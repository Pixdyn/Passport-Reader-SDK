//package com.pixl.pixlpassportreader.scanner
//
//import android.content.Context
//import android.graphics.Bitmap
//import android.util.Log
//import com.pixl.pixlpassportreader.TesseractManager
//import com.pixl.pixlpassportreader.scanner.mrz.MrzParser
//import com.pixl.pixlpassportreader.scanner.mrz.MrzRecord
//
//class CaptureTextReaderAnalyzer(
//    private val context: Context,
//    private val passFoundListener: (MrzRecord) -> Unit,
//    private val errorListener: (String, Boolean) -> Unit
//) {
//    // Suspend, not a self-launched coroutine: the caller (MRZScanActivity.onDetect)
//    // already runs this inside its own bgScope.launch, so wrapping again here just
//    // added a redundant coroutine hop and - worse - an untracked scope that kept
//    // running OCR even after the activity was torn down. Shares the single
//    // TesseractManager engine with the TD1 (3-line) analyzer instead of maintaining
//    // a second, separately-initialized TessBaseAPI - that duplicate engine load was
//    // racing this one on every resume and was the main source of the multi-second
//    // delay before the first successful read.
//    suspend fun process(bitmap: Bitmap) {
//        try {
//            if (!TesseractManager.isReady) {
//                errorListener("Please scan again.", true)
//                return
//            }
//
//            val extractedText = TesseractManager.recognize(bitmap)
//            if (extractedText.isNullOrBlank()) {
//                Log.e("OCRB", "Empty OCR output")
//                errorListener("Please scan again. Couldn't read from image.", true)
//                return
//            }
//
//            Log.d("OCRB", "OCR Output: $extractedText")
//            processTextFromImage(extractedText)
//        } catch (e: Exception) {
//            Log.e("CaptureTextReader", "process error: ${e.message}", e)
//            errorListener("Please scan again. Couldn't read from image.", true)
//        }
//    }
//
//
//    private fun processTextFromImage(visionText: String) {
//        Log.d("MRZ_RAW", visionText)
//
//        val fullMrzString = convertToFullMrz(visionText)
//        if (fullMrzString.startsWith("Error:")) {
//            Log.e("MRZScan", fullMrzString)
//            errorListener("Please scan again. $fullMrzString", true)
//            return
//        }
//
//        val lines = fullMrzString.split('\n')
//        if (lines.size != 2) {
//            errorListener("Error: Could not extract two valid MRZ lines from the scanned text.", true)
//            return
//        }
//
//        try {
//            val parts = extractMrzParts(lines.first())
//            val lastString = parts.lastOrNull()
//            var processedMrz = fullMrzString
//
//            if (lastString != null && lastString.hasNumber()) {
//                val reformatted = reformatGenericMrz(fullMrzString)
//                if (reformatted == null) {
//                    errorListener("MRZ reformat failed. Please scan again.", true)
//                    return
//                }
//                processedMrz = reformatted
//            }
//
//            processedMrz = replacePattern(processedMrz)
//            val finalLines = processedMrz.split('\n')
//            if (finalLines.size == 2) {
//                val firstLine = finalLines[0]
//                val secondLine = finalLines[1]
//                if (firstLine.length < 44 || secondLine.length < 44) {
//                    errorListener(
//                        "Error: Both MRZ lines must contain at least 44 characters after conversion.",
//                        true
//                    )
//                    return
//                }
//                checkCorrectMrzScanned(firstLine, secondLine)
//            } else {
//                errorListener(
//                    "Error: Could not extract two valid MRZ lines from the scanned text.",
//                    true
//                )
//            }
//        } catch (e: Exception) {
//            Log.e("MRZScan", "Error processing MRZ: ${e.message}", e)
//            errorListener("Please scan again. Error in processing MRZ structure.", true)
//        }
//    }
//
//    fun extractMrzParts(mrzLine: String): List<String> {
//        val delimiterRegex = "<{1,}".toRegex()
//        return mrzLine.split(delimiterRegex).filter { it.isNotEmpty() }
//    }
//
//    fun replacePattern(inputString: String): String {
//        val regex = Regex("<a< <[a-zA-Z0-9]<")
//        return inputString.replace(regex, "<<<")
//    }
//
//    private fun checkCorrectMrzScanned(firstLine: String, secondLine: String) {
//        val correctedFirstLine =
//            correctWrongCharacters(firstLine).replace("Ö", "0")
//                .replace(" ", "", ignoreCase = true)
//
//        val correctedSecondLine = secondLine.replace(" ", "", ignoreCase = true)
//        val validStartCharacters = setOf('P', 'V')
//
//        if (correctedFirstLine.length == 44 &&
//            correctedFirstLine.contains("<<") &&
//            validStartCharacters.contains(correctedFirstLine[0])
//        ) {
//            try {
//                val record =
//                    MrzParser.parse(correctedFirstLine + "\n" + correctedSecondLine)
//                if (record != null) {
//                    if (record.surname.isEmpty()) record.surname = "N/A"
//                    if (record.givenNames.isEmpty()) record.givenNames = "N/A"
//
//                    record.surname = record.surname.replace("9", " ")
//                    record.givenNames = record.givenNames.replace("9", " ")
//
//                    val passportNo = record.documentNumber
//
//                    if (!isValidPassportNumber(passportNo)) {
//                        errorListener(
//                            "Invalid or incomplete passport number detected. Please scan again.",
//                            true
//                        )
//                        return
//                    }
//
//
//                    val cleanSurname = normalizeMrzName(record.surname)
//                    val cleanGivenName = normalizeMrzName(record.givenNames)
//
//                    if (
//                        containsInvalidRepeatedChars(cleanSurname) ||
//                        containsInvalidRepeatedChars(cleanGivenName)
//                    ) {
//                        errorListener(
//                            "Invalid Name detected. Please scan again.",
//                            true
//                        )
//                    }
//
//                    val personalNumber = extractPersonalNumberFromLine2(correctedSecondLine)
//                    record.personalNumber = personalNumber ?: ""
//
//                    sanitizeMrzRecord(record)?.let { clean ->
//                        Log.e("passFoundListener", "Cleaned MRZ Record: $clean")
//                        passFoundListener(clean)
//                    } ?: run {
//                        errorListener(
//                            "Invalid characters detected in MRZ fields. Please scan again.",
//                            true
//                        )
//                    }
//                } else {
//                    errorListener("Please scan again. Error in processing MRZ.", true)
//                }
//            } catch (e: Exception) {
//                errorListener("Please scan again. Error in processing MRZ.", true)
//            }
//        } else {
//            errorListener("Please scan again. Error in processing MRZ.", true)
//        }
//    }
//
//    private fun normalizePassportNumber(raw: String): String {
//        return raw
//            .uppercase()
//            .replace("<", "")
//            .replace(" ", "")
//            .replace("Ö", "0")
//            .replace("O", "0") // OCR confusion
//    }
//
//    private fun hasOnlyValidPassportChars(passportNo: String): Boolean {
//        return passportNo.matches(Regex("^[A-Z0-9]+$"))
//    }
//
//    private fun isValidPassportLength(passportNo: String): Boolean {
//        return passportNo.length in 8..9
//    }
//
//    private fun isLikelyOcrGarbage(passportNo: String): Boolean {
//        if (passportNo.length < 6) return true
//
//        val freq = passportNo.groupingBy { it }.eachCount()
//        val maxRatio = freq.values.maxOrNull()!!.toFloat() / passportNo.length
//
//        return maxRatio > 0.6f
//    }
//
//    private fun isValidPassportNumber(rawPassportNo: String?): Boolean {
//        if (rawPassportNo.isNullOrBlank()) return false
//
//        val passportNo = normalizePassportNumber(rawPassportNo)
//
//        return hasOnlyValidPassportChars(passportNo) &&
//                isValidPassportLength(passportNo) &&
//                !isLikelyOcrGarbage(passportNo)
//    }
//
//    private fun containsInvalidRepeatedChars(name: String): Boolean {
//        val regex = Regex("([A-Z])\\1{4,}")
//        return regex.containsMatchIn(name)
//    }
//
//
//    fun extractPersonalNumberFromLine2(mrzLine2: String): String? {
//        if (mrzLine2.length != 44) return null
//        return mrzLine2.substring(28, 42)
//    }
//
//    private fun normalizeMrzName(name: String): String {
//        return name
//            .replace("<", " ")
//            .replace("9", " ")
//            .replace(Regex("\\s+"), " ")
//            .trim()
//            .uppercase()
//    }
//
//
//    fun cleanName(value: String): String {
//        return value.uppercase()
//            .replace("<", " ")
//            .replace(Regex("[^A-Z ]"), "")
//            .replace(Regex("\\s+"), " ")
//            .trim()
//    }
//
//
//    private fun sanitizeMrzRecord(record: MrzRecord): MrzRecord? {
//        val allowedPattern = Regex("[A-Z0-9<]")
//
//        fun cleanField(value: String): String {
//            if (value.isBlank()) return ""
//            return buildString {
//                value.uppercase().forEach { ch ->
//                    when {
//                        allowedPattern.matches(ch.toString()) -> append(ch)
//                        ch.isWhitespace() -> append("<")
//                        else -> append("<")
//                    }
//                }
//            }.trim('<')
//        }
//
//        record.surname = decodeNameField(cleanField(record.surname))
//        record.givenNames = decodeNameField(cleanField(record.givenNames))
//        record.documentNumber = cleanField(record.documentNumber)
//        record.nationality = cleanField(record.nationality)
//        record.issuingCountry = cleanField(record.issuingCountry)
//        record.personalNumber = cleanField(record.personalNumber)
//        return record
//    }
//
//    private fun decodeNameField(mrz: String): String {
//
//        var mrzNameFild = mrz
//            .trimEnd('<')
//            .replace("<<", " ")
//            .replace("<", " ")
//            .trim()
//        var cleanName = cleanName(mrzNameFild)
//        return cleanName
//    }
//
//    private fun correctWrongCharacters(mrzLine: String): String {
//        var line = mrzLine
//            .replace("«", "<", ignoreCase = true)
//            .replace(" ", "", ignoreCase = true)
//            .replace("  ", "", ignoreCase = true)
//            .replace(",", "<", ignoreCase = true)
//            .replace("a", "Q")
//            .replace("<<S<<", "<<<<<", ignoreCase = true)
//            .replace("<K<", "<<<", ignoreCase = true)
//            .replace("<KK<", "<<<<", ignoreCase = true)
//            .replace("<KKK<", "<<<<<", ignoreCase = true)
//            .replace("<KKKK<", "<<<<<<", ignoreCase = true)
//            .replace("<KKKKK<", "<<<<<<<", ignoreCase = true)
//            .replace("<KKKKKK<", "<<<<<<<<", ignoreCase = true)
//            .replace("<c<", "<<<", ignoreCase = true)
//            .replace("?", "<", ignoreCase = true)
//            .replace("<cc<", "<<<<", ignoreCase = true)
//            .replace("<cc", "<<<", ignoreCase = true)
//            .replace("cc<", "<<<", ignoreCase = true)
//            .replace("<ccc<", "<<<<<", ignoreCase = true)
//            .replace("<ccccc<", "<<<<<<<", ignoreCase = true)
//            .replace("<cccccc<", "<<<<<<<<", ignoreCase = true)
//            .replace("c<<<", "<<<<", ignoreCase = true)
//            .replace("<s<", "<<<", ignoreCase = true)
//            .replace("<ss<", "<<<<", ignoreCase = true)
//            .replace("<sss<", "<<<<<", ignoreCase = true)
//            .replace("<ssss<", "<<<<<<", ignoreCase = true)
//            .replace("<sssss<", "<<<<<<<", ignoreCase = true)
//            .replace("<ssssss<", "<<<<<<<<", ignoreCase = true)
//            .replace("0D00", "0000", ignoreCase = true)
//            .replace("OO0", "000", ignoreCase = true)
//            .replace("0D0", "000", ignoreCase = true)
//            .replace("OD0", "000", ignoreCase = true)
//            .replace("OOO", "000", ignoreCase = true)
//            .replace("O0D", "000", ignoreCase = true)
//            .replace("ODO", "000", ignoreCase = true)
//            .replace("D0", "00", ignoreCase = true)
//            .replace("0O0", "000", ignoreCase = true)
//            .replace("O0", "00", ignoreCase = true)
//            .replace("0D", "00", ignoreCase = true)
//            .replace("<8<", "<<<", ignoreCase = true)
//            .replace("<0<", "<<<", ignoreCase = true)
//            .replace("Ó", "O")
//            .replace("&", "8", ignoreCase = true)
//            .replace("<C<", "<<<", ignoreCase = true)
//            .replace("<<C<", "<<<<", ignoreCase = true)
//            .replace("<:<", "<<<", ignoreCase = true)
//            .replace("IMD", "IND", ignoreCase = true)
//            .replace("C<CC", "<<<<", ignoreCase = true)
//            .replace(Regex("[%^&#`!@\$\\-()*]"), "<")
//            .replace(".", "")
//            .uppercase()
//
//        if (line.length < 44) {
//            line = line.padEnd(44, '<')
//        } else if (line.length > 44) {
//            line = line.substring(0, 44)
//        }
//
////        val split = line.split("<<")[0].split("<")
////        if (split.size > 2) {
////            val index = split[0].length + split[1].length + 1
////            line = line.substring(0, index) + "9" + line.substring(index + 1)
////        }
//        return line
//    }
//
//    fun reformatGenericMrz(malformedMrz: String): String? {
//        return try {
//            val TARGET_LINE_LENGTH = 44
//            val lines = malformedMrz.replace("«", "<").split('\n')
//            if (lines.size != 2) {
//                errorListener("Please scan again. Error in processing MRZ.", true)
//                null
//            } else {
//                val splitfirst = extractMrzParts(lines.first())
//                if (splitfirst.isEmpty()) {
//                    errorListener("Please scan again. Invalid MRZ format detected.", true)
//                    null
//                } else {
//                    val passportID = splitfirst.last()
//                    val firstLine = lines.first()
//                    val secondLine = lines.last()
//
//                    val newFirstLine = firstLine.replace(passportID, "").padEnd(44, '<')
//                    val secondSub = secondLine.substring(
//                        0,
//                        (secondLine.length - passportID.length - 1).coerceAtLeast(0)
//                    )
//                    val newSecondLine =
//                        (passportID + secondSub).padEnd(TARGET_LINE_LENGTH - 1, '<') + "4"
//
//                    "$newFirstLine\n$newSecondLine"
//                }
//            }
//        } catch (e: Exception) {
//            Log.e("MRZScan", "Error reformatting MRZ: ${e.message}", e)
//            errorListener("Please scan again. Error reformatting MRZ.", true)
//            null
//        }
//    }
//
//    fun String.hasNumber(): Boolean = any { it.isDigit() }
//
//    fun convertToFullMrz(inputString: String): String {
//        return try {
//            val normalizedMrzString = normalizePassportPrefix(inputString)
//            val TARGET_LINE_LENGTH = 44
//            val cleanedMrz = normalizedMrzString.replace(Regex("[^A-Z0-9<]"), "")
//
//            val line2AnchorPattern = "[A-Z]{3}\\d{6}".toRegex()
//            val anchorMatch = line2AnchorPattern.find(cleanedMrz)
//            if (anchorMatch != null) {
//                val passportInfoBlockLength = 10
//                val line2StartIndex = anchorMatch.range.first - passportInfoBlockLength
//                if (line2StartIndex < 0) {
//                    return "Error: Could not determine a valid split point."
//                }
//
//                val line1Raw = cleanedMrz.substring(0, line2StartIndex)
//                var line2Raw = cleanedMrz.substring(line2StartIndex)
//
//                val natDobMatch = line2AnchorPattern.find(line2Raw)
//                if (natDobMatch != null) {
//                    val sexFieldIndex = natDobMatch.range.last + 2
//                    if (sexFieldIndex < line2Raw.length && line2Raw[sexFieldIndex] == 'N') {
//                        val chars = line2Raw.toCharArray()
//                        chars[sexFieldIndex] = 'M'
//                        line2Raw = String(chars)
//                    }
//                }
//
//                val fullMrzLine1 = line1Raw.padEnd(TARGET_LINE_LENGTH, '<')
//                val bodyLength = TARGET_LINE_LENGTH - 1
//                val finalCheckDigit =
//                    if (line2Raw.isNotEmpty() && line2Raw.last().isDigit()) line2Raw.last() else '4'
//                val contentSource =
//                    if (line2Raw.isNotEmpty() && line2Raw.last().isDigit()) line2Raw.dropLast(1)
//                    else line2Raw
//                val body =
//                    contentSource.padEnd(bodyLength, '<').substring(0, bodyLength)
//                val fullMrzLine2 = body + finalCheckDigit
//
//                "$fullMrzLine1\n$fullMrzLine2"
//            } else {
//                "Error: Could not find anchor (Nationality + DOB) in MRZ string."
//            }
//        } catch (e: Exception) {
//            "Error: An exception occurred during parsing: ${e.message}"
//        }
//    }
//
//    private fun normalizePassportPrefix(inputString: String): String {
//        val pIndex = inputString.indexOf('P')
//        if (pIndex == -1) {
//            return "P<" + inputString.replace(Regex("[^A-Z0-9<]"), "")
//        }
//        val candidateString = inputString.substring(pIndex).trim()
//        if (candidateString.startsWith("P<")) return candidateString
//
//        val otherValidPrefixes = listOf(
//            "PA", "PC", "PD", "PE", "PF", "PG", "PH", "PI", "PJ", "PK", "PL", "PM",
//            "PN", "PO", "PP", "PQ", "PR", "PS", "PT", "PU", "PV", "PW", "PX", "PY", "PZ"
//        )
//        for (prefix in otherValidPrefixes) {
//            if (candidateString.startsWith(prefix)) {
//                return "P<" + candidateString.substring(2)
//            }
//        }
//
//        if (candidateString.length >= 2 &&
//            candidateString[0] == 'P' &&
//            candidateString[1].isLetter()
//        ) {
//            return "P<" + candidateString.substring(2)
//        }
//
//        return "P<$candidateString"
//    }
//}

package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.pixl.pixlpassportreader.TesseractManager
import com.pixl.pixlpassportreader.scanner.mrz.MrtdTd1
import com.pixl.pixlpassportreader.scanner.mrz.MrzParser
import com.pixl.pixlpassportreader.scanner.mrz.MrzRecord

class CaptureTextReaderAnalyzer(
    private val context: Context,
    private val passFoundListener: (MrzRecord) -> Unit,
    private val errorListener: (String, Boolean) -> Unit
) {

    // MARK: - Stability tracking
    //
    // WAS requiredStableReads = 2, comparing the OCR-derived candidate
    // string for EXACT equality across two consecutive attempts. That was
    // fighting against normal per-attempt OCR variance: even when checksum
    // validation passed on two consecutive reads, small character-level OCR
    // noise (a shifted digit, a stray character - more surface area for this
    // on 3-line TD1 cards) meant the two strings rarely matched byte-for-byte,
    // so stableReadCount kept resetting to 1 instead of reaching 2 - visible
    // in logs as "MRZ valid but not yet stable (1/2)" repeating many times in
    // a row. ICAO checksum validation (multiple independent 7-3-1 weighted
    // check digits + composite check + garbage-token/name-shape checks) is
    // already a strong enough gate on its own; requiring an exact repeat on
    // top of it only added latency and, on noisier TD1 reads, could cause
    // the scan to never converge at all. Accept on the first checksum-valid
    // candidate instead.
    private val requiredStableReads = 1
    private var lastCandidateMrz: String? = null
    private var stableReadCount = 0

    private fun resetStability() {
        lastCandidateMrz = null
        stableReadCount = 0
    }

    suspend fun process(bitmap: Bitmap) {
        try {
            if (!TesseractManager.isReady) {
                errorListener("Please scan again.", true)
                return
            }

            val extractedText = TesseractManager.recognize(bitmap)
            if (extractedText.isNullOrBlank()) {
                Log.e("OCRB", "Empty OCR output")
                resetStability()
                return
            }

            Log.d("OCRB", "OCR Output: $extractedText")
            processTextFromImage(extractedText)
        } catch (e: Exception) {
            Log.e("CaptureTextReader", "process error: ${e.message}", e)
            resetStability()
        }
    }

    // ---------------------------------------------------------------------
    // MARK: - Candidate generation + checksum-gated selection
    // ---------------------------------------------------------------------

    private fun processTextFromImage(visionText: String) {
        Log.d("MRZ_RAW", visionText)

        val rawLines = visionText
            .split('\n')
            .map { sanitizeLine(it) }
            .filter { it.isNotEmpty() }

        val groups = candidateLineGroups(rawLines)
        if (groups.isEmpty()) {
            Log.d("MRZScan", "No plausible MRZ line groupings found this frame")
            resetStability()
            return
        }

        // Try every plausible grouping this frame produced and let checksum
        // validation pick the real MRZ, instead of committing to a single
        // guessed split point (the old convertToFullMrz anchor approach).
        var validatedCandidate: ValidatedCandidate? = null
        for (group in groups) {
            val candidate = validate(group)
            if (candidate != null) {
                validatedCandidate = candidate
                break
            }
        }

        if (validatedCandidate == null) {
            Log.d("MRZScan", "No candidate grouping passed checksum/shape validation, discarding frame")
            resetStability()
            return
        }

        val candidateKey = validatedCandidate.lines.joinToString("\n")

        // Require the same checksum-valid candidate on consecutive frames
        // before finalizing (mirrors OCRTextProcessor's stability guard).
        if (candidateKey == lastCandidateMrz) {
            stableReadCount += 1
        } else {
            lastCandidateMrz = candidateKey
            stableReadCount = 1
        }

        if (stableReadCount < requiredStableReads) {
            Log.d("MRZScan", "MRZ valid but not yet stable ($stableReadCount/$requiredStableReads)")
            return
        }

        finalizeRecord(validatedCandidate)
    }

    private data class ValidatedCandidate(
        val lines: List<String>,
        val docType: DocType
    )

    private enum class DocType { TD1, TD2, TD3 }

    /**
     * Builds every plausible 2-line (TD2/TD3) and 3-line (TD1) grouping from
     * lines that are individually expected to already be isolated MRZ rows
     * (post-OCR, pre-line-boundary-guessing). Mirrors
     * MRZParser.candidateLineGroups() on iOS - deliberately does not
     * concatenate unrelated text and slide a fixed window across it, which is
     * what the old convertToFullMrz anchor-regex effectively did and is what
     * made it fragile against new OCR error patterns.
     */
    private fun candidateLineGroups(rawLines: List<String>): List<List<String>> {
        val mrzWidths = setOf(28, 29, 30, 31, 35, 36, 37, 43, 44, 45)
        val candidateLines = rawLines.filter { line ->
            line.length >= 28 && (line.contains("<") || mrzWidths.contains(line.length))
        }
        if (candidateLines.isEmpty()) return emptyList()

        val groups = mutableListOf<List<String>>()
        for (index in candidateLines.indices) {
            if (index + 1 < candidateLines.size) {
                groups.add(listOf(candidateLines[index], candidateLines[index + 1])) // TD3/TD2 attempt
            }
            if (index + 2 < candidateLines.size) {
                groups.add(
                    listOf(
                        candidateLines[index],
                        candidateLines[index + 1],
                        candidateLines[index + 2]
                    )
                ) // TD1 attempt
            }
        }
        return groups
    }

    /**
     * Applies position-aware correction + structural regex + ICAO checksum
     * validation to a candidate grouping. Returns null if it fails any gate.
     * This function - not string-pattern patching - is the decisive filter,
     * mirroring parse(lines:) + validateTDxChecksums on iOS.
     */
    private fun validate(group: List<String>): ValidatedCandidate? {
        return when (group.size) {
            2 -> validateTwoLine(group[0], group[1])
            3 -> validateTd1(group[0], group[1], group[2])
            else -> null
        }
    }

    companion object {
        // Compiled ONCE and reused. Regex(...) recompiles the pattern via
        // java.util.regex.Pattern.compile() on every construction - with no
        // caching, calling `Regex("^...")` inline inside validateTd3/Td2/Td1
        // meant every one of these patterns was rebuilt from scratch on every
        // single candidate grouping tried, potentially dozens of times per
        // OCR attempt (candidateLineGroups() can produce several windows per
        // frame). Compiling once here removes that entirely - the actual
        // dominant cost remains Tesseract's own recognize() call, not this
        // validation step, but there's no reason to pay redundant compile
        // overhead on top of it.
        private val TD3_LINE1_PATTERN = Regex("^[A-Z][A-Z<][A-Z]{3}[A-Z<]{39}$")
        private val TD3_LINE2_PATTERN = Regex("^[A-Z0-9<]{9}[0-9][A-Z]{3}[0-9]{7}[MFX<][0-9]{7}[A-Z0-9<]{16}$")
        private val TD2_LINE1_PATTERN = Regex("^[A-Z][A-Z<][A-Z]{3}[A-Z<]{31}$")
        private val TD2_LINE2_PATTERN = Regex("^[A-Z0-9<]{9}[0-9][A-Z]{3}[0-9]{7}[MFX<][0-9]{7}[A-Z0-9<]{8}$")
        private val TD1_LINE1_PATTERN = Regex("^[A-Z][A-Z<][A-Z]{3}[A-Z0-9<]{9}[0-9][A-Z0-9<]{15}$")
        private val TD1_LINE2_PATTERN = Regex("^[0-9]{7}[MFX<][0-9]{7}[A-Z]{3}[A-Z0-9<]{11}[0-9]$")
        private val TD1_LINE3_PATTERN = Regex("^[A-Z<]{30}$")
    }

    private fun validateTwoLine(rawLine1: String, rawLine2: String): ValidatedCandidate? {
        // Try TD3 (44-wide) first, then TD2 (36-wide).
        validateTd3(rawLine1, rawLine2)?.let { return it }
        validateTd2(rawLine1, rawLine2)?.let { return it }
        return null
    }

    private fun validateTd3(rawLine1: String, rawLine2: String): ValidatedCandidate? {
        val line1 = normalizeTdLine1(rawLine1, width = 44)
        val line2 = normalizeTravelDocLine2(rawLine2, width = 44)
        if (line1.length != 44 || line2.length != 44) return null

        if (!TD3_LINE1_PATTERN.matches(line1)) return null
        if (!TD3_LINE2_PATTERN.matches(line2)) return null

        if (!validateTd3Checksums(line2)) return null

        val namesSection = line1.substring(5)
        if (containsGarbageToken(namesSection)) return null

        return ValidatedCandidate(listOf(line1, line2), DocType.TD3)
    }

    private fun validateTd2(rawLine1: String, rawLine2: String): ValidatedCandidate? {
        val line1 = normalizeTdLine1(rawLine1, width = 36)
        val line2 = normalizeTravelDocLine2(rawLine2, width = 36)
        if (line1.length != 36 || line2.length != 36) return null

        if (!TD2_LINE1_PATTERN.matches(line1)) return null
        if (!TD2_LINE2_PATTERN.matches(line2)) return null

        if (!validateTd2Checksums(line2)) return null

        val namesSection = line1.substring(5)
        if (containsGarbageToken(namesSection)) return null

        return ValidatedCandidate(listOf(line1, line2), DocType.TD2)
    }

    private fun validateTd1(rawLine1: String, rawLine2: String, rawLine3: String): ValidatedCandidate? {
        val line1 = normalizeTd1Line1(rawLine1)
        val line2 = normalizeTd1Line2(rawLine2)
        val line3 = normalizeTd1Line3(rawLine3)
        if (line1.length != 30 || line2.length != 30 || line3.length != 30) return null

        if (!TD1_LINE1_PATTERN.matches(line1)) return null
        if (!TD1_LINE2_PATTERN.matches(line2)) return null
        if (!TD1_LINE3_PATTERN.matches(line3)) return null

        if (!validateTd1Checksums(line1, line2)) return null
        if (containsGarbageToken(line3)) return null

        return ValidatedCandidate(listOf(line1, line2, line3), DocType.TD1)
    }

    private fun finalizeRecord(candidate: ValidatedCandidate) {
        try {
            val mrzText = candidate.lines.joinToString("\n")
            val record = MrzParser.parse(mrzText)
            if (record == null) {
                Log.e("MRZScan", "Checksum-valid candidate failed MrzParser.parse - unexpected")
                resetStability()
                return
            }

            val passportNo = record.documentNumber
            if (!isValidPassportNumber(passportNo)) {
                resetStability()
                return
            }

            val cleanSurname = normalizeMrzName(record.surname)
            val cleanGivenName = normalizeMrzName(record.givenNames)
            if (containsInvalidRepeatedChars(cleanSurname) || containsInvalidRepeatedChars(cleanGivenName)) {
                resetStability()
                return
            }

            when (candidate.docType) {
                DocType.TD3 -> {
                    record.personalNumber = extractPersonalNumberFromLine2(candidate.lines[1]) ?: ""
                }
                DocType.TD1 -> applyTd1FieldCleanup(record, candidate.lines)
                DocType.TD2 -> { /* no extra fields to backfill */ }
            }

            val clean = sanitizeMrzRecord(record)
            if (clean == null) {
                resetStability()
                return
            }

            // Applied after sanitizeMrzRecord so the "/" survives - cleanField() treats any
            // character outside [A-Z0-9<] as MRZ filler and would mangle "N/A" into "N A".
            if (clean.surname.isEmpty()) clean.surname = "N/A"
            if (clean.givenNames.isEmpty()) clean.givenNames = "N/A"

            Log.d("passFoundListener", "Confirmed MRZ Record: $clean")
            passFoundListener(clean)
        } catch (e: Exception) {
            Log.e("MRZScan", "Error finalizing MRZ record: ${e.message}", e)
            resetStability()
        }
    }

    /**
     * TD1-only field cleanup, ported as-is from the old
     * CaptureTextReaderAnalyzerTd1.checkCorrectMrzScanned.
     *
     * MrtdTd1.optional/.optional2 are populated by MrzParser.parseString() by
     * turning a "<<" filler run into a literal ", " - a comma that trips
     * MRZScanActivity.hasInvalidChars() and silently kills the scan.
     * Overwritten here with clean values pulled straight from the raw MRZ
     * substrings (same column ranges MrtdTd1.fromMrz()/toMrz() use
     * internally), and personalNumber (never populated by MrtdTd1 itself, but
     * required downstream by MRZScanActivity.generatePassportMRZ) is
     * backfilled from that cleaned optional2.
     *
     * The manual substring fallback below only fires if MrzParser.parse
     * already left a field blank - it's a safety net, not the primary path.
     */
    private fun applyTd1FieldCleanup(record: MrzRecord, lines: List<String>) {
        val firstLine = lines[0]
        val secondLine = lines[1]
        val thirdLine = lines[2]

        if (record is MrtdTd1) {
            record.optional = firstLine
                .substring(15, minOf(30, firstLine.length))
                .replace(Regex("[^A-Z0-9]"), "")
            record.optional2 = secondLine
                .substring(18, minOf(29, secondLine.length))
                .replace(Regex("[^A-Z0-9]"), "")
        }

        record.personalNumber = (record as? MrtdTd1)?.optional2 ?: ""

        try {
            val issuingCountry = firstLine.substring(2, 5).replace("<", "")
            val documentNumber = firstLine.substring(5, 14).padEnd(9, '<').replace(" ", "")
            val nationality = secondLine.substring(15, 18).take(3).replace("<", "").replace(" ", "")

            val nameLine = thirdLine.replace("<", " ").trim()
            val names = nameLine.split("  ")
            val surname = names.getOrNull(0)?.trim() ?: "N/A"
            val givenNames = names.getOrNull(1)?.trim() ?: "N/A"

            if (record.nationality.isNullOrBlank()) record.nationality = nationality
            if (record.documentNumber.isNullOrBlank()) record.documentNumber = documentNumber
            if (record.surname.isNullOrBlank()) record.surname = surname
            if (record.givenNames.isNullOrBlank()) record.givenNames = givenNames
            record.issuingCountry = issuingCountry
        } catch (e: Exception) {
            Log.e("MRZ_FIELD_EXTRACTION_TD1", "Manual field extraction error: ${e.message}")
        }
    }

    // ---------------------------------------------------------------------
    // MARK: - ICAO 9303 checksum validation (7-3-1 weighting)
    // Ported directly from MRZParser.swift's validateTDxChecksums.
    // ---------------------------------------------------------------------

    private fun checksumCharValue(c: Char): Int {
        return when (c) {
            in '0'..'9' -> c - '0'
            in 'A'..'Z' -> c - 'A' + 10
            '<' -> 0
            else -> -1
        }
    }

    private fun computeCheckDigit(data: String): Int? {
        val weights = intArrayOf(7, 3, 1)
        var sum = 0
        for ((i, c) in data.withIndex()) {
            val value = checksumCharValue(c)
            if (value < 0) return null
            sum += value * weights[i % 3]
        }
        return sum % 10
    }

    private fun validateCheckDigit(data: String, checkDigit: Char): Boolean {
        if (checkDigit == '<') {
            // '<' as a check digit is only valid when the field is entirely filler.
            return data.all { it == '<' }
        }
        val expected = computeCheckDigit(data) ?: return false
        val actual = checkDigit.digitToIntOrNull() ?: return false
        return expected == actual
    }

    private fun validateTd3Checksums(line2: String): Boolean {
        if (line2.length != 44) return false
        val docNumber = line2.substring(0, 9)
        if (!validateCheckDigit(docNumber, line2[9])) return false

        val dob = line2.substring(13, 19)
        if (!validateCheckDigit(dob, line2[19])) return false

        val expiry = line2.substring(21, 27)
        if (!validateCheckDigit(expiry, line2[27])) return false

        val personalNumber = line2.substring(28, 42)
        if (!personalNumber.all { it == '<' }) {
            if (!validateCheckDigit(personalNumber, line2[42])) return false
        }

        val composite = docNumber + line2[9] + dob + line2[19] + expiry + line2[27] + personalNumber + line2[42]
        return validateCheckDigit(composite, line2[43])
    }

    private fun validateTd2Checksums(line2: String): Boolean {
        if (line2.length != 36) return false
        val docNumber = line2.substring(0, 9)
        if (!validateCheckDigit(docNumber, line2[9])) return false

        val dob = line2.substring(13, 19)
        if (!validateCheckDigit(dob, line2[19])) return false

        val expiry = line2.substring(21, 27)
        return validateCheckDigit(expiry, line2[27])
    }

    private fun validateTd1Checksums(line1: String, line2: String): Boolean {
        if (line1.length != 30 || line2.length != 30) return false

        val docNumber = line1.substring(5, 14)
        if (!validateCheckDigit(docNumber, line1[14])) return false

        val dob = line2.substring(0, 6)
        if (!validateCheckDigit(dob, line2[6])) return false

        val expiry = line2.substring(8, 14)
        if (!validateCheckDigit(expiry, line2[14])) return false

        val optionalLine1 = line1.substring(15, 30)
        val composite = docNumber + line1[14] + optionalLine1 + dob + line2[6] +
                expiry + line2[14] + line2.substring(18, 29)
        return validateCheckDigit(composite, line2[29])
    }

    /** Flags OCR noise: a token that's mostly one repeated character. */
    private fun containsGarbageToken(text: String): Boolean {
        val tokens = text.replace("<", " ").split(" ").filter { it.isNotEmpty() }
        for (token in tokens) {
            if (token.length < 4) continue
            val first = token.first()
            val repeats = token.count { it == first }
            if (repeats.toDouble() / token.length > 0.6) return true
        }
        return false
    }

    // ---------------------------------------------------------------------
    // MARK: - Position-aware OCR character correction
    // Ported from letterLike()/digitLike()/sexLike() + normalizeTDLine1/2 and
    // normalizeTD1Line1/2/3 on iOS. Replaces the old ~40-pattern
    // correctWrongCharacters() blanket string patching.
    // ---------------------------------------------------------------------

    private fun letterLike(c: Char): Char = when (c) {
        '0' -> 'O'
        '1' -> 'I'
        '2' -> 'Z'
        '5' -> 'S'
        '6' -> 'G'
        '8' -> 'B'
        else -> c
    }

    private fun digitLike(c: Char): Char = when (c) {
        'O', 'Q', 'D' -> '0'
        'I', 'L' -> '1'
        'Z' -> '2'
        'S' -> '5'
        'G' -> '6'
        'B' -> '8'
        else -> c
    }

    private fun sexLike(c: Char): Char = when (c) {
        'K' -> '<'
        'P' -> 'F'
        else -> letterLike(c)
    }

    private fun padOrTruncate(line: String, width: Int): String {
        return if (line.length >= width) line.substring(0, width) else line.padEnd(width, '<')
    }

    private fun normalizeTdLine1(rawLine: String, width: Int): String {
        val padded = padOrTruncate(rawLine, width)
        return buildString {
            for ((index, ch) in padded.withIndex()) {
                append(if (index == 1) (if (ch == 'K') '<' else ch) else letterLike(ch))
            }
        }
    }

    private fun normalizeTravelDocLine2(rawLine: String, width: Int): String {
        val padded = padOrTruncate(rawLine, width)
        return buildString {
            for ((index, ch) in padded.withIndex()) {
                val out = when (index) {
                    9, 19, 27, width - 1 -> digitLike(ch)
                    in 10..12 -> letterLike(ch)
                    in 13..18, in 21..26 -> digitLike(ch)
                    20 -> sexLike(ch)
                    else -> ch
                }
                append(out)
            }
        }
    }

    private fun normalizeTd1Line1(rawLine: String): String {
        val padded = padOrTruncate(rawLine, 30)
        return buildString {
            for ((index, ch) in padded.withIndex()) {
                val out = when (index) {
                    in 0..4 -> if (index == 1) (if (ch == 'K') '<' else ch) else letterLike(ch)
                    14 -> digitLike(ch)
                    else -> ch
                }
                append(out)
            }
        }
    }

    private fun normalizeTd1Line2(rawLine: String): String {
        val padded = padOrTruncate(rawLine, 30)
        return buildString {
            for ((index, ch) in padded.withIndex()) {
                val out = when (index) {
                    in 0..6, 8, in 8..13, 14, 29 -> digitLike(ch)
                    7 -> sexLike(ch)
                    in 15..17 -> letterLike(ch)
                    else -> ch
                }
                append(out)
            }
        }
    }

    private fun normalizeTd1Line3(rawLine: String): String {
        val padded = padOrTruncate(rawLine, 30)
        return buildString { padded.forEach { append(letterLike(it)) } }
    }

    private fun sanitizeLine(rawLine: String): String {
        val allowed = "ABCDEFGHIJKLMNOPQRSTUVWXYZ<0123456789".toSet()
        val fillerLike = setOf('«', '»', '‹', '›', '\\', '/', '|', '_', '-', '–', '—')
        return buildString {
            for (ch in rawLine.uppercase()) {
                when {
                    allowed.contains(ch) -> append(ch)
                    fillerLike.contains(ch) -> append('<')
                }
            }
        }
    }

    // ---------------------------------------------------------------------
    // MARK: - Field-level validation / cleanup (kept from the original,
    // still useful as a secondary sanity check after checksum validation)
    // ---------------------------------------------------------------------

    private fun normalizePassportNumber(raw: String): String {
        return raw
            .uppercase()
            .replace("<", "")
            .replace(" ", "")
            .replace("Ö", "0")
            .replace("O", "0")
    }

    private fun hasOnlyValidPassportChars(passportNo: String): Boolean {
        return passportNo.matches(Regex("^[A-Z0-9]+$"))
    }

    private fun isValidPassportLength(passportNo: String): Boolean {
        return passportNo.length in 8..9
    }

    private fun isLikelyOcrGarbage(passportNo: String): Boolean {
        if (passportNo.length < 6) return true
        val freq = passportNo.groupingBy { it }.eachCount()
        val maxRatio = freq.values.maxOrNull()!!.toFloat() / passportNo.length
        return maxRatio > 0.6f
    }

    private fun isValidPassportNumber(rawPassportNo: String?): Boolean {
        if (rawPassportNo.isNullOrBlank()) return false
        val passportNo = normalizePassportNumber(rawPassportNo)
        return hasOnlyValidPassportChars(passportNo) &&
                isValidPassportLength(passportNo) &&
                !isLikelyOcrGarbage(passportNo)
    }

    private fun containsInvalidRepeatedChars(name: String): Boolean {
        val regex = Regex("([A-Z])\\1{4,}")
        return regex.containsMatchIn(name)
    }

    fun extractPersonalNumberFromLine2(mrzLine2: String): String? {
        if (mrzLine2.length != 44) return null
        return mrzLine2.substring(28, 42)
    }

    private fun normalizeMrzName(name: String): String {
        return name
            .replace("<", " ")
            .replace("9", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .uppercase()
    }

    fun cleanName(value: String): String {
        return value.uppercase()
            .replace("<", " ")
            .replace(Regex("[^A-Z ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun sanitizeMrzRecord(record: MrzRecord): MrzRecord? {
        val allowedPattern = Regex("[A-Z0-9<]")

        fun cleanField(value: String): String {
            if (value.isBlank()) return ""
            return buildString {
                value.uppercase().forEach { ch ->
                    when {
                        allowedPattern.matches(ch.toString()) -> append(ch)
                        else -> append("<")
                    }
                }
            }.trim('<')
        }

        // "N/A" is a sentinel for "field not present," not raw MRZ text - cleanField()
        // treats '/' as filler and would mangle it into "N A", so it's passed through as-is.
        record.surname = if (record.surname == "N/A") "N/A" else decodeNameField(cleanField(record.surname))
        record.givenNames = if (record.givenNames == "N/A") "N/A" else decodeNameField(cleanField(record.givenNames))
        record.documentNumber = cleanField(record.documentNumber)
        record.nationality = cleanField(record.nationality)
        record.issuingCountry = cleanField(record.issuingCountry)
        record.personalNumber = cleanField(record.personalNumber)
        return record
    }

    private fun decodeNameField(mrz: String): String {
        val mrzNameField = mrz
            .trimEnd('<')
            .replace("<<", " ")
            .replace("<", " ")
            .trim()
        return cleanName(mrzNameField)
    }
}