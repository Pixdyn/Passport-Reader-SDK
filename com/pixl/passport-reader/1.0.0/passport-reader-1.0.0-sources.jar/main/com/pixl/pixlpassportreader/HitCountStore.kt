package com.pixl.pixlpassportreader


import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * File-backed queue of hit records awaiting upload. Using filesDir (not
 * cacheDir) so the OS never evicts it under storage pressure — pending
 * hits must not silently disappear before they're synced.
 */
class HitCountStore(context: Context) {

    private val file = File(context.applicationContext.filesDir, FILE_NAME)
    private val gson = Gson()

    suspend fun appendHit(dateIso: String, count: Int = 1) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val current = readInternal().toMutableList()
            current.add(HitDetail(dateIso, count))
            writeInternal(current)
        }
    }

    suspend fun getAll(): List<HitDetail> = withContext(Dispatchers.IO) {
        mutex.withLock { readInternal() }
    }

    /** Removes exactly the records that were successfully synced, leaving any newer ones intact. */
    suspend fun removeSynced(synced: List<HitDetail>) = withContext(Dispatchers.IO) {
        mutex.withLock {
            val current = readInternal().toMutableList()
            synced.forEach { current.remove(it) }
            writeInternal(current)
        }
    }

    private fun readInternal(): List<HitDetail> {
        if (!file.exists()) return emptyList()
        return try {
            val json = file.readText()
            if (json.isBlank()) return emptyList()
            val type = object : TypeToken<List<HitDetail>>() {}.type
            gson.fromJson<List<HitDetail>>(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeInternal(list: List<HitDetail>) {
        file.writeText(gson.toJson(list))
    }

    companion object {
        private const val FILE_NAME = "pixl_hit_queue.json"
        // Shared across instances — file I/O for this queue must be serialized process-wide.
        private val mutex = Mutex()
    }
}