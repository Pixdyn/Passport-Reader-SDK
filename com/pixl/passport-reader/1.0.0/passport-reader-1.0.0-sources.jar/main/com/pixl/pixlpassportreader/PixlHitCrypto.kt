package com.pixl.pixlpassportreader

import android.util.Base64
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256-CBC / PKCS5(=PKCS7) encryption of the API request payload — the
 * Android counterpart of the iOS SDK's PixlHitCrypto.swift.
 *
 * The Hit APIs expect the REAL request body to travel encrypted inside the
 * `Authorization: Bearer <base64(ciphertext)>` header, while the HTTP body
 * itself is either the literal empty JSON object `{}` (verify-client /
 * register-device) or the plain hitDetails JSON (update-hit-count). The
 * server decrypts the bearer value with the same shared key + IV and parses
 * the JSON out of it.
 *
 * This same primitive is also used to encrypt everything PixlHitService
 * keeps on disk (the offline hit queue, the verified-apiKey flag, the cached
 * plan snapshot) so nothing about a device's licensing state is ever stored
 * in plaintext.
 */
class PixlHitCryptoException(message: String, cause: Throwable? = null) : Exception(message, cause)

object PixlHitCrypto {

    // AES-256-CBC shared secret material (matches the backend / iOS SDK).
    // NOTE: a key shipped inside the binary is obfuscation, not secrecy — it
    // protects the payload in transit-inspection tools, but anyone who
    // reverse-engineers the SDK can recover it. That's an accepted tradeoff
    // for this licensing scheme, just don't reuse this key for anything else.
    private const val KEY_B64 = "zxEhPBwe8BhT+XudcPqez7TybRXir56o0vA8AzLAO34="
    private const val IV_B64 = "004sGNCJJI2NSfrtQcz9sA=="

    /**
     * Encrypts a JSON-safe map and returns the Base64 ciphertext that goes
     * into the `Authorization: Bearer …` header. Keys are inserted in sorted
     * order before serializing, which keeps the plaintext byte-for-byte
     * deterministic — the same trick the iOS SDK uses (`.sortedKeys`) so a
     * payload can be compared across platforms while debugging.
     */
    fun bearerToken(payload: Map<String, Any?>): String {
        val json = sortedJson(payload)
        return Base64.encodeToString(encrypt(json.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun encrypt(data: ByteArray): ByteArray = crypt(data, Cipher.ENCRYPT_MODE)

    /**
     * Not used in the request path (the server does the decrypting), but
     * this is how everything PixlHitService persists to disk/SharedPreferences
     * gets read back.
     */
    fun decrypt(data: ByteArray): ByteArray = crypt(data, Cipher.DECRYPT_MODE)

    private fun crypt(input: ByteArray, mode: Int): ByteArray {
        try {
            val keyBytes = Base64.decode(KEY_B64, Base64.NO_WRAP)
            val ivBytes = Base64.decode(IV_B64, Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(mode, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(ivBytes))
            return cipher.doFinal(input)
        } catch (e: Exception) {
            val verb = if (mode == Cipher.ENCRYPT_MODE) "encryption" else "decryption"
            throw PixlHitCryptoException("AES $verb failed: ${e.message}", e)
        }
    }

    private fun sortedJson(map: Map<String, Any?>): String {
        val sorted = LinkedHashMap<String, Any?>()
        map.keys.sorted().forEach { key -> sorted[key] = map[key] }
        // JSONObject(Map) recursively wraps nested Lists/Maps into
        // JSONArray/JSONObject and preserves LinkedHashMap insertion order.
        return JSONObject(sorted).toString()
    }
}
