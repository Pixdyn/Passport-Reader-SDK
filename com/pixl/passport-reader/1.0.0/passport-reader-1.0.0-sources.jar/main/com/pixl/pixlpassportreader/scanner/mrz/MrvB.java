package com.pixl.pixlpassportreader.scanner.mrz;


/**
 * MRV type-B format: A two lines long, 36 characters per line format
 * @author Jeremy Le Berre
 */
public class MrvB extends MrzRecord {

    private static final long serialVersionUID = 1L;

    public MrvB() {
        super(MrzFormat.MRV_VISA_B);
        code1 = 'V';
        code2 = '<';
        code = MrzDocumentCode.TypeV;
    }
    /**
     * Optional data at the discretion of the issuing State
     */
    public String optional;

    @Override
    public void fromMrz(String mrz) {
        super.fromMrz(mrz);
        final MrzParser parser = new MrzParser(mrz);
        setName(parser.parseName(new MrzRange(5, 36, 0)));
        documentNumber = parser.parseString(new MrzRange(0, 9, 1));
        validDocumentNumber = parser.checkDigit(9, 1, new MrzRange(0, 9, 1), "passport number");
        nationality = parser.parseString(new MrzRange(10, 13, 1));
        dateOfBirth = parser.parseDate(new MrzRange(13, 19, 1));
        validDateOfBirth = parser.checkDigit(19, 1, new MrzRange(13, 19, 1), "date of birth") && dateOfBirth.isDateValid();
        sex = parser.parseSex(20, 1);
        expirationDate = parser.parseDate(new MrzRange(21, 27, 1));
        validExpirationDate = parser.checkDigit(27, 1, new MrzRange(21, 27, 1), "expiration date") && expirationDate.isDateValid();
        optional = parser.parseString(new MrzRange(28, 36, 1));
        // TODO validComposite missing? (full MRZ line)
    }

    @Override
    public String toString() {
        return "MRV-B{" + super.toString() + ", optional=" + optional + '}';
    }

    @Override
    public String toMrz() {
        String sb = "V<" + MrzParser.toMrz(issuingCountry, 3) +
                MrzParser.nameToMrz(surname, givenNames, 31) +
                '\n' +
                // second line
                MrzParser.toMrz(documentNumber, 9) +
                MrzParser.computeCheckDigitChar(MrzParser.toMrz(documentNumber, 9)) +
                MrzParser.toMrz(nationality, 3) +
                dateOfBirth.toMrz() +
                MrzParser.computeCheckDigitChar(dateOfBirth.toMrz()) +
                sex.mrz +
                expirationDate.toMrz() +
                MrzParser.computeCheckDigitChar(expirationDate.toMrz()) +
                MrzParser.toMrz(optional, 8) +
                '\n';
        return sb;
    }
}
