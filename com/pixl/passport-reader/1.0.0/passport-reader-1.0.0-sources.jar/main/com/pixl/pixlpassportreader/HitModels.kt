package com.pixl.pixlpassportreader


data class DeviceInfo(
    val id: String,
    val os: String
)

data class VerifyClientRequest(
    val apiKey: String,
    val device: DeviceInfo
)

data class HitDetail(
    val date: String,
    val hitCount: Int
)

data class UpdateHitCountRequest(
    val deviceId: String,
    val apiKey: String,
    val hitDetails: List<HitDetail>
)

data class ApiResponse(
    val success: Boolean? = null,
    val message: String? = null
)

data class ApiResult(
    val httpCode: Int,
    val success: Boolean,
    val message: String?
)
