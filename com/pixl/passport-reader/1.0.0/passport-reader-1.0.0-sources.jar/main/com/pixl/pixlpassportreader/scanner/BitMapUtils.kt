package com.pixl.pixlpassportreader.scanner

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.math.abs
import kotlin.math.roundToInt

object BitmapUtils {
    fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream) // Lossless format
        return Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT)
    }
    //preprocess function
    fun preprocessBitmap(bitmap: Bitmap): Bitmap {
        // Convert to grayscale
        val grayBitmap = toGrayscale(bitmap)

        // Apply Gaussian blur
        val blurredBitmap = applyGaussianBlur(grayBitmap)

        // Apply adaptive thresholding
        val thresholdedBitmap = applyAdaptiveThresholding(blurredBitmap)

        // Denoise
        val denoisedBitmap = denoise(thresholdedBitmap)

        // Deskew (if needed) and resize
        val deskewedBitmap = correctSkew(denoisedBitmap)

        return deskewedBitmap
    }

    private fun toGrayscale(bitmap: Bitmap): Bitmap {
        val grayBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(grayBitmap)
        val paint = Paint()
        val colorMatrix = android.graphics.ColorMatrix()
        colorMatrix.setSaturation(0f)
        val filter = android.graphics.ColorMatrixColorFilter(colorMatrix)
        paint.colorFilter = filter
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        return grayBitmap
    }

    private fun applyGaussianBlur(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        Imgproc.GaussianBlur(mat, mat, Size(5.0, 5.0), 0.0) // Increased kernel size
        val blurredBitmap = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, blurredBitmap)
        return blurredBitmap
    }

    private fun applyAdaptiveThresholding(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        val grayMat = Mat()
        Imgproc.cvtColor(mat, grayMat, Imgproc.COLOR_RGBA2GRAY)

        val thresholdMat = Mat()
        Imgproc.adaptiveThreshold(grayMat, thresholdMat, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY, 15, 4.0) // Adjusted block size and constant

        val thresholdedBitmap = Bitmap.createBitmap(thresholdMat.cols(), thresholdMat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(thresholdMat, thresholdedBitmap)

        return thresholdedBitmap
    }

    private fun denoise(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        Imgproc.medianBlur(mat, mat, 3)
        val denoisedBitmap = Bitmap.createBitmap(mat.cols(), mat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, denoisedBitmap)
        return denoisedBitmap
    }
    //preporcess image adjustment


    // Helper function to convert RGB to HSL
    fun rgbToHsl(r: Int, g: Int, b: Int): FloatArray {
        val rf = r / 255.0f
        val gf = g / 255.0f
        val bf = b / 255.0f
        val max = maxOf(rf, gf, bf)
        val min = minOf(rf, gf, bf)
        val l = (max + min) / 2
        val delta = max - min
        val s = if (l > 0.5f) delta / (2.0f - max - min) else delta / (max + min)
        val h = when (max) {
            rf -> (gf - bf) / delta + (if (gf < bf) 6f else 0f)
            gf -> (bf - rf) / delta + 2f
            else -> (rf - gf) / delta + 4f
        } / 6f
        return floatArrayOf(h, s, l)
    }

    // Helper function to convert HSL to RGB
    fun hslToRgb(h: Float, s: Float, l: Float): IntArray {
        val r: Float
        val g: Float
        val b: Float

        if (s == 0.0f) {
            r = l
            g = l
            b = l
        } else {
            val q = if (l < 0.5f) l * (1 + s) else l + s - l * s
            val p = 2 * l - q
            r = hueToRgb(p, q, h + 1.0f / 3.0f)
            g = hueToRgb(p, q, h)
            b = hueToRgb(p, q, h - 1.0f / 3.0f)
        }
        return intArrayOf((r * 255).toInt(), (g * 255).toInt(), (b * 255).toInt())
    }

    // Helper function for HSL to RGB conversion
    fun hueToRgb(p: Float, q: Float, t: Float): Float {
        var tt = t
        if (tt < 0) tt += 1f
        if (tt > 1) tt -= 1f
        return when {
            tt < 1.0f / 6.0f -> p + (q - p) * 6f * tt
            tt < 1.0f / 2.0f -> q
            tt < 2.0f / 3.0f -> p + (q - p) * (2.0f / 3.0f - tt) * 6f
            else -> p
        }
    }


    fun calculateFocusScore(bitmap: Bitmap, vFocusN: Int): Float {
        val (gradientHorizontal, gradientVertical, luminanceHistogram) = calculateGradientAndHistogram(
            bitmap
        )
        val (maxGradient, rangeLow, rangeHi) = calculateMaxGradientAndRange(
            gradientHorizontal,
            gradientVertical,
            luminanceHistogram,
            vFocusN
        )
        return (maxGradient / (kotlin.math.abs(rangeHi - rangeLow) * 0.005f)).coerceAtMost(100.0f)
    }
    fun calculateMaxGradientAndRange(
        gradientHorizontal: IntArray,
        gradientVertical: IntArray,
        luminanceHistogram: IntArray,
        vFocusN: Int
    ): Triple<Int, Int, Int> {
        var maxGradient = 0

        for (i in 255 downTo 0) {
            if (gradientHorizontal[i] > 0 || gradientVertical[i] > 0) {
                maxGradient = i
                break
            }
        }

        var rangeLow = 0
        var rangeHi = 0
        var p = 0

        for (i in 0 until 256) {
            if (luminanceHistogram[i] > 0) {
                if (p + luminanceHistogram[i] > vFocusN) {
                    rangeLow += (i * (vFocusN - p))
                    p = vFocusN
                    break
                }

                p += luminanceHistogram[i]
                rangeLow += (i * luminanceHistogram[i])
            }
        }
        if (p != 0) rangeLow /= p

        p = 0
        for (i in 255 downTo 0) {
            if (luminanceHistogram[i] > 0) {
                if (p + luminanceHistogram[i] > vFocusN) {
                    rangeHi += (i * (vFocusN - p))
                    p = vFocusN
                    break
                }

                p += luminanceHistogram[i]
                rangeHi += (i * luminanceHistogram[i])
            }
        }
        if (p != 0) rangeHi /= p

        return Triple(maxGradient, rangeLow, rangeHi)
    }


    fun calculateGradientAndHistogram(bitmap: Bitmap): Triple<IntArray, IntArray, IntArray> {
        val width = bitmap.width
        val height = bitmap.height
        val gradientHorizontal = IntArray(256)
        val gradientVertical = IntArray(256)
        val luminanceHistogram = IntArray(256)

        for (i in 0 until 256) {
            gradientHorizontal[i] = 0
            gradientVertical[i] = 0
            luminanceHistogram[i] = 0
        }

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        for (nRow in 0 until height - 1) {
            val nRowOffset = nRow * width
            val nNextRowOffset = (nRow + 1) * width

            for (nCol in 0 until width - 1) {
                val gC = Color.red(pixels[nRowOffset + nCol]) // Use red as the grayscale value
                val gH = abs(gC - Color.red(pixels[nRowOffset + nCol + 1]))
                val gV = abs(gC - Color.red(pixels[nNextRowOffset + nCol]))
                luminanceHistogram[gC]++
                gradientHorizontal[gH]++
                gradientVertical[gV]++
            }
        }

        return Triple(gradientHorizontal, gradientVertical, luminanceHistogram)
    }

    fun deviceSpecificResize(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val ratio =
            if (width > height) maxDimension.toFloat() / width else maxDimension.toFloat() / height
        val scaledWidth = (ratio * width).toInt()
        val scaledHeight = (ratio * height).toInt()
        return Bitmap.createScaledBitmap(bitmap, scaledWidth, scaledHeight, true)
    }
    fun resizeBitmap(bitmap: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val aspectRatio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int

        if (width > height) {
            newWidth = maxWidth
            newHeight = (maxWidth / aspectRatio).toInt()
        } else {
            newHeight = maxHeight
            newWidth = (maxHeight * aspectRatio).toInt()
        }

        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
    fun saveBitmapToGallery(bitmap: Bitmap, context: Context): String? {
        val filename = "image_${System.currentTimeMillis()}.png"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pixlOCR")
        }

        val uri: Uri? = context.contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        )
        if (uri != null) {
            try {
                val outputStream = context.contentResolver.openOutputStream(uri)
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                    outputStream.flush()
                    outputStream.close()
                    return uri.toString()
                }
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        return null
    }
//    fun cropBitmap(inputBitmap: Bitmap, boundingBox: BoundingBox): Bitmap {
//        // Get the dimensions of the input bitmap
//        val width = inputBitmap.width
//        val height = inputBitmap.height
//
//        // Calculate the coordinates of the bounding box in pixels
//        val x1 = (boundingBox.x1 * width).roundToInt()
//        val y1 = (boundingBox.y1 * height).roundToInt()
//        val x2 = (boundingBox.x2 * width).roundToInt()
//        val y2 = (boundingBox.y2 * height).roundToInt()
//
//        // Calculate the width and height of the bounding box
//        val boundingBoxWidth = x2 - x1
//        val boundingBoxHeight = y2 - y1
//
//        // Ensure the bounding box maintains the aspect ratio
//        val aspectRatio = boundingBoxWidth.toFloat() / boundingBoxHeight.toFloat()
//        val newBoundingBoxHeight = (boundingBoxWidth / aspectRatio).roundToInt()
//        val newBoundingBoxWidth = (boundingBoxHeight * aspectRatio).roundToInt()
//
//        val croppedBitmap: Bitmap =
//            if (boundingBoxWidth.toFloat() / boundingBoxHeight > aspectRatio) {
//                // Adjust width to maintain aspect ratio
//                val offsetX = ((boundingBoxWidth - newBoundingBoxWidth) / 2).coerceAtLeast(0)
//                Bitmap.createBitmap(
//                    inputBitmap,
//                    x1 + offsetX,
//                    y1,
//                    newBoundingBoxWidth,
//                    boundingBoxHeight
//                )
//            } else {
//                // Adjust height to maintain aspect ratio
//                val offsetY = ((boundingBoxHeight - newBoundingBoxHeight) / 2).coerceAtLeast(0)
//                Bitmap.createBitmap(
//                    inputBitmap,
//                    x1,
//                    y1 + offsetY,
//                    boundingBoxWidth,
//                    newBoundingBoxHeight
//                )
//            }
//
//        return croppedBitmap
//    }

    fun cropBitmap(inputBitmap: Bitmap?, boundingBox: BoundingBox): Bitmap? {
        // Validate input
        if (inputBitmap == null || inputBitmap.isRecycled) {
            Log.e("BitmapUtils", "cropBitmap: input bitmap is null or already recycled")
            return null
        }

        val width = inputBitmap.width
        val height = inputBitmap.height

        // Clamp normalized coordinates [0.0, 1.0] to pixel values
        val x1 = (boundingBox.x1 * width).roundToInt().coerceIn(0, width - 1)
        val y1 = (boundingBox.y1 * height).roundToInt().coerceIn(0, height - 1)
        val x2 = (boundingBox.x2 * width).roundToInt().coerceIn(x1 + 1, width)
        val y2 = (boundingBox.y2 * height).roundToInt().coerceIn(y1 + 1, height)

        val cropWidth = (x2 - x1).coerceAtLeast(1)
        val cropHeight = (y2 - y1).coerceAtLeast(1)

        return try {
            // Create a safe copy in case the source gets recycled later
            val safeSource = inputBitmap.copy(Bitmap.Config.ARGB_8888, false)

            // Crop safely
            val cropped = Bitmap.createBitmap(safeSource, x1, y1, cropWidth, cropHeight)

            // Optional: ensure consistent config
            cropped.copy(Bitmap.Config.ARGB_8888, false).also {
                safeSource.recycle() // free the copy if not needed further
            }

        } catch (e: Exception) {
            Log.e("BitmapUtils", "Error cropping bitmap: ${e.message}")
            null
        }
    }

    fun correctSkew(bitmap: Bitmap, delta: Int = 1, limit: Int = 5, gaussianKernelSize: Size = Size(5.0, 5.0)): Bitmap {
        // Convert Bitmap to Mat
        val originalMat = Mat()
        Utils.bitmapToMat(bitmap, originalMat)

        // Convert image to grayscale
        val grayMat = Mat()
        Imgproc.cvtColor(originalMat, grayMat, Imgproc.COLOR_BGR2GRAY)

        // Apply Gaussian Blur to reduce noise
        val blurredMat = Mat()
        Imgproc.GaussianBlur(grayMat, blurredMat, gaussianKernelSize, 0.0)

        // Apply Histogram Equalization to enhance contrast
        val equalizedMat = Mat()
        Imgproc.equalizeHist(blurredMat, equalizedMat)

        // Threshold the image
        val threshMat = Mat()
        Imgproc.threshold(equalizedMat, threshMat, 0.0, 255.0, Imgproc.THRESH_BINARY_INV + Imgproc.THRESH_OTSU)

        // Determine the best angle to correct skew
        var bestAngle = 0.0
        var maxScore = Double.MIN_VALUE

        for (angle in -limit..limit step delta) {
            val rotatedMat = rotateMat(threshMat, angle.toDouble())
            val score = calculateScore(rotatedMat)
            if (score > maxScore) {
                maxScore = score
                bestAngle = angle.toDouble()
            }
        }

        // Correct the skew with the best angle
        val correctedMat = rotateMat(originalMat, bestAngle)

        // Convert Mat back to Bitmap
        val correctedBitmap = Bitmap.createBitmap(correctedMat.cols(), correctedMat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(correctedMat, correctedBitmap)

        return correctedBitmap
    }

    private fun rotateMat(mat: Mat, angle: Double): Mat {
        val center = Point((mat.cols() / 2).toDouble(), (mat.rows() / 2).toDouble())
        val rotationMatrix = Imgproc.getRotationMatrix2D(center, angle, 1.0)
        val rotatedMat = Mat()
        Imgproc.warpAffine(mat, rotatedMat, rotationMatrix, mat.size(), Imgproc.INTER_CUBIC, Core.BORDER_REPLICATE)
        return rotatedMat
    }

    private fun calculateScore(mat: Mat): Double {
        val histogram = IntArray(mat.rows())
        for (i in 0 until mat.rows()) {
            histogram[i] = Core.countNonZero(mat.row(i))
        }
        var score = 0.0
        for (i in 1 until histogram.size) {
            val diff = (histogram[i] - histogram[i - 1]).toDouble()
            score += diff * diff
        }
        return score
    }
}