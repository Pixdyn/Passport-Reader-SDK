package com.pixl.pixlpassportreader

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream


object TesseractManager {

    @Volatile
    private var tess: TessBaseAPI? = null

    @Volatile
    private var isInitialized = false

    // Guards init() so two near-simultaneous callers don't both build a TessBaseAPI
    private val initMutex = Mutex()

    // Guards recognize() — TessBaseAPI.setImage()/getUTF8Text() is NOT thread-safe.
    // Only one recognition can be in flight on the shared instance at a time.
    private val ocrMutex = Mutex()

    val isReady: Boolean get() = isInitialized

    suspend fun init(context: Context) {
        if (isInitialized) return

        initMutex.withLock {
            if (isInitialized) return@withLock

            withContext(Dispatchers.IO) {
                try {
                    val appContext = context.applicationContext
                    val tessDir = File(appContext.filesDir, "tessdata")
                    if (!tessDir.exists()) tessDir.mkdirs()

                    val file = File(tessDir, "mrz.traineddata")
                    if (!file.exists()) {
                        appContext.assets.open("mrz.traineddata").use { input ->
                            FileOutputStream(file).use { output -> input.copyTo(output) }
                        }
                    }

                    val api = TessBaseAPI()
                    api.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789<")
                    // MRZ crop is the full 2-line block (TD3), not a single line.
                    api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
                    api.setVariable("load_system_dawg", "F")
                    api.setVariable("load_freq_dawg", "F")
                    api.setVariable("load_punc_dawg", "F")
                    api.setVariable("load_number_dawg", "F")
                    api.setVariable("load_unambig_dawg", "F")
                    api.setVariable("load_bigram_dawg", "F")
                    api.setVariable("tessedit_do_invert", "0")

                    val success = api.init(appContext.filesDir.absolutePath, "mrz")

                    if (success) {
                        // Warm-up: Tesseract's first inference call is always noticeably
                        // slower (lazy internal allocation / dictionary loading). Eat
                        // that cost once here instead of on the user's first real scan.
                        api.setImage(Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888))
                        api.utF8Text
                        api.clear()

                        tess = api
                        isInitialized = true
                        Log.d("TesseractManager", "Tesseract initialized")
                    } else {
                        api.recycle()
                        Log.e("TesseractManager", "Tesseract init returned false")
                    }
                } catch (e: Exception) {
                    Log.e("TesseractManager", "Tesseract init error: ${e.message}", e)
                }
            }
        }
    }

    /**
     * Runs OCR on [bitmap] using the single shared TessBaseAPI instance.
     * Returns null if the engine isn't ready or recognition failed.
     */
    suspend fun recognize(bitmap: Bitmap): String? {
        val api = tess ?: return null
        return withContext(Dispatchers.Default) {
            ocrMutex.withLock {
                try {
                    api.setImage(bitmap)
                    val text = api.utF8Text
                    api.clear() // frees page-level results only; engine stays loaded
                    text
                } catch (e: Exception) {
                    Log.e("TesseractManager", "recognize error: ${e.message}", e)
                    null
                }
            }
        }
    }
}