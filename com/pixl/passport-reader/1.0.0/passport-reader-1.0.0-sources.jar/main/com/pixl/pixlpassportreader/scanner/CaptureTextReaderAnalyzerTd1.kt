package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.pixl.pixlpassportreader.TesseractManager
import com.pixl.pixlpassportreader.scanner.mrz.MrtdTd1
import com.pixl.pixlpassportreader.scanner.mrz.MrzParser
import com.pixl.pixlpassportreader.scanner.mrz.MrzRecord

/**
 * OCR + parsing pipeline for TD1 MRZs (ID cards): three lines of 30 characters each,
 * as opposed to [CaptureTextReaderAnalyzer]'s TD3 (passport) two lines of 44 characters.
 * The cleanup/validation rules mirror the ones already proven out for TD1 in another
 * project, adapted to this project's Tesseract + MrzParser pipeline.
 */
class CaptureTextReaderAnalyzerTd1(
    private val context: Context,
    private val passFoundListener: (MrzRecord) -> Unit,
    private val errorListener: (String, Boolean) -> Unit
) {

    private val TARGET_LINE_LENGTH = 30

    // Suspend, not a self-launched coroutine: the caller (MRZScanActivity.onDetect)
    // already runs this inside its own bgScope.launch. Self-launching a fresh
    // CoroutineScope(Dispatchers.IO) per call here meant an in-flight OCR call had
    // no tie to the activity's lifecycle and kept running (and could still invoke
    // passFoundListener/errorListener) even after the screen was torn down.
    suspend fun process(bitmap: Bitmap) {
        try {
            if (!TesseractManager.isReady) {
                Log.w("TESS_OCR_TD1", "Tesseract not ready yet")
                errorListener("Please scan again.", true)
                return
            }

            val extractedText = TesseractManager.recognize(bitmap)
            if (extractedText.isNullOrBlank()) {
                Log.e("TESS_OCR_TD1", "Empty OCR output")
                errorListener("Please scan again. Couldn't read from image.", true)
                return
            }

            Log.d("TESS_OCR_TD1", "OCR Output: $extractedText")
            processTextFromImage(extractedText)
        } catch (e: Exception) {
            Log.e("CaptureTextReaderTd1", "process error: ${e.message}", e)
            errorListener("Please scan again. Couldn't read from image.", true)
        }
    }

    private fun processTextFromImage(visionText: String) {
        Log.d("MRZ_RAW_TD1", visionText)

        val fullMrzString = convertToFullMrz(visionText)
        if (fullMrzString.startsWith("Error:")) {
            Log.e("MRZScanTd1", fullMrzString)
            errorListener("Please scan again. $fullMrzString", true)
            return
        }

        val lines = fullMrzString.split('\n')
        if (lines.size != 3 || lines.any { it.length < 25 }) {
            errorListener(
                "Error: MRZ incomplete or distorted. Ensure clear image and lighting.",
                true
            )
            return
        }

        val (firstLine, secondLine, thirdLine) = lines.map {
            if (it.length >= TARGET_LINE_LENGTH) it else it.padEnd(TARGET_LINE_LENGTH, '<')
        }

        checkCorrectMrzScanned(firstLine, secondLine, thirdLine)
    }

    private fun checkCorrectMrzScanned(firstLine: String, secondLine: String, thirdLine: String) {
        val isValidTd1Start = firstLine.length >= 2 &&
                (firstLine.startsWith("I<") || firstLine.startsWith("ID") ||
                        firstLine.startsWith("I<<") || firstLine.startsWith("IV") ||
                        firstLine.startsWith("A<") || firstLine.startsWith("C<") ||
                        firstLine.startsWith("V<") || firstLine.startsWith("P<") ||
                        firstLine.startsWith("PM") || firstLine.startsWith("CA") ||
                        firstLine.startsWith("AR") || firstLine.startsWith("IR") ||
                        firstLine.startsWith("IL"))

        val containsValidMrzChars = secondLine.matches(Regex("[A-Z0-9<]+")) &&
                thirdLine.matches(Regex("[A-Z<]+"))

        if (firstLine.length == TARGET_LINE_LENGTH && secondLine.length == TARGET_LINE_LENGTH &&
            thirdLine.length == TARGET_LINE_LENGTH && isValidTd1Start && containsValidMrzChars
        ) {
            try {
                val mrzText = "$firstLine\n$secondLine\n$thirdLine"
                val record = MrzParser.parse(mrzText)

                if (record == null || record.documentNumber.isNullOrBlank() ||
                    record.surname.isNullOrBlank()
                ) {
                    errorListener(
                        "Invalid MRZ: Required fields (document number or name) missing.",
                        true
                    )
                    return
                }

                if (record.surname.isEmpty()) record.surname = "N/A"
                if (record.givenNames.isEmpty()) record.givenNames = "N/A"
                record.surname = record.surname.replace("9", " ").replace("<", " ").trim()
                record.givenNames = record.givenNames.replace("9", " ").replace("<", " ").trim()

                // MrtdTd1.optional/.optional2 are populated by MrzParser.parseString(),
                // which turns a "<<" filler run into a literal ", " - a comma that trips
                // MRZScanActivity.hasInvalidChars() and silently kills the scan (this is
                // what caused the earlier "Required fields missing" failure). Overwrite
                // both with clean values pulled straight from the raw MRZ substrings -
                // same column ranges MrtdTd1.fromMrz()/toMrz() already use internally -
                // so callers get the actual optional-data content, not filler noise.
                if (record is MrtdTd1) {
                    record.optional = firstLine
                        .substring(15, minOf(30, firstLine.length))
                        .replace(Regex("[^A-Z0-9]"), "")
                    record.optional2 = secondLine
                        .substring(18, minOf(29, secondLine.length))
                        .replace(Regex("[^A-Z0-9]"), "")
                }

                // MrtdTd1 never populates the inherited personalNumber field -
                // downstream MRZScanActivity.generatePassportMRZ requires a non-null
                // String for it, so backfill it from the now-cleaned optional2 data.
                record.personalNumber = (record as? MrtdTd1)?.optional2 ?: ""

                try {
                    val issuingCountry = firstLine.substring(2, 5).replace("<", "")
                    val documentNumber =
                        firstLine.substring(5, 14).padEnd(9, '<').replace(" ", "")
                    val nationality =
                        secondLine.substring(15, 18).take(3).replace("<", "").replace(" ", "")

                    val nameLine = thirdLine.replace("<", " ").trim()
                    val names = nameLine.split("  ")
                    val surname = names.getOrNull(0)?.trim() ?: "N/A"
                    val givenNames = names.getOrNull(1)?.trim() ?: "N/A"

                    if (record.nationality.isNullOrBlank()) record.nationality = nationality
                    if (record.documentNumber.isNullOrBlank()) record.documentNumber = documentNumber
                    if (record.surname.isNullOrBlank()) record.surname = surname
                    if (record.givenNames.isNullOrBlank()) record.givenNames = givenNames
                    record.issuingCountry = issuingCountry
                } catch (e: Exception) {
                    Log.e("MRZ_FIELD_EXTRACTION_TD1", "Manual field extraction error: ${e.message}")
                }

                passFoundListener(record)
            } catch (e: Exception) {
                errorListener(
                    "Please scan again. Error in processing TD1 MRZ: ${e.message}",
                    true
                )
            }
        } else {
            val reason = when {
                firstLine.length != TARGET_LINE_LENGTH -> "L1 length (${firstLine.length})"
                secondLine.length != TARGET_LINE_LENGTH -> "L2 length (${secondLine.length})"
                thirdLine.length != TARGET_LINE_LENGTH -> "L3 length (${thirdLine.length})"
                !isValidTd1Start -> "Invalid TD1 start (${firstLine.take(2)})"
                !containsValidMrzChars -> "Contains invalid MRZ characters in line 2 or 3."
                else -> "Unknown TD1 validation issue."
            }
            errorListener("Please scan again. Invalid TD1 MRZ format or content: $reason", true)
        }
    }

    // Cleanup rules ported as-is from the other project's TD1 pipeline - tuned against
    // real-world Tesseract OCR quirks on ID card MRZs.
    private fun cleanAndPadTd1MrzLine(lineContent: String): String {
        var processedLine = lineContent
            .uppercase()
            .replace("�", "<")
            .replace(",", "<", ignoreCase = true)
            .replace("a", "Q")
            .replace(" ", "", ignoreCase = true)
            .replace("<K<", "<<<", ignoreCase = true)
            .replace("<KK<", "<<<<", ignoreCase = true)
            .replace("<KKK<", "<<<<<", ignoreCase = true)
            .replace("<KKKK<", "<<<<<<", ignoreCase = true)
            .replace("<KKKKK<", "<<<<<<<", ignoreCase = true)
            .replace("<KKKKKK<", "<<<<<<<<", ignoreCase = true)
            .replace("1N0", "IND", ignoreCase = true)
            .replace("1ND", "IND", ignoreCase = true)
            .replace("1NQ", "IND", ignoreCase = true)
            .replace("IN0", "IND", ignoreCase = true)
            .replace("INO", "IND", ignoreCase = true)
            .replace("INQ", "IND", ignoreCase = true)
            .replace("<c<", "<<<", ignoreCase = true)
            .replace("?", "<", ignoreCase = true)
            .replace("<cc<", "<<<<", ignoreCase = true)
            .replace("cc<", "<<<", ignoreCase = true)
            .replace("<ccc<", "<<<<<", ignoreCase = true)
            .replace("<ccccc<", "<<<<<<<", ignoreCase = true)
            .replace("<cccccc<", "<<<<<<<<", ignoreCase = true)
            .replace("c<<<", "<<<<", ignoreCase = true)
            .replace("<s<", "<<<", ignoreCase = true)
            .replace("<ss<", "<<<<", ignoreCase = true)
            .replace("<sss<", "<<<<<", ignoreCase = true)
            .replace("<ssss<", "<<<<<<", ignoreCase = true)
            .replace("<sssss<", "<<<<<<<", ignoreCase = true)
            .replace("<ssssss<", "<<<<<<<<", ignoreCase = true)
            .replace("00D0D00", "0000000")
            .replace("O00", "000")
            .replace("0D00000", "0000000")
            .replace("0Q000000", "0000000")
            .replace("0O0O0O0O", "00000000")
            .replace("O000", "0000")
            .replace("O000000", "0000000")
            .replace("&", "8", ignoreCase = true)
            .replace("<C<", "<<<", ignoreCase = true)
            .replace("<<C<", "<<<<", ignoreCase = true)
            .replace(Regex("[��??`~,]"), "<")
            .replace(Regex("[\\s]+"), "")
            .replace("1N[0DQ]".toRegex(), "IND")
            .replace("IN[0OQ]".toRegex(), "IND")
            .replace("UT0000", "UTO0000")
            .replace(Regex("[^A-Z0-9<]"), "<")
            .replace(Regex("<{2,}"), "<<")

        processedLine = processedLine.replace(Regex("[^A-Z0-9<]"), "<")

        return when {
            processedLine.length < TARGET_LINE_LENGTH -> processedLine.padEnd(TARGET_LINE_LENGTH, '<')
            processedLine.length > TARGET_LINE_LENGTH -> processedLine.substring(0, TARGET_LINE_LENGTH)
            else -> processedLine
        }
    }

    private fun convertToFullMrz(input: String): String {
        val cleanedLines = input
            .lines()
            .map { cleanAndPadTd1MrzLine(it.trim()) }
            .take(3)

        if (cleanedLines.size < 3) {
            return "Error: Not enough valid MRZ lines (found ${cleanedLines.size})"
        }

        return cleanedLines.joinToString("\n")
    }
}
