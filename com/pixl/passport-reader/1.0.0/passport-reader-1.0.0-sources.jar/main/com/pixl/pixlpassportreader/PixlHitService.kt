package com.pixl.pixlpassportreader

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.provider.Settings
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * Stable, per-device identifier for the Hit/licensing APIs — the Android
 * counterpart of the iOS SDK's PixlDeviceIdentity.swift. ANDROID_ID is scoped
 * to (device, user, signing key), requires no permission, and — unlike a
 * UUID stashed in SharedPreferences — survives the app being uninstalled and
 * reinstalled, which is exactly the property the iOS Keychain-backed UUID is
 * there for.
 */
object PixlDeviceIdentity {
    @SuppressLint("HardwareIds")
    fun stableDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown-device"
}

/** Mirrors iOS's PixlClientStatus. */
enum class PixlClientStatus {
    EXISTING_USER,
    NEW_USER,
    /** Registration already confirmed on a previous launch — no network call was made at all. */
    ALREADY_REGISTERED
}

/**
 * A 200-OK envelope with status "Failed" carries the server's own error code
 * (ERR001, ERR002, ERR003, …) and message — also used for the *locally
 * cached* equivalent of ERR002 (plan expired) / ERR003 (hit limit exceeded)
 * when PixlHitService can catch those before ever making a network call.
 * Mirrors iOS's PixlHitServiceError.
 */
class PixlHitServiceException(val code: String, message: String) : Exception(message) {
    companion object {
        const val NO_API_KEY = "SDK_NO_API_KEY"
        const val BAD_RESPONSE = "SDK_BAD_RESPONSE"
        const val NETWORK_ERROR = "SDK_NETWORK_ERROR"
    }
}

/**
 * Cached snapshot of the plan mapping, as last reported by the server.
 * Refreshed from the `data` object on every verify-client, register-device,
 * or update-hit-count response — success or failure — and used to gate
 * scanning locally (expiry, remaining hits) without a network round-trip.
 * Mirrors iOS's PixlPlanInfo.
 */
data class PixlPlanInfo(
    var planStartDate: String? = null,
    var planEndDate: String? = null,
    var planType: String? = null,
    var totalHitCount: Int? = null,
    var remainingHitCount: Int? = null,
    var totalDeviceCount: Int? = null,
    var remainingDeviceCount: Int? = null
)

/**
 * Licensing / usage-metering flow against accounts-dev.pixl.ai — the Android
 * counterpart of the iOS SDK's PixlHitService.swift, matching the same flow:
 *
 *   SDK entry ──▶ verified flag (encrypted, persisted) matches THIS apiKey?
 *                   ├─ yes ──▶ skip verify-client entirely BUT still check
 *                   │          the locally cached plan (expiry / remaining
 *                   │          hits) before letting the scan proceed
 *                   └─ no  ──▶ verify-client
 *                                ├─ status "Success"            ─▶ persist ─▶ continue
 *                                ├─ ERR007 "not registered"     ─▶ register-device
 *                                │      ├─ "Success" ─▶ persist ─▶ continue
 *                                │      └─ Failed    ─▶ throw → caller alerts, closes
 *                                └─ ERR001 / ERR002 / ERR003 / any error ─▶ throw
 *   Scan finished ──▶ hit payload ENCRYPTED IMMEDIATELY and appended to a
 *                     local file, and the locally cached remainingHitCount is
 *                     decremented right away so an offline device can't keep
 *                     scanning past its plan's limit before the next flush
 *                     reports it. At flush time every stored ciphertext is
 *                     decrypted, grouped by the (apiKey, deviceId) it was
 *                     recorded under, and each group's hitDetails are
 *                     flattened into ONE array and sent in a SINGLE
 *                     update-hit-count call with a FRESH bearer token — the
 *                     server rejects timestamps older than ±5 minutes, so
 *                     stored tokens can't be replayed verbatim. A
 *                     ConnectivityManager callback re-triggers the flush the
 *                     moment connectivity returns.
 *
 * Wire format / error codes / envelope shape are identical to the iOS SDK —
 * see PixlHitService.swift for the full contract notes.
 */
object PixlHitService {

    private const val TAG = "PixlHitService"
    private const val BASE_URL = "https://accounts-dev.pixl.ai/api/Hit/"
    private const val DEVICE_OS = "android"

    private const val ERR_DEVICE_NOT_REGISTERED = "ERR007"

    private lateinit var appContext: Context
    private var apiKey: String = ""

    private val deviceId: String by lazy { PixlDeviceIdentity.stableDeviceId(appContext) }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    private val gson = Gson()
    private val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val stateMutex = Mutex()
    private var isFlushing = false

    private var monitorRegistered = false

    private val prefs by lazy {
        appContext.getSharedPreferences("pixl_hit_service", Context.MODE_PRIVATE)
    }

    private val pendingHitsFile: File by lazy {
        File(appContext.filesDir, "pixl_pending_hits.json")
    }

    private const val KEY_VERIFIED_APIKEY = "pixl.hit.verifiedApiKey"
    private const val KEY_PLAN_INFO = "pixl.hit.planInfo"

    // ===== Configuration =====

    /** Call once — e.g. at Activity entry, before startSession(). */
    fun configure(context: Context, apiKey: String) {
        this.appContext = context.applicationContext
        this.apiKey = apiKey
        startNetworkMonitorIfNeeded()
    }

    /**
     * True when the currently configured apiKey has already been verified on
     * some previous launch. Lets the caller skip straight to starting the
     * scanner instead of always routing through verifyClientThenStart().
     */
    val isVerified: Boolean
        get() = ::appContext.isInitialized && isRegistered(apiKey)

    // ===== Registration cache (SharedPreferences, encrypted) =====

    /**
     * A different stored key (key rotation by the host app) reads as NOT
     * registered, which is precisely what forces verify-client to run again
     * — exactly once — for the newly shared key.
     */
    private fun isRegistered(key: String): Boolean {
        if (key.isEmpty()) return false
        return decryptedString(KEY_VERIFIED_APIKEY) == key
    }

    private fun persistRegistration(key: String) {
        encryptAndStore(KEY_VERIFIED_APIKEY, key)
    }

    // ===== Local plan cache (SharedPreferences, encrypted, apiKey-scoped) =====

    /** Ties a stored plan snapshot to the apiKey that produced it, exactly like isRegistered(). */
    private data class StoredPlanInfo(val apiKey: String, val planInfo: PixlPlanInfo)

    private fun loadPlanInfo(): PixlPlanInfo? {
        if (apiKey.isEmpty()) return null
        val json = decryptedString(KEY_PLAN_INFO) ?: return null
        return try {
            val stored = gson.fromJson(json, StoredPlanInfo::class.java)
            if (stored?.apiKey == apiKey) stored.planInfo else null
        } catch (e: Exception) {
            null
        }
    }

    private fun savePlanInfo(info: PixlPlanInfo) {
        if (apiKey.isEmpty()) return
        encryptAndStore(KEY_PLAN_INFO, gson.toJson(StoredPlanInfo(apiKey, info)))
    }

    /**
     * Merges the `data` object of any envelope (success OR failure — ERR007
     * carries `data` too) into the cached plan snapshot. Fields absent from a
     * given response are left untouched.
     */
    private fun updatePlanInfo(json: JSONObject) {
        val data = json.optJSONObject("data") ?: return
        val info = loadPlanInfo() ?: PixlPlanInfo()
        if (data.has("planStartDate")) info.planStartDate = data.optString("planStartDate")
        if (data.has("planEndDate")) info.planEndDate = data.optString("planEndDate")
        if (data.has("planType")) info.planType = data.optString("planType")
        if (data.has("totalHitCount")) info.totalHitCount = data.optInt("totalHitCount")
        if (data.has("remainingHitCount")) info.remainingHitCount = data.optInt("remainingHitCount")
        if (data.has("totalDeviceCount")) info.totalDeviceCount = data.optInt("totalDeviceCount")
        if (data.has("remainingDeviceCount")) info.remainingDeviceCount = data.optInt("remainingDeviceCount")
        savePlanInfo(info)
    }

    private fun isPlanExpiredLocally(): Boolean {
        val endDateString = loadPlanInfo()?.planEndDate ?: return false
        val endDate = parseServerDate(endDateString) ?: return false
        return endDate.before(Date())
    }

    private fun isHitLimitExceededLocally(): Boolean {
        val remaining = loadPlanInfo()?.remainingHitCount ?: return false
        return remaining <= 0
    }

    /**
     * The local, zero-network equivalent of an exhausted plan — checked at
     * startSession() (including the "already registered" fast path) so an
     * expired plan or exhausted hit budget stops the SDK before the camera
     * ever opens.
     *
     * Only the hit-limit case reuses the server's real "ERR003" code, since
     * that's genuinely the same condition update-hit-count would report.
     * Plan expiry has no confirmed server error code of its own (per the
     * current API doc, ERR002 means "Invalid API Key" — a different failure
     * — so it must NOT be reused here), hence the distinct SDK-side code.
     */
    private fun localPlanBlockError(): PixlHitServiceException? {
        if (isPlanExpiredLocally()) {
            return PixlHitServiceException("SDK_PLAN_EXPIRED", "No active plan exists.")
        }
        if (isHitLimitExceededLocally()) {
            return PixlHitServiceException("ERR003", "Hit count limit has been exceeded.")
        }
        return null
    }

    // ===== Flow entry: verify (+ register) only when needed =====

    /**
     * Call at SDK entry, BEFORE the camera flow proceeds — mirrors iOS's
     * `startSession()` / `verifyClientThenStart()`.
     *
     * - Already registered with this key → checked against the LOCAL plan
     *   cache (expiry / remaining hits); if it passes, returns
     *   ALREADY_REGISTERED with zero network calls (works fully offline). If
     *   the cache says the plan is expired or hits are exhausted, throws
     *   immediately — same as a live server rejection would.
     * - Not registered (first launch, or the apiKey changed) → verify-client.
     *   "Success" means this device is already registered server-side;
     *   ERR007 means it isn't, so register-device is called automatically.
     *   Success on either path persists the key and refreshes the plan cache.
     * - ERR001/ERR002/ERR003, any HTTP/network failure, or a register-device
     *   failure all throw PixlHitServiceException — the caller must alert,
     *   hand errorJson(for:) to the parent app, and close the SDK.
     */
    suspend fun startSession(): PixlClientStatus = withContext(Dispatchers.IO) {
        if (!::appContext.isInitialized || apiKey.isEmpty()) {
            throw PixlHitServiceException(
                PixlHitServiceException.NO_API_KEY,
                "No API key configured. Call PixlHitService.configure(context, apiKey) before starting a scan."
            )
        }

        if (isRegistered(apiKey)) {
            localPlanBlockError()?.let { throw it }
            flushHits()
            return@withContext PixlClientStatus.ALREADY_REGISTERED
        }

        // This device has never been verified, so verify-client/register-device
        // MUST reach the server - there's no cached registration to fall back
        // to. If the network itself is the problem (no internet, DNS/timeout),
        // report it the same way an ERR007 "not registered" response would be
        // reported, rather than surfacing a raw network/timeout error the host
        // app has no code to branch on.
        val verifyResult = try {
            verifyClient()
        } catch (e: PixlHitServiceException) {
            throw remapUnreachableToDeviceNotRegistered(e)
        }

        when (verifyResult) {
            VerifyOutcome.REGISTERED -> {
                persistRegistration(apiKey)
                localPlanBlockError()?.let { throw it }
                flushHits()
                PixlClientStatus.EXISTING_USER
            }
            VerifyOutcome.NEEDS_REGISTRATION -> {
                try {
                    registerDevice() // throws on Failed
                } catch (e: PixlHitServiceException) {
                    throw remapUnreachableToDeviceNotRegistered(e)
                }
                persistRegistration(apiKey)
                localPlanBlockError()?.let { throw it }
                flushHits()
                PixlClientStatus.NEW_USER
            }
        }
    }

    /**
     * Only remaps a NETWORK_ERROR (unreachable server / timeout / no
     * internet) - a real server response (ERR002, ERR003, …) is never
     * touched here, it's already correctly coded.
     */
    private fun remapUnreachableToDeviceNotRegistered(e: PixlHitServiceException): PixlHitServiceException =
        if (e.code == PixlHitServiceException.NETWORK_ERROR) {
            PixlHitServiceException(ERR_DEVICE_NOT_REGISTERED, "Device is not registered")
        } else {
            e
        }

    /**
     * JSON error payload for the parent app:
     * {"success":false,"errorCode":"ERR002","error":"No active plan exists."}
     * Mirrors iOS's `errorJSON(for:)`.
     */
    fun errorJson(error: Throwable): String {
        val fields = JSONObject()
        fields.put("success", false)
        if (error is PixlHitServiceException) {
            fields.put("errorCode", error.code)
            fields.put("error", error.message ?: "Verification failed.")
        } else {
            fields.put("errorCode", "SDK_ERROR")
            fields.put("error", error.message ?: "Verification failed.")
        }
        return fields.toString()
    }

    // ===== Flow exit: hits =====

    /**
     * Record one successful use (one completed scan). The stored payload is
     * AES-encrypted RIGHT NOW before touching disk, so the on-disk queue only
     * ever contains ciphertext. The locally cached remainingHitCount is
     * decremented in the same breath, so an offline device can't keep
     * scanning past its budget before the next flush reports these hits.
     */
    fun recordHit(date: Date = Date()) {
        if (!::appContext.isInitialized || apiKey.isEmpty()) return

        val payload = linkedMapOf<String, Any?>(
            "apiKey" to apiKey,
            "deviceId" to deviceId,
            "timestamp" to isoTimestampSeconds(date),
            "hitDetails" to listOf(
                linkedMapOf("date" to isoTimestampSeconds(date), "hitCount" to 1)
            )
        )

        val token = try {
            PixlHitCrypto.bearerToken(payload)
        } catch (e: Exception) {
            Log.w(TAG, "recordHit: failed to encrypt payload: ${e.message}")
            return
        }

        ioScope.launch { recordHitLocked(token) }
    }

    /** Convenience for the common exit path: one scan just finished. */
    fun recordHitAndFlush() {
        recordHit()
        flushHits()
    }

    private suspend fun recordHitLocked(token: String) {
        stateMutex.withLock {
            val tokens = loadPendingTokens().toMutableList()
            tokens.add(token)
            savePendingTokens(tokens)

            loadPlanInfo()?.let { info ->
                val remaining = info.remainingHitCount
                if (remaining != null) {
                    info.remainingHitCount = maxOf(0, remaining - 1)
                    savePlanInfo(info)
                }
            }
        }
    }

    /** One decrypted, not-yet-delivered hit, plus the token it came from. */
    private data class DecodedHit(
        val token: String,
        val apiKey: String,
        val deviceId: String,
        val hitDetails: List<Map<String, Any?>>
    )

    /**
     * Delivers every stored encrypted hit in as few network calls as
     * possible: decrypts everything, groups by the (apiKey, deviceId) pair
     * captured at scan time, and sends each group's hitDetails flattened
     * into ONE update-hit-count call. Fire-and-forget by design — metering
     * must never block the scan result from reaching the host app.
     */
    fun flushHits() {
        if (!::appContext.isInitialized || apiKey.isEmpty() || !isRegistered(apiKey)) return

        ioScope.launch {
            val shouldStart = stateMutex.withLock {
                if (isFlushing) false else {
                    isFlushing = true
                    true
                }
            }
            if (!shouldStart) return@launch

            try {
                val tokens = stateMutex.withLock { loadPendingTokens() }
                if (tokens.isEmpty()) return@launch

                val decoded = mutableListOf<DecodedHit>()
                val poison = mutableListOf<String>()
                tokens.forEach { token ->
                    val hit = decodeStoredHit(token)
                    if (hit != null) decoded.add(hit) else poison.add(token)
                }
                if (poison.isNotEmpty()) {
                    removeTokens(poison)
                    Log.w(TAG, "Discarded ${poison.size} undecodable stored hit token(s)")
                }

                val groups = decoded.groupBy { "${it.apiKey}|${it.deviceId}" }
                for ((_, group) in groups) {
                    val first = group.firstOrNull() ?: continue
                    val flattened = group.flatMap { it.hitDetails }
                    try {
                        sendBatchedHits(first.apiKey, first.deviceId, flattened)
                        removeTokens(group.map { it.token })
                        Log.d(TAG, "Delivered ${group.size} stored hit(s) in one update-hit-count call")
                    } catch (e: Exception) {
                        // This group's hits stay stored and are retried on the next flush
                        // (e.g. ERR003 — usage is still reported once the plan renews).
                        Log.w(TAG, "Hit flush stopped for one group (will retry later): ${e.message}")
                    }
                }
            } finally {
                stateMutex.withLock { isFlushing = false }
            }
        }
    }

    private fun decodeStoredHit(token: String): DecodedHit? {
        return try {
            val cipher = Base64.decode(token, Base64.NO_WRAP)
            val plain = PixlHitCrypto.decrypt(cipher)
            val payload = JSONObject(String(plain, Charsets.UTF_8))
            val hitDetailsArray = payload.optJSONArray("hitDetails") ?: return null
            val hitDetails = (0 until hitDetailsArray.length()).map { i ->
                val entry = hitDetailsArray.getJSONObject(i)
                linkedMapOf<String, Any?>("date" to entry.optString("date"), "hitCount" to entry.optInt("hitCount"))
            }
            DecodedHit(
                token = token,
                apiKey = payload.optString("apiKey").ifBlank { apiKey },
                deviceId = payload.optString("deviceId").ifBlank { deviceId },
                hitDetails = hitDetails
            )
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun removeTokens(tokensToRemove: List<String>) {
        if (tokensToRemove.isEmpty()) return
        stateMutex.withLock {
            val remaining = loadPendingTokens().toMutableList()
            val removeSet = tokensToRemove.toSet()
            remaining.removeAll { it in removeSet }
            savePendingTokens(remaining)
        }
    }

    /**
     * Sends one update-hit-count call carrying every queued hitDetails entry
     * for a given (apiKey, deviceId) pair. apiKey/deviceId here are whatever
     * was captured AT SCAN TIME, but the bearer's timestamp is always
     * generated NOW to satisfy the server's ±5-minute window.
     */
    private fun sendBatchedHits(hitApiKey: String, hitDeviceId: String, hitDetails: List<Map<String, Any?>>) {
        if (hitDetails.isEmpty()) return

        val bodyJson = JSONObject(linkedMapOf<String, Any?>("hitDetails" to hitDetails)).toString()
        val bearerPayload = linkedMapOf<String, Any?>(
            "apiKey" to hitApiKey,
            "deviceId" to hitDeviceId,
            "timestamp" to isoTimestampSeconds(Date())
        )
        val bearer = PixlHitCrypto.bearerToken(bearerPayload)

        val json = post("update-hit-count", bearer, bodyJson)
        requireSuccessEnvelope(json)
    }

    // ===== Pending-token file helpers (call only while holding stateMutex) =====

    private fun loadPendingTokens(): List<String> {
        if (!pendingHitsFile.exists()) return emptyList()
        return try {
            val json = pendingHitsFile.readText()
            if (json.isBlank()) emptyList()
            else {
                val type = object : TypeToken<List<String>>() {}.type
                gson.fromJson<List<String>>(json, type) ?: emptyList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun savePendingTokens(tokens: List<String>) {
        if (tokens.isEmpty()) {
            // All offline-stored hits delivered — clear the encrypted data entirely.
            pendingHitsFile.delete()
            return
        }
        pendingHitsFile.writeText(gson.toJson(tokens))
    }

    // ===== Network monitor (auto-flush when connectivity returns) =====

    private fun startNetworkMonitorIfNeeded() {
        if (monitorRegistered) return
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Internet just became available — drain the offline queue.
                flushHits()
            }
        }
        try {
            cm.registerNetworkCallback(request, callback)
            monitorRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register network callback: ${e.message}")
        }
    }

    // ===== Individual API calls =====

    private enum class VerifyOutcome {
        REGISTERED,        // status "Success" — device known to server
        NEEDS_REGISTRATION // ERR007 / isDeviceRegistered == 0
    }

    private fun verifyClient(): VerifyOutcome {
        val json = post("verify-client", PixlHitCrypto.bearerToken(basePayload()))
        return parseVerifyResponse(json)
    }

    private fun registerDevice() {
        val json = post("register-device", PixlHitCrypto.bearerToken(basePayload()))
        requireSuccessEnvelope(json)
    }

    // ===== Request plumbing =====

    /**
     * The plaintext that gets AES-encrypted into the bearer header:
     * { "apiKey": …, "deviceId": …, "deviceOs": …, "timestamp": ISO-8601 }.
     * Timestamp is generated at SEND time; the server rejects requests whose
     * timestamp differs from its clock by more than 5 minutes.
     */
    private fun basePayload(): Map<String, Any?> = linkedMapOf(
        "apiKey" to apiKey,
        "deviceId" to deviceId,
        "deviceOs" to DEVICE_OS,
        "timestamp" to isoTimestamp(Date())
    )

    /**
     * POSTs to `<base>/<endpoint>` with the encrypted bearer token. Body
     * defaults to the literal empty object `{}` (verify-client and
     * register-device); update-hit-count passes its plain JSON body.
     */
    private fun post(endpoint: String, bearerToken: String, bodyJson: String = "{}"): JSONObject {
        val requestBody = bodyJson.toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url("$BASE_URL$endpoint")
            .post(requestBody)
            .addHeader("Accept", "*/*")
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", "Bearer $bearerToken")
            .build()

        val response = try {
            client.newCall(request).execute()
        } catch (e: Exception) {
            throw PixlHitServiceException(PixlHitServiceException.NETWORK_ERROR, e.message ?: "Network error")
        }

        response.use { resp ->
            val bodyText = resp.body?.string().orEmpty()
            Log.d(TAG, "$endpoint -> ${resp.code}: $bodyText")

            if (!resp.isSuccessful) {
                throw PixlHitServiceException("HTTP_${resp.code}", "Licensing server returned HTTP ${resp.code}: $bodyText")
            }
            if (bodyText.isBlank()) return JSONObject()
            return try {
                JSONObject(bodyText)
            } catch (e: Exception) {
                throw PixlHitServiceException(
                    PixlHitServiceException.BAD_RESPONSE,
                    "The licensing server returned a response that could not be parsed."
                )
            }
        }
    }

    // ===== Response parsing (documented envelope) =====

    /** Envelope: { status: "Success"|"Failed", message, data, error: {code, errorMessage} } */
    private fun envelopeError(json: JSONObject): Pair<String, String> {
        val errorObject = json.optJSONObject("error")
        val code = errorObject?.optString("code")?.takeIf { it.isNotBlank() } ?: "UNKNOWN"
        val message = errorObject?.optString("errorMessage")?.takeIf { it.isNotBlank() }
            ?: json.optString("message").takeIf { it.isNotBlank() }
            ?: "The licensing server rejected the request."
        return code to message
    }

    private fun isSuccessEnvelope(json: JSONObject): Boolean =
        json.optString("status").equals("Success", ignoreCase = true)

    /**
     * verify-client outcomes:
     *   status "Success"                       → device already registered
     *   status "Failed" + ERR007 (or data.isDeviceRegistered == 0) → register-device
     *   status "Failed" + anything else        → hard failure (ERR001/002/003, …)
     * Also refreshes the local plan cache from `data` before deciding.
     */
    private fun parseVerifyResponse(json: JSONObject): VerifyOutcome {
        updatePlanInfo(json)

        if (isSuccessEnvelope(json)) return VerifyOutcome.REGISTERED

        val (code, message) = envelopeError(json)
        if (code == ERR_DEVICE_NOT_REGISTERED) return VerifyOutcome.NEEDS_REGISTRATION

        val data = json.optJSONObject("data")
        val hasError = json.has("error") && !json.isNull("error")
        if (data != null && data.has("isDeviceRegistered") && data.optInt("isDeviceRegistered") == 0 && !hasError) {
            return VerifyOutcome.NEEDS_REGISTRATION
        }

        throw PixlHitServiceException(code, message)
    }

    /**
     * register-device and update-hit-count: anything other than status
     * "Success" is a failure carrying the envelope's error. Also refreshes
     * the local plan cache from `data` whenever present.
     */
    private fun requireSuccessEnvelope(json: JSONObject) {
        updatePlanInfo(json)
        if (json.length() == 0) return // 2xx with empty body — accept
        if (!isSuccessEnvelope(json)) {
            val (code, message) = envelopeError(json)
            throw PixlHitServiceException(code, message)
        }
    }

    // ===== Formatting helpers =====

    /** With fractional seconds — matches the verify/register doc sample. */
    private fun isoTimestamp(date: Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(date)
    }

    /** Seconds precision, no fractional part — matches the update-hit-count samples. */
    private fun isoTimestampSeconds(date: Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(date)
    }

    /** Parses planStartDate/planEndDate — tries seconds precision first, then fractional. */
    private fun parseServerDate(value: String): Date? {
        for (pattern in listOf("yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                return sdf.parse(value)
            } catch (e: Exception) {
                // try next pattern
            }
        }
        return null
    }

    // ===== Encrypted SharedPreferences helpers =====

    private fun decryptedString(prefKey: String): String? {
        val base64 = prefs.getString(prefKey, null) ?: return null
        return try {
            String(PixlHitCrypto.decrypt(Base64.decode(base64, Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    private fun encryptAndStore(prefKey: String, plainText: String) {
        try {
            val cipher = PixlHitCrypto.encrypt(plainText.toByteArray(Charsets.UTF_8))
            prefs.edit().putString(prefKey, Base64.encodeToString(cipher, Base64.NO_WRAP)).apply()
        } catch (e: Exception) {
            Log.w(TAG, "encryptAndStore failed for $prefKey: ${e.message}")
        }
    }
}
