package com.pixl.pixlpassportreader.scanner
import android.os.Handler
import android.os.Looper
import android.util.Log
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class HttpRequest  {

    companion object {

        val apikey: String = "RiIQlKCJulsiOSIdIrb5zxwASJawIklBNRbQcMxVT2wD0BB8"
        val baseURL: String = "https://dev-saas-platform.pixl.ai/api/Hit/"
        val auth_verify_client: String = "dX3G9z!rA#5yP@V2&MkN7qL\$wT8C6bF%JpZ"
        val auth_hit_count: String = "B5tY@W#K2qM!Z8G&X7L9pV%R6F\$J3zCA"

        fun verifyClient(deviceId: String, callback: (JSONObject?) -> Unit) {
            val client = OkHttpClient()
            val url = "${baseURL}verify-client"

            val json = JSONObject().apply {
                put("apiKey", apikey)
                put("device", JSONObject().apply {
                    put("id", deviceId)
                    put("os", "android")
                })
            }

            val requestBody = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val request = Request.Builder().url(url).post(requestBody)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", auth_verify_client)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("API_ERROR", "Failed to verify client: ${e.message}")
                    callback(null)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.body?.string()?.let { responseBody ->
                        Log.d("API_RESPONSE", "Client Verification Response: $responseBody")
                        try {
                            val jsonResponse = JSONObject(responseBody)
                            Handler(Looper.getMainLooper()).post {
                                callback(jsonResponse)
                            }
                        } catch (e: JSONException) {
                            Log.e("API_ERROR", "JSON Parsing error: ${e.message}")
                            callback(null)
                        }
                    } ?: callback(null)
                }
            })
        }

        fun updateHitCount(date: String, remainHitcount: Int ,deviceId: String,callback: (JSONObject?) -> Unit) {
            val client = OkHttpClient()
            val url = "${baseURL}update-hit-count"

            val hitDetailsArray = JSONArray().apply {
                put(JSONObject().apply { put("date", date); put("hitCount", remainHitcount) })
            }

            val json = JSONObject().apply {
                put("deviceId", deviceId)
                put("apiKey", apikey)
                put("hitDetails", hitDetailsArray)
            }

            val requestBody = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val request = Request.Builder().url(url).post(requestBody)
                .addHeader("Content-Type", "application/json")
                .addHeader("Authorization", auth_hit_count)
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    Log.e("API_ERROR", "Failed to update hit count: ${e.message}")
                    callback(null)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.body?.string()?.let { responseBody ->
                        Log.d("API_RESPONSE", "Update Hit Count Response: $responseBody")
                        try {
                            val jsonResponse = JSONObject(responseBody)
                            Handler(Looper.getMainLooper()).post {
                                callback(jsonResponse)
                            }
                        } catch (e: JSONException) {
                            Log.e("API_ERROR", "JSON Parsing error: ${e.message}")
                            callback(null)
                        }
                    } ?: callback(null)
                }
            })
        }
    }
}

