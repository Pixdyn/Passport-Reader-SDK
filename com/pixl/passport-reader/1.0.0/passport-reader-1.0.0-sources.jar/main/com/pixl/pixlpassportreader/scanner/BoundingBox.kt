package com.pixl.pixlpassportreader.scanner

data class BoundingBox(
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val cnf: Float,
    val cls: Int,
    val clsName: String
) {
    fun isValid(): Boolean {
        return !x1.isNaN() && !y1.isNaN() && !x2.isNaN() && !y2.isNaN() && !cx.isNaN() && !cy.isNaN() && !w.isNaN() && !h.isNaN()
    }
}