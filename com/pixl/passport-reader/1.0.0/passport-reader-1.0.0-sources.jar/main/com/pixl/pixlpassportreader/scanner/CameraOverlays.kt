package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CameraOverlays @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val blackPaint = Paint().apply {
        color = Color.BLACK
        alpha = (0.6f * 255).toInt()
    }

    private val whiteStrokePaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4.dpToPx().toFloat()
    }

    private val textPaint = Paint().apply {
        color = Color.WHITE
        textSize = 24.dpToPx().toFloat()
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), blackPaint)

        val rect = RectF(0f, height / 2f, width.toFloat(), height.toFloat())
        canvas.drawRect(rect, whiteStrokePaint)

        val text = "Powered by"
        val poweredByText = "Pixl"
        val textX = width / 2f
        val textY = height - 20.dpToPx().toFloat()
        canvas.drawText(text, textX, textY, textPaint)


        val poweredByTextWidth = textPaint.measureText(poweredByText)
        canvas.drawText(
            poweredByText,
            textX + poweredByTextWidth / 2,
            textY,
            textPaint.apply { alpha = 128 }
        )
    }

    private fun Int.dpToPx(): Int {
        val scale = resources.displayMetrics.density
        return (this * scale + 0.5f).toInt()
    }
}