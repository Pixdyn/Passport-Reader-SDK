package com.pixl.pixlpassportreader.scanner

import android.app.ActivityManager
import android.content.Context
import android.os.Build

object DevicePerf {
    lateinit var tier: DeviceTier
        private set

    fun init(context: Context) {
        if (::tier.isInitialized) return
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        if (am.isLowRamDevice) { tier = DeviceTier.LOW; return }
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGB = mem.totalMem / (1024L * 1024L * 1024L)
        val cores = Runtime.getRuntime().availableProcessors()
        tier = when {
            ramGB >= 6 && cores >= 8 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> DeviceTier.HIGH
            ramGB >= 4 -> DeviceTier.MID
            else -> DeviceTier.LOW
        }
    }

    val analysisResolution get() = when (tier) {
        DeviceTier.HIGH -> android.util.Size(1920, 1440)
        DeviceTier.MID  -> android.util.Size(1280, 960)
        DeviceTier.LOW  -> android.util.Size(960, 720)
    }
    val inferenceIntervalMs get() = when (tier) {
        DeviceTier.HIGH -> 80L
        DeviceTier.MID  -> 150L
        DeviceTier.LOW  -> 280L
    }
    val detectorThreads get() = when (tier) {
        DeviceTier.HIGH -> 4; DeviceTier.MID -> 3; DeviceTier.LOW -> 2
    }
    val mrzTargetMinDim get() = when (tier) {
        DeviceTier.HIGH -> 1000; DeviceTier.MID -> 800; DeviceTier.LOW -> 640
    }
    val maxUpscale get() = when (tier) {
        DeviceTier.HIGH -> 3.0; DeviceTier.MID -> 2.5; DeviceTier.LOW -> 2.0
    }
}