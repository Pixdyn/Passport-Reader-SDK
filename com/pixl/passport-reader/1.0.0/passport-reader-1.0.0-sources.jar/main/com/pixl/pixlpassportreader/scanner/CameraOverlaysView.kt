package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class CameraOverlaysView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    // ---- Paints ----

//    private val overlayPaint = Paint().apply {
//        color = Color.argb(200, 0, 0, 0) // Dark semi-transparent scrim
//    }

    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#80000000") // 50% black
    }
    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }
    private val transparentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.TRANSPARENT
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 131, 91, 255) // Purple #835BFF
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    // MRZ zone box (the "ALIGN MRZ DATA" area)
    private val mrzZoneFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 131, 91, 255) // Faint purple tint
        style = Paint.Style.FILL
    }

    private val mrzZoneBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 131, 91, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val mrzTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 200, 200, 210) // Light gray
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.15f
    }

    // ---- Config ----

    private val paddingDp = 20f
    private val cutoutCornerRadiusDp = 24f   // Rounded corners of the cutout
//    private val cornerLengthDp = 20f         // Length of each corner bracket arm
    private val horizontalCornerLengthDp = 24f
    private val verticalCornerLengthDp = 10f
    private val mrzZonePaddingDp = 12f       // MRZ box inset from cutout sides/bottom
    private val mrzZoneHeightRatio = 0.28f   // MRZ box height relative to cutout height
    private val mrzTextSizeSp = 13f

    private var isCaptured = false
    private var fullBorderWidthPx = 12f

    private val clearPath = Path()
    private val cornerPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val density = resources.displayMetrics.density
        val paddingPx = paddingDp * density
        val cornerRadiusPx = cutoutCornerRadiusDp * density
//        val cornerLenPx = cornerLengthDp * density
        val horizontalLenPx = horizontalCornerLengthDp * density
        val verticalLenPx = verticalCornerLengthDp * density

        // 1. Dark scrim over the whole screen
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)

        // 2. Cutout rectangle — centered, document ratio
        val rectWidth = width - (2 * paddingPx)
        val rectHeight = rectWidth / 1.585f
        val centerX = width / 2f
        val centerY = height / 2f
        val rect = RectF(
            centerX - rectWidth / 2, centerY - rectHeight / 2,
            centerX + rectWidth / 2, centerY + rectHeight / 2
        )

        // 3. Punch the transparent camera window
        clearPath.reset()
        clearPath.addRoundRect(rect, cornerRadiusPx, cornerRadiusPx, Path.Direction.CW)
        canvas.drawPath(clearPath, transparentPaint)

        // 4. Purple corners only
        if (isCaptured) {
            cornerPaint.strokeWidth = fullBorderWidthPx
            canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, cornerPaint)
        } else {
            cornerPaint.strokeWidth = 10f
//            drawCornerBrackets(canvas, rect, cornerRadiusPx, cornerLenPx)
            drawCornerBrackets(
                canvas,
                rect,
                cornerRadiusPx,
                horizontalLenPx,
                verticalLenPx
            )
        }
    }

    /**
     * Draws the four rounded corner brackets around [rect], following its
     * rounded corners with radius [radius] and arm length [len].
     */
    private fun drawCornerBrackets(
        canvas: Canvas,
        rect: RectF,
        radius: Float,
        horizontalLen: Float,
        verticalLen: Float
    ) {
        cornerPath.reset()

        // Top-left
        cornerPath.moveTo(rect.left, rect.top + radius + verticalLen)
        cornerPath.lineTo(rect.left, rect.top + radius)
        cornerPath.arcTo(
            rect.left, rect.top, rect.left + 2 * radius, rect.top + 2 * radius,
            180f, 90f, false
        )
        cornerPath.lineTo(rect.left + radius + horizontalLen, rect.top)

        // Top-right
        cornerPath.moveTo(rect.right - radius - horizontalLen, rect.top)
        cornerPath.lineTo(rect.right - radius, rect.top)
        cornerPath.arcTo(
            rect.right - 2 * radius, rect.top, rect.right, rect.top + 2 * radius,
            270f, 90f, false
        )
        cornerPath.lineTo(rect.right, rect.top + radius + verticalLen)
        // Bottom-right
        cornerPath.moveTo(rect.right, rect.bottom - radius - verticalLen)
        cornerPath.lineTo(rect.right, rect.bottom - radius)
        cornerPath.arcTo(
            rect.right - 2 * radius, rect.bottom - 2 * radius, rect.right, rect.bottom,
            0f, 90f, false
        )
        cornerPath.lineTo(rect.right - radius - horizontalLen, rect.bottom)
        // Bottom-left
        cornerPath.moveTo(rect.left + radius + horizontalLen, rect.bottom)
        cornerPath.lineTo(rect.left + radius, rect.bottom)
        cornerPath.arcTo(
            rect.left, rect.bottom - 2 * radius, rect.left + 2 * radius, rect.bottom,
            90f, 90f, false
        )
        cornerPath.lineTo(rect.left, rect.bottom - radius - verticalLen)

        canvas.drawPath(cornerPath, cornerPaint)
    }

    fun setCaptured(captured: Boolean) {
        isCaptured = captured
        invalidate()
    }

    /** Full document cutout rect (view coordinates). */
    fun getOverlayRect(): Rect {
        val density = resources.displayMetrics.density
        val paddingPx = paddingDp * density
        val rectWidth = width - (2 * paddingPx)
        val rectHeight = rectWidth / 1.585f
        val centerX = width / 2f
        val centerY = height / 2f

        return Rect(
            (centerX - rectWidth / 2).toInt(),
            (centerY - rectHeight / 2).toInt(),
            (centerX + rectWidth / 2).toInt(),
            (centerY + rectHeight / 2).toInt()
        )
    }

    /** MRZ alignment zone rect (view coordinates) — useful for validating detections. */
    fun getMrzZoneRect(): Rect {
        val density = resources.displayMetrics.density
        val overlay = getOverlayRect()
        val mrzPaddingPx = (mrzZonePaddingDp * density).toInt()
        val mrzZoneHeight = ((overlay.height()) * mrzZoneHeightRatio).toInt()

        return Rect(
            overlay.left + mrzPaddingPx,
            overlay.bottom - mrzPaddingPx - mrzZoneHeight,
            overlay.right - mrzPaddingPx,
            overlay.bottom - mrzPaddingPx
        )
    }
}