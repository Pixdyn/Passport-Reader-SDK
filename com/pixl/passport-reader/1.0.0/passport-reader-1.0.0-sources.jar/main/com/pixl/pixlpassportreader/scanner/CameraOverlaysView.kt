package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.view.View
import com.pixl.pixlpassportreader.R

class CameraOverlaysView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val overlayPaint = Paint().apply {
        color = Color.argb(200, 0, 0, 0) // Darker semi-transparent gray
    }

    private val transparentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.TRANSPARENT
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    private val cornerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
//        Color.argb(255, (0.208f * 255).toInt(), (0.698f * 255).toInt(), (0.922f * 255).toInt())
        color = Color.argb(255, 131, 91, 255)
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val paddingDp = 20f
    private var isCaptured = false
    private var fullBorderWidthPx = 12f

    private val personOverlayBitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.person_overlay_img)
    private val mrzLineBitmap: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.mrz_lines)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val density = resources.displayMetrics.density
        val paddingPx = paddingDp * density
        val cornerWidthPx = 67f * density // Corner width in pixels
        val cornerHeightPx = 67f * density // Corner height in pixels

        // Fill the screen with gray
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), overlayPaint)

        // Calculate the dimensions of the rectangle
        val rectWidth = width - (2 * paddingPx) // Width with padding
        val rectHeight = rectWidth / 1.585f // Height based on credit card ratio
        val centerX = width / 2f
        val centerY = height / 2f

        // Define the rectangle bounds
        val left = centerX - rectWidth / 2
        val top = centerY - rectHeight / 2
        val right = centerX + rectWidth / 2
        val bottom = centerY + rectHeight / 2

        // Draw the transparent sharp-edged rectangle
        val rect = RectF(left, top, right, bottom)
        canvas.drawRect(rect, transparentPaint)

        if (isCaptured) {
            // Draw a full rectangle border after capture
            cornerPaint.strokeWidth = fullBorderWidthPx
            canvas.drawRect(rect, cornerPaint)
        } else {
            // Draw corner line indicators
            // Top-left corner
            canvas.drawLine(left, top, left + cornerWidthPx, top, cornerPaint)
            canvas.drawLine(left, top, left, top + cornerHeightPx, cornerPaint)

            // Top-right corner
            canvas.drawLine(right, top, right - cornerWidthPx, top, cornerPaint)
            canvas.drawLine(right, top, right, top + cornerHeightPx, cornerPaint)

            // Bottom-left corner
            canvas.drawLine(left, bottom, left + cornerWidthPx, bottom, cornerPaint)
            canvas.drawLine(left, bottom, left, bottom - cornerHeightPx, cornerPaint)

            // Bottom-right corner
            canvas.drawLine(right, bottom, right - cornerWidthPx, bottom, cornerPaint) // Horizontal
            canvas.drawLine(right, bottom, right, bottom - cornerHeightPx, cornerPaint) // Vertical
        }
        val screenWidth = canvas.width
        val screenHeight = canvas.height

        if (screenWidth == 0 || screenHeight == 0) {
            Log.e("Error", "Canvas dimensions are invalid")
            return
        }

        if (personOverlayBitmap == null) {
            Log.e("Error", "Person overlay bitmap is null")
            return
        }

        val personOverlayWidth = (screenWidth * 0.2).toInt()
        val personOverlayHeight = (personOverlayBitmap.height * personOverlayWidth / personOverlayBitmap.width.toFloat()).toInt() // Maintain aspect ratio

        val scaledPersonOverlayBitmap = Bitmap.createScaledBitmap(personOverlayBitmap, personOverlayWidth, personOverlayHeight, true)

        val leftPadding = (screenWidth * 0.15).toFloat()
        val topPadding = (screenHeight * 0.2).toFloat()

        val personOverlayLeft = leftPadding // Dynamic left padding
        val personOverlayTop = centerY - rectHeight / 3 - scaledPersonOverlayBitmap.height / 2 + topPadding // Dynamic top padding

        canvas.drawBitmap(scaledPersonOverlayBitmap, personOverlayLeft, personOverlayTop, null)

        val mrzscreenWidth = canvas.width
        val mrzscreenHeight = canvas.height

        val mrzLineWidth = (mrzscreenWidth * 0.8).toInt()
        val mrzLineHeight = (mrzLineBitmap.height * mrzLineWidth / mrzLineBitmap.width)

        val scaledMrzLineBitmap = Bitmap.createScaledBitmap(mrzLineBitmap, mrzLineWidth, mrzLineHeight, true)

        val padding = 20 * density

        val mrzLineLeft = centerX - scaledMrzLineBitmap.width / 2
        val mrzLineTop = bottom - scaledMrzLineBitmap.height - padding

        canvas.drawBitmap(scaledMrzLineBitmap, mrzLineLeft, mrzLineTop, null)

    }

    fun setCaptured(captured: Boolean) {
        isCaptured = captured
        invalidate()
    }

    fun getOverlayRect(): Rect {
        val density = resources.displayMetrics.density
        val paddingPx = paddingDp * density
        val rectWidth = width - (2 * paddingPx)
        val rectHeight = rectWidth / 1.585f
        val centerX = width / 2f
        val centerY = height / 2f

        // Define the rectangle bounds in view coordinates
        val left = (centerX - rectWidth / 2).toInt()
        val top = (centerY - rectHeight / 2).toInt()
        val right = (centerX + rectWidth / 2).toInt()
        val bottom = (centerY + rectHeight / 2).toInt()
        return Rect(left, top, right, bottom)
    }
}
