package com.pixl.pixlpassportreader.scanner.mrz.additionaldetails;

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object MRZUtils {
    fun calculateMonthsToExpire(expirationDate: String): String {
        try {
            // Split the expiration date into day, month, and year parts
            val expiryParts = expirationDate.split("/")

            // Check if there are exactly three parts (day, month, year) in the input
            if (expiryParts.size != 3) {
                return "Invalid date format. Please scan again. "
            }

            // Parse day, month, and year from the input
            val expiryDay = expiryParts[0].toInt()
            val expiryMonth = expiryParts[1].toInt()
            val expiryYear = expiryParts[2].toInt()

            // Get the current date
            val currentDate = Calendar.getInstance()

            // Create a Calendar instance for the expiry date
            val expiryDate = Calendar.getInstance()
            expiryDate.set(expiryYear, expiryMonth - 1, expiryDay) // Month is 0-based

            // Calculate the difference in years and months
            var yearsDiff = expiryYear - currentDate.get(Calendar.YEAR)
            var monthsDiff = expiryMonth - (currentDate.get(Calendar.MONTH) + 1) // Month is 0-based

            // Adjust the difference if the day of expiry is earlier in the month than the current day
            if (expiryDay < currentDate.get(Calendar.DAY_OF_MONTH)) {
                monthsDiff--
            }

            // Calculate the total months to expire
            val totalMonths = yearsDiff * 12 + monthsDiff

            // Check if the expiry date is in the past
            return if (totalMonths < 0) {
                "Expired"
            } else {
                totalMonths.toString()
            }
        } catch (e: Exception) {
            // Handle any exceptions that might occur during the operation
            return "Please scan again. Error in processing."
        }
    }
    fun extractCode(code: String, passportType: String): String {
        val regex = Regex("""\[(.*?)\]""")
        val matchResult = regex.find(code)
        val extractedCode = matchResult?.groups?.get(1)?.value ?: "N/A"
        return when {
            extractedCode == "PM" -> extractedCode
            extractedCode == "PN" -> extractedCode
            extractedCode == "PC" -> extractedCode
            extractedCode == "PS" -> extractedCode
            extractedCode == "PL" -> extractedCode
            extractedCode.startsWith("P") -> passportType
            // Non-passport codes (e.g. "IL" for ID cards) aren't in the P-prefixed
            // subtype list above - surface the actual 2-char code rather than
            // collapsing to just code1, which previously showed "I" instead of "IL".
            extractedCode != "N/A" -> extractedCode
            else -> passportType
        }
    }
    fun isExpired(expirationDate: String): Boolean {
        try {
            // Parse the expiration date
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val expiryDate = dateFormat.parse(expirationDate)

            // Get the current date
            val currentDate = Calendar.getInstance().time

            // Compare expiration date with current date
            return expiryDate != null && expiryDate.before(currentDate)
        } catch (e: Exception) {
            // Log any parsing errors
            Log.e("ExpirationDate", "Error parsing expiration date: $expirationDate", e)
            // Return true if there's an error, assuming the date is expired
            return true
        }
    }
    fun calculateAge(dob: String): String {
        try {
            val dobParts = dob.split("/")

            // Check if there are exactly three parts (day, month, year) in the input
            if (dobParts.size != 3) {
                return "Please scan again. Invalid date of birth format."
            }

            val day = dobParts[0].toInt()
            val month = dobParts[1].toInt()
            val year = dobParts[2].toInt()

            // Check if the month is within the valid range (1 to 12)
            if (month < 1 || month > 12) {
                return "Please scan again. Invalid month."
            }

            // Assuming year should be greater than 0 (Adjust this condition based on your requirements)
            if (year <= 0) {
                return "Please scan again. Invalid year."
            }

            val today = Calendar.getInstance()
            val birthDate = Calendar.getInstance()
            birthDate.set(year, month - 1, day) // Month is 0-based

            var age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR)
            if (today.get(Calendar.DAY_OF_YEAR) < birthDate.get(Calendar.DAY_OF_YEAR)) {
                age--
            }

            return age.toString() // Return the calculated age as a string
        } catch (e: Exception) {
            val dobParts = dob.split("/")

            // Check if there are exactly three parts (day, month, year) in the input
            if (dobParts.size != 3) {
                return "Please scan again. Invalid date of birth format."
            }

            val day = dobParts[0].toInt()
            val month = dobParts[1].toInt()
            val year = dobParts[2].toInt()

            // Check if the month is within the valid range (1 to 12)
            if (month < 1 || month > 12) {
                return "Please scan again. Invalid month."
            }

            // Assuming year should be greater than 0 (Adjust this condition based on your requirements)
            if (year <= 0) {
                return "Please scan again. Invalid year."
            }
            return "Please scan again. Error in processing."
        }
    }
    fun cleanName(name: String): String {
        // Replace '0' with 'o', remove non-alphabetic characters except spaces, and convert to uppercase
        val cleanedName = name.replace("0", "o", ignoreCase = true)
            .replace(Regex("[^a-zA-Z ]"), "")
            .uppercase()

        // Split the name by two or more spaces and take the first part
        val parts = cleanedName.split(Regex("\\s{2,}"))
        return parts.firstOrNull() ?: cleanedName
    }
    fun formatPassportNumber(documentNumber: String?, countryCode: String): String {
        try {
            // Define a set of country codes that use alphanumeric passport numbers
            val countriesWithFirstAlphabets = setOf(
                "AFG", "AGO", "AUS", "AUT", "AZE", "BGB", "BOL", "BIH", "CHN",
                "CUB", "CYB", "EGY", "SLV", "GHA", "HND", "ISL", "IND", "IRN",
                "IRQ", "JAM", "KAZ", "KEN", "MYS", "MDV", "MLI", "MDA", "NGA",
                "PRT", "SYC", "SGP", "SOM", "LKA", "SDN", "CHE", "EGY", "TUN",
                "TUR", "TKM", "VNM"
            )
            val countriesWithFirstTwoAlphabets = setOf(
                "ARM", "BGD", "BLR", "BEL", "BWA", "BRA", "MMR", "CAN", "COL", "DOM",
                "EST", "ETH", "FIN", "EAA/GRC", "HUN", "IDN", "IRL", "ITA", "JPN",
                "KGZ", "LVA", "MWI", "MRT", "MAR", "NZL", "PAK", "POL", "SVK", "SVN",
                "KOR", "THA", "TTO", "UGA", "UKR", "UTO", "UZB", "ZMB", "ZIM"
            )
            val countriesNumbersOnly = setOf(
                "DZA", "BHR", "BGR", "BDI", "CMR", "HRV", "CZE", "DNK", "ECU",
                "LTU", "D", "GTM", "GBR", "KWT", "LBN", "LTU", "MLT", "MUS",
                "NPL", "NOR", "OMN", "PSE", "PER", "QAT", "ROU", "RUS", "SRB",
                "SWE", "SYR", "TWN", "USA", "GBR", "VEN", "YEM"
            )

            val countryWithAlphaNumericPassNumAsLast = setOf("ARG")

            if (countriesWithFirstAlphabets.contains(countryCode)) {
                documentNumber?.let {
                    val modifiedPassportNumber = StringBuilder(it)
                    if (it.isNotEmpty()) {
                        val firstChar = it[0]
                        when (firstChar) {
                            '2' -> modifiedPassportNumber.setCharAt(0, 'Z')
                            '0', ')' -> modifiedPassportNumber.setCharAt(0, 'O')
                            '8' -> modifiedPassportNumber.setCharAt(0, 'B')
                            '1' -> modifiedPassportNumber.setCharAt(0, 'I')
                            '5' -> modifiedPassportNumber.setCharAt(0, 'S')
                            '(' -> modifiedPassportNumber.setCharAt(0, 'C')
                        }
                    }
                    return modifiedPassportNumber.toString()
                }
            }
            return documentNumber ?: ""
        } catch (e: Exception) {
            // Handle any exceptions that might occur during the operation
            Log.e("FormatPassportNumber", "Error formatting passport number: ${e.message}")
            // Return the original document number in case of an exception
            return documentNumber ?: ""
        }
    }
    fun formatDate(date: String): String {
        try {
            val parts = date.split("/")
            val day = parts[0].toInt()
            val month = parts[1].toInt()
            val year = parts[2].padStart(2, '0')

            // Check if day or month is greater than the maximum allowed values
            if (day > 31 || month > 12 || day < 1 || month < 1) {
                return "-1" // Return -1 if day or month is invalid
            }

            val fullYear = when {
                year.toInt() <= 40 -> "20$year" // Assume 21st century
                else -> "19$year" // Assume 20th century
            }

            // Pad day and month with leading zeros if necessary
            val formattedDay = day.toString().padStart(2, '0')
            val formattedMonth = month.toString().padStart(2, '0')

            return "$formattedDay/$formattedMonth/$fullYear"
        } catch (e: Exception) {
            return ""
        }
    }
}