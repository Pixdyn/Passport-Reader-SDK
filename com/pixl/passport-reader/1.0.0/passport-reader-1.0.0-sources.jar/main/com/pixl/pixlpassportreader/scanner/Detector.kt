package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.pixl.pixlpassportreader.scanner.BoundingBox
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.nnapi.NnApiDelegate
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader

class Detector(
    private val context: Context,
    private val modelPath: String,
    private val labelPath: String,
    private val detectorListener: DetectorListener
) {

    private var interpreter: Interpreter? = null
    private var labels = mutableListOf<String>()
    private var tensorWidth = 0
    private var tensorHeight = 0
    private var numChannel = 0
    private var numElements = 0
    private var maxConfidenceImage: Bitmap? = null
    private var nnApiDelegate: NnApiDelegate? = null

    private val imageProcessor = ImageProcessor.Builder()
        .add(NormalizeOp(INPUT_MEAN, INPUT_STANDARD_DEVIATION))
        .add(CastOp(INPUT_IMAGE_TYPE))
        .build()

    // Method to retrieve the maximum confidence image
    fun getMaxConfidenceImage(): Bitmap? {
        return maxConfidenceImage
    }

    private fun updateMaxConfidenceImage(resultBitmap: Bitmap) {
        try {
            if (maxConfidenceImage == null || calculateConfidence(resultBitmap) > calculateConfidence(maxConfidenceImage!!)) {
                maxConfidenceImage?.recycle() // Release previous Bitmap
                maxConfidenceImage = resultBitmap.config?.let { resultBitmap.copy(it, true) }
            }
        } catch (e: Exception) {
            Log.e("Detector", "Error in updateMaxConfidenceImage: ${e.message}")
        }
    }

    fun setup() {
        try {
            val model = FileUtil.loadMappedFile(context, modelPath)
            val options = Interpreter.Options()
            // Ensure the interpreter only uses CPU
            options.setUseXNNPACK(true)
            options.numThreads =
                if (Runtime.getRuntime().availableProcessors() <= 4) 2 else 4
            interpreter = Interpreter(model, options)

            val inputShape = interpreter?.getInputTensor(0)?.shape() ?: return
            val outputShape = interpreter?.getOutputTensor(0)?.shape() ?: return

            tensorWidth = inputShape[1]
            tensorHeight = inputShape[2]
            numChannel = outputShape[1]
            numElements = outputShape[2]

            loadLabels()
        } catch (e: IOException) {
            Log.e("Detector", "Error in setup: ${e.message}")
        }
    }

    fun clear() {
        interpreter?.close()
        interpreter = null
        nnApiDelegate?.close()
        nnApiDelegate = null
        maxConfidenceImage?.recycle() // Release maxConfidenceImage Bitmap
        maxConfidenceImage = null
    }

    @Synchronized
    fun detect(frame: Bitmap?) {
        try {
            if (frame == null) {
                detectorListener.onEmptyDetect()
                return
            }

            if (interpreter == null || tensorWidth == 0 || tensorHeight == 0 || numChannel == 0 || numElements == 0) {
                detectorListener.onEmptyDetect()
                return
            }

            var inferenceTime = SystemClock.uptimeMillis()

            val resizedBitmap = Bitmap.createScaledBitmap(frame, tensorWidth, tensorHeight, true)
            val tensorImage = TensorImage(DataType.FLOAT32)
            tensorImage.load(resizedBitmap)
            val processedImage = imageProcessor.process(tensorImage)
            val imageBuffer = processedImage.buffer

            val output = TensorBuffer.createFixedSize(intArrayOf(1, numChannel, numElements), OUTPUT_IMAGE_TYPE)

            // Run TensorFlow Lite inference
            interpreter?.run(imageBuffer, output.buffer)

            val bestBoxes = bestBox(output.floatArray)
            inferenceTime = SystemClock.uptimeMillis() - inferenceTime

            if (bestBoxes.isNullOrEmpty()) {
                detectorListener.onEmptyDetect()
                return
            }

            if (bestBoxes.any { it.cnf > 0.75f }) {
                maxConfidenceImage?.recycle()
                maxConfidenceImage = resizedBitmap.copy(Bitmap.Config.ARGB_8888, false)
            }
            detectorListener.onDetect(bestBoxes,  frame)
        } catch (e: Exception) {
            Log.e("Detector", "Error in detect: ${e.message}")
            detectorListener.onEmptyDetect()
        }
    }

    private fun loadLabels() {
        try {
            val inputStream: InputStream = context.assets.open(labelPath)
            val reader = BufferedReader(InputStreamReader(inputStream))

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                if (line!!.isNotEmpty()) {
                    labels.add(line!!)
                }
            }
            reader.close()
            inputStream.close()
        } catch (e: IOException) {
            Log.e("Detector", "Error in loadLabels: ${e.message}")
        }
    }

    private fun calculateConfidence(bitmap: Bitmap): Float {
        var sum = 0.0f
        for (x in 0 until bitmap.width) {
            for (y in 0 until bitmap.height) {
                val pixel = bitmap.getPixel(x, y)
                sum += (pixel shr 16 and 0xFF) + (pixel shr 8 and 0xFF) + (pixel and 0xFF)
            }
        }
        return sum / (bitmap.width * bitmap.height * 255.0f)
    }

    private fun bestBox(array: FloatArray): List<BoundingBox>? {
        val boundingBoxes = mutableListOf<BoundingBox>()

        for (c in 0 until numElements) {
            var maxConf = -1.0f
            var maxIdx = -1
            var j = 4
            var arrayIdx = c + numElements * j
            while (j < numChannel) {
                if (array[arrayIdx] > maxConf) {
                    maxConf = array[arrayIdx]
                    maxIdx = j - 4
                }
                j++
                arrayIdx += numElements
            }

            if (maxConf > CONFIDENCE_THRESHOLD) {
                val clsName = labels[maxIdx]
                val cx = array[c]
                val cy = array[c + numElements]
                val w = array[c + numElements * 2]
                val h = array[c + numElements * 3]
                val x1 = cx - (w / 2F)
                val y1 = cy - (h / 2F)
                val x2 = cx + (w / 2F)
                val y2 = cy + (h / 2F)

                if (x1 < 0F || x1 > 1F || y1 < 0F || y1 > 1F || x2 < 0F || x2 > 1F || y2 < 0F || y2 > 1F) {
                    continue
                }

                boundingBoxes.add(
                    BoundingBox(
                        x1 = x1, y1 = y1, x2 = x2, y2 = y2,
                        cx = cx, cy = cy, w = w, h = h,
                        cnf = maxConf, cls = maxIdx, clsName = clsName
                    )
                )
            }
        }

        if (boundingBoxes.isEmpty()) return null

        return applyNMS(boundingBoxes)
    }

    private fun applyNMS(boxes: List<BoundingBox>): MutableList<BoundingBox> {
        val sortedBoxes = boxes.sortedByDescending { it.cnf }.toMutableList()
        val selectedBoxes = mutableListOf<BoundingBox>()

        while (sortedBoxes.isNotEmpty()) {
            val first = sortedBoxes.first()
            selectedBoxes.add(first)
            sortedBoxes.remove(first)

            val iterator = sortedBoxes.iterator()
            while (iterator.hasNext()) {
                val nextBox = iterator.next()
                val iou = calculateIoU(first, nextBox)
                if (iou >= IOU_THRESHOLD) {
                    iterator.remove()
                }
            }
        }

        return selectedBoxes
    }

    private fun calculateIoU(box1: BoundingBox, box2: BoundingBox): Float {
        val x1 = maxOf(box1.x1, box2.x1)
        val y1 = maxOf(box1.y1, box2.y1)
        val x2 = minOf(box1.x2, box2.x2)
        val y2 = minOf(box1.y2, box2.y2)
        val intersectionArea = maxOf(0F, x2 - x1) * maxOf(0F, y2 - y1)
        val box1Area = box1.w * box1.h
        val box2Area = box2.w * box2.h
        return intersectionArea / (box1Area + box2Area - intersectionArea)
    }

    interface DetectorListener {
        fun onEmptyDetect()
        fun onDetect(boundingBoxes: List<BoundingBox>, rotatedBitmap: Bitmap)
    }

    companion object {
        private const val INPUT_MEAN = 0f
        private const val INPUT_STANDARD_DEVIATION = 255f
        private val INPUT_IMAGE_TYPE = DataType.FLOAT32
        private val OUTPUT_IMAGE_TYPE = DataType.FLOAT32
        private const val CONFIDENCE_THRESHOLD = 0.3F
        private const val IOU_THRESHOLD = 0.9F
    }
}