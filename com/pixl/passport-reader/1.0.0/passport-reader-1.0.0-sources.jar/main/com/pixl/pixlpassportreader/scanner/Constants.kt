package com.pixl.pixlpassportreader.scanner

object Constants {
    const val MODEL_PATH = "model.tflite"
    const val LABELS_PATH = "labels.txt"
    const val VFOCUS_N = 1000
    const val SOME_THRESHOLD = 60
    const val REQUEST_CODE_PERMISSIONS = 10
    const val TAG = "Camera"
    const val FRAME_SKIP_COUNT = 1
}