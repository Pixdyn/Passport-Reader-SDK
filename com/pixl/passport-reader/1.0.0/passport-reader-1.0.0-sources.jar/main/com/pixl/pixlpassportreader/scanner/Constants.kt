package com.pixl.pixlpassportreader.scanner

object Constants {
    // model1/labels1 replace the old passport-only detector: this model additionally
    // classifies the MRZ zone as mrz_2_line (TD3 passports) or mrz_3_line (TD1 ID cards).
    const val MODEL_PATH = "model1.tflite"
    const val LABELS_PATH = "labels1.txt"
    const val VFOCUS_N = 1000
    const val SOME_THRESHOLD = 60
    const val REQUEST_CODE_PERMISSIONS = 10
    const val TAG = "Camera"
    const val FRAME_SKIP_COUNT = 1
}