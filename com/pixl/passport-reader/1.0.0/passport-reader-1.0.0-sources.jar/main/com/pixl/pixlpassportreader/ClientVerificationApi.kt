package com.pixl.pixlpassportreader

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Implements the /verify-client and /register-device handshake: the plaintext
 * {apiKey, deviceId, deviceOs, timestamp} payload is AES-256-CBC encrypted and sent
 * as the bearer token, per the SaaS platform's client-verification contract.
 */
object ClientVerificationApi {

    private const val TAG = "ClientVerificationApi"
    private const val BASE_URL = "https://accounts-dev.pixl.ai/api/Hit/"

    // Fixed per the API contract - not a per-request secret.
    private const val SECRET_KEY_B64 = "zxEhPBwe8BhT+XudcPqez7TybRXir56o0vA8AzLAO34="
    private const val IV_B64 = "004sGNCJJI2NSfrtQcz9sA=="

    private const val ERR_DEVICE_NOT_REGISTERED = "ERR007"
    private const val ERR_HIT_LIMIT_EXCEEDED = "ERR003"
    private const val ERR_INVALID_API_KEY = "ERR002"

    private val client = OkHttpClient()

    data class PlanData(
        val planStartDate: String = "",
        val planEndDate: String = "",
        val planType: String = "",
        val totalHitCount: Int = 0,
        val remainingHitCount: Int = 0,
        val totalDeviceCount: Int = 0,
        val remainingDeviceCount: Int = 0
    )

    sealed class VerifyResult {
        data class Success(val data: PlanData?) : VerifyResult()
        data class DeviceNotRegistered(val data: PlanData?) : VerifyResult()
        data class HitLimitExceeded(val message: String) : VerifyResult()
        data class InvalidApiKey(val message: String) : VerifyResult()
        data class Failure(val reason: String) : VerifyResult()
    }

    suspend fun verifyClient(apiKey: String, deviceId: String): VerifyResult =
        callEndpoint("verify-client", apiKey, deviceId)

    suspend fun registerDevice(apiKey: String, deviceId: String): VerifyResult =
        callEndpoint("register-device", apiKey, deviceId)

    private suspend fun callEndpoint(path: String, apiKey: String, deviceId: String): VerifyResult =
        withContext(Dispatchers.IO) {
            try {
                Log.d(TAG, "$path called with apiKey=$apiKey, deviceId=$deviceId")
                val token = buildEncryptedToken(apiKey, deviceId)
                Log.d(TAG, "TOKEN: Bearer $token")
                val requestBody = "{}".toRequestBody("application/json".toMediaTypeOrNull())
                val request = Request.Builder()
                    .url("$BASE_URL$path")
                    .post(requestBody)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("Authorization", "Bearer $token")
                    .build()

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    Log.d(TAG, "$path -> ${response.code}: $body")
                    parseResponse(body)
                }
            } catch (e: Exception) {
                Log.e(TAG, "$path failed: ${e.message}", e)
                VerifyResult.Failure(e.message ?: "Network error")
            }
        }

    private fun parseResponse(body: String): VerifyResult {
        if (body.isBlank()) return VerifyResult.Failure("Empty response from server")

        val json = JSONObject(body)
        val status = json.optString("status")
        val error = json.optJSONObject("error")
        val data = json.optJSONObject("data")?.let { d ->
            PlanData(
                planStartDate = d.optString("planStartDate"),
                planEndDate = d.optString("planEndDate"),
                planType = d.optString("planType"),
                totalHitCount = d.optInt("totalHitCount"),
                remainingHitCount = d.optInt("remainingHitCount"),
                totalDeviceCount = d.optInt("totalDeviceCount"),
                remainingDeviceCount = d.optInt("remainingDeviceCount")
            )
        }

        if (error == null && status.equals("Success", ignoreCase = true)) {
            return VerifyResult.Success(data)
        }

        val errorMessage = error?.optString("errorMessage")?.takeIf { it.isNotBlank() }

        return when (error?.optString("code")) {
            ERR_DEVICE_NOT_REGISTERED -> VerifyResult.DeviceNotRegistered(data)
            ERR_HIT_LIMIT_EXCEEDED ->
                VerifyResult.HitLimitExceeded(errorMessage ?: "Hit count limit has been exceeded.")
            ERR_INVALID_API_KEY ->
                VerifyResult.InvalidApiKey(errorMessage ?: "Invalid API Key.")
            else -> VerifyResult.Failure(errorMessage ?: "Client verification failed")
        }
    }

    private fun buildEncryptedToken(apiKey: String, deviceId: String): String {
        val payload = JSONObject().apply {
            put("apiKey", apiKey)
            put("deviceId", deviceId)
            put("deviceOs", "android")
            put("timestamp", nowIso())
        }.toString()

        val keyBytes = Base64.decode(SECRET_KEY_B64, Base64.NO_WRAP)
        val ivBytes = Base64.decode(IV_B64, Base64.NO_WRAP)

        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(ivBytes))
        val encrypted = cipher.doFinal(payload.toByteArray(Charsets.UTF_8))

        return Base64.encodeToString(encrypted, Base64.NO_WRAP)
    }

    private fun nowIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }
}
