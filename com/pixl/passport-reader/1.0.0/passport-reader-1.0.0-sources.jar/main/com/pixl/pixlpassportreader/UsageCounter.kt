package com.pix.pixscanner.Usage


//import android.content.Context
//import android.util.Log
//import java.io.File
//import java.io.IOException
//
//
//
//class UsageCounter(private val context: Context) {
//    private val usageFile: File = File(context.filesDir, "usage_count.txt")
//    private val USAGE_LIMIT = 1000
//
//    init {
//        if (!usageFile.exists()) {
//            try {
//                usageFile.createNewFile()
//                writeUsageCount(0)
//            } catch (e: IOException) {
//                e.printStackTrace()
//            }
//        }
//    }
//
//    fun incrementUsage(): Boolean {
//        var usageCount = readUsageCount()
//        if (usageCount >= USAGE_LIMIT) {
//            return false
//        }
//        Log.e("Usage Count", "${usageCount}")
//        usageCount++
//        writeUsageCount(usageCount)
//        return true
//    }
//
//    fun getUsageCount(): Int {
//        return readUsageCount()
//    }
//
//    fun resetUsage() {
//        writeUsageCount(0)
//    }
//
//    private fun readUsageCount(): Int {
//        return try {
//            usageFile.readText().toInt()
//        } catch (e: IOException) {
//            e.printStackTrace()
//            0
//        } catch (e: NumberFormatException) {
//            e.printStackTrace()
//            0
//        }
//    }
//
//    private fun writeUsageCount(count: Int) {
//        try {
//            usageFile.writeText(count.toString())
//        } catch (e: IOException) {
//            e.printStackTrace()
//        }
//    }
//
//    fun getUsageFilePath(): String {
//        return usageFile.absolutePath
//    }
//}

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class UsageCounter(private val context: Context) {
    private val usageFile: File = File(context.filesDir, "usage_data.json")
    public val USAGE_LIMIT: Int = 0
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    init {
        if (!usageFile.exists()) {
            try {
                usageFile.createNewFile()
                writeUsageData(JSONArray())
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    fun incrementUsage(): Boolean {
        val usageData = readUsageData()
        val todayDate = dateFormat.format(Date())
        var todayUsage = getUsageForDate(todayDate, usageData)

        if (todayUsage >= USAGE_LIMIT) {
            return false
        }

        todayUsage++
        updateUsageForDate(todayDate, todayUsage, usageData)
        writeUsageData(usageData)
        return true
    }

    fun getUsageForDate(date: String, usageData: JSONArray): Int {
        for (i in 0 until usageData.length()) {
            val entry = usageData.getJSONObject(i)
            if (entry.getString("date") == date) {
                return entry.getInt("count")
            }
        }
        return 0
    }

    fun updateUsageForDate(date: String, count: Int, usageData: JSONArray) {
        var updated = false
        var totalUsage = calculateTotalUsage(usageData) + 1

        for (i in 0 until usageData.length()) {
            val entry = usageData.getJSONObject(i)
            if (entry.getString("date") == date) {
                entry.put("count", count)
                entry.put("totalCount", totalUsage)
                updated = true
                break
            }
        }

        if (!updated) {
            val newEntry = JSONObject().apply {
                put("date", date)
                put("count", count)
                put("totalCount", totalUsage)
            }
            usageData.put(newEntry)
        }
    }

    private fun calculateTotalUsage(usageData: JSONArray): Int {
        var total = 0
        for (i in 0 until usageData.length()) {
            val entry = usageData.getJSONObject(i)
            total += entry.getInt("count")
        }
        return total
    }

    fun getTotalUsage(): Int {
        return calculateTotalUsage(readUsageData())
    }

    fun resetUsage() {
        writeUsageData(JSONArray())
    }

    fun getFormattedUsageLog(): String {
        val usageData = readUsageData()
        return usageData.toString(4)
    }

    private fun readUsageData(): JSONArray {
        return try {
            val content = usageFile.readText()
            if (content.isNotEmpty()) JSONArray(content) else JSONArray()
        } catch (e: IOException) {
            e.printStackTrace()
            JSONArray()
        } catch (e: Exception) {
            e.printStackTrace()
            JSONArray()
        }
    }

    private fun writeUsageData(data: JSONArray) {
        try {
            usageFile.writeText(data.toString())
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun getUsageFilePath(): String {
        return usageFile.absolutePath
    }
}