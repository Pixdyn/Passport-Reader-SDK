package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import androidx.core.content.ContextCompat
import com.pixl.pixlpassportreader.R

class OverlayViews(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    private var results = listOf<BoundingBox>()
    private var boxPaint = Paint()
    private var bounds = Rect()

    // Convert 20dp to pixels
    private val additionalHeightPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        40f,
        resources.displayMetrics
    )

    init {
        initPaints()
    }

    fun clear() {
        results = listOf()
        invalidate()
    }

    private fun initPaints() {
        val color = ContextCompat.getColor(context!!, R.color.bounding_box_color)
        val alpha = 50
        boxPaint.color = color
        boxPaint.alpha = alpha
        boxPaint.style = Paint.Style.FILL_AND_STROKE
        boxPaint.strokeWidth = 5f
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)

        results.forEach {
            val left = it.x1 * width
            val top = it.y1 * height
            val right = it.x2 * width
            val bottom = it.y2 * height + additionalHeightPx

            // Draw the bounding box
            canvas.drawRect(left, top, right, bottom, boxPaint)
        }
    }

    fun trackMRZ(boundingBoxes: List<BoundingBox>) {
        val mrzBoundingBoxes = boundingBoxes.filter { it.clsName == "mrz" }
        results = mrzBoundingBoxes
        invalidate()
    }

    fun setResults(boundingBoxes: List<BoundingBox>) {
        results = boundingBoxes
        invalidate()
    }
}
