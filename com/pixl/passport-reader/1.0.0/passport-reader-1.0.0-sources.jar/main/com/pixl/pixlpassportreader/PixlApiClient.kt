package com.pixl.pixlpassportreader

import android.util.Log
import com.google.gson.Gson

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

object PixlApiClient {

    private const val TAG = "PixlApiClient"
    private const val BASE_URL = "https://accounts-uat.pixl.ai/api"

    private const val bearerToken = ""
    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 15_000

    private val gson = Gson()

    suspend fun verifyClient(request: VerifyClientRequest): ApiResult =
        post("$BASE_URL/Hit/verify-client", gson.toJson(request))

    suspend fun updateHitCount(request: UpdateHitCountRequest): ApiResult =
        post("$BASE_URL/Hit/update-hit-count", gson.toJson(request))

    private fun printCurl(url: String, jsonBody: String) {
        val curl = """
        curl --location '$url' \
        --header 'Content-Type: application/json' \
        --header 'Accept: */*' \
        --header 'Authorization: Bearer $bearerToken' \
        --data '$jsonBody'
    """.trimIndent()

        Log.d(TAG, "cURL:\n$curl")
    }

    private suspend fun post(urlString: String, jsonBody: String): ApiResult =  //bearerToken: String? = null
        withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                printCurl(urlString, jsonBody)
                connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    doOutput = true
                    connectTimeout = CONNECT_TIMEOUT_MS
                    readTimeout = READ_TIMEOUT_MS
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "*/*")
                    setRequestProperty("Authorization", "Bearer $bearerToken")
//                    if (!PixlApiClient.bearerToken.isNullOrBlank()) {
//                        setRequestProperty("Authorization", "Bearer $bearerToken")
//                    }
                }

                connection.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }

                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseBody = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                Log.d(TAG, "POST $urlString -> $code : $responseBody")

                val parsed = runCatching {
                    gson.fromJson(responseBody, ApiResponse::class.java)
                }.getOrNull()

                ApiResult(
                    httpCode = code,
                    success = (code in 200..299) && (parsed?.success ?: true),
                    message = parsed?.message
                )
            } catch (e: Exception) {
                Log.e(TAG, "POST $urlString failed: ${e.message}", e)
                ApiResult(httpCode = -1, success = false, message = e.message)
            } finally {
                connection?.disconnect()
            }
        }
}