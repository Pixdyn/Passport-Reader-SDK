package com.pixl.pixlpassportreader

import android.content.Context

data class SdkCredentials(
    val apiKey: String,
    val deviceId: String,
    val verified: Boolean
)

/**
 * Persists the verified API key + device id in SharedPreferences.
 * This survives app restarts/reboots and is only cleared on uninstall
 * (or if the app's data is manually cleared) — exactly what we want,
 * since a re-verified key lets the SDK run offline afterward.
 */
class SdkCredentialsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getCredentials(): SdkCredentials? {
        val apiKey = prefs.getString(KEY_API_KEY, null) ?: return null
        val deviceId = prefs.getString(KEY_DEVICE_ID, null) ?: return null
        return SdkCredentials(
            apiKey = apiKey,
            deviceId = deviceId,
            verified = prefs.getBoolean(KEY_VERIFIED, false)
        )
    }

    fun saveVerified(apiKey: String, deviceId: String) {
        prefs.edit()
            .putString(KEY_API_KEY, apiKey)
            .putString(KEY_DEVICE_ID, deviceId)
            .putBoolean(KEY_VERIFIED, true)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "pixl_sdk_credentials"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_VERIFIED = "verified"
    }
}