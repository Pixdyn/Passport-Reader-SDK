package com.pixl.pixlpassportreader

import android.content.Context

data class SdkCredentials(
    val apiKey: String,
    val deviceId: String,
    val verified: Boolean,
    // -1 means "never received from the server" - distinct from a real 0 (limit hit).
    val remainingHitCount: Int,
    val totalHitCount: Int
)

/**
 * Persists the verified API key + device id, plus the last known hit allowance from
 * /verify-client or /register-device, in SharedPreferences. This survives app
 * restarts/reboots and is only cleared on uninstall (or if the app's data is manually
 * cleared) — exactly what we want, since a re-verified key plus a remembered hit
 * allowance lets the SDK keep working while offline.
 */
class SdkCredentialsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getCredentials(): SdkCredentials? {
        val apiKey = prefs.getString(KEY_API_KEY, null) ?: return null
        val deviceId = prefs.getString(KEY_DEVICE_ID, null) ?: return null
        return SdkCredentials(
            apiKey = apiKey,
            deviceId = deviceId,
            verified = prefs.getBoolean(KEY_VERIFIED, false),
            remainingHitCount = prefs.getInt(KEY_REMAINING_HIT_COUNT, -1),
            totalHitCount = prefs.getInt(KEY_TOTAL_HIT_COUNT, -1)
        )
    }

    fun saveVerified(apiKey: String, deviceId: String) {
        prefs.edit()
            .putString(KEY_API_KEY, apiKey)
            .putString(KEY_DEVICE_ID, deviceId)
            .putBoolean(KEY_VERIFIED, true)
            .apply()
    }

    /** Overwrites the locally cached allowance with the server's authoritative values. */
    fun saveHitAllowance(remainingHitCount: Int, totalHitCount: Int) {
        prefs.edit()
            .putInt(KEY_REMAINING_HIT_COUNT, remainingHitCount)
            .putInt(KEY_TOTAL_HIT_COUNT, totalHitCount)
            .apply()
    }

    /**
     * Decrements the locally cached remaining-hit count by one and persists it. Purely a
     * local best-effort estimate - no network call - so the SDK still knows roughly how
     * much allowance is left the next time /verify-client can't be reached. Gets
     * overwritten with the server's real value the next time verification succeeds online.
     */
    fun decrementRemainingHit(): Int {
        val current = prefs.getInt(KEY_REMAINING_HIT_COUNT, -1)
        if (current < 0) return current
        val updated = (current - 1).coerceAtLeast(0)
        prefs.edit().putInt(KEY_REMAINING_HIT_COUNT, updated).apply()
        return updated
    }

    companion object {
        private const val PREFS_NAME = "pixl_sdk_credentials"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_VERIFIED = "verified"
        private const val KEY_REMAINING_HIT_COUNT = "remaining_hit_count"
        private const val KEY_TOTAL_HIT_COUNT = "total_hit_count"
    }
}