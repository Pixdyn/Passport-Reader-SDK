package com.pixl.pixlpassportreader

// The verify/register/hit-tracking flow that used to live in this file
// (PixlSdkManager.ensureVerified/recordHit/syncPendingHits) has moved into
// PixlHitService.kt, which is now the single source of truth — mirroring the
// iOS SDK's PixlHitService.swift. The stable device-id helper moved to
// PixlDeviceIdentity (also in PixlHitService.kt), matching PixlDeviceIdentity.swift.
//
// ClientVerificationApi.kt, SdkCredentialsStore.kt, HitCountStore.kt and
// PixlApiClient.kt are no longer referenced anywhere in the module — they're
// superseded by PixlHitService/PixlHitCrypto and can be deleted whenever
// you're ready; left in place for now since files in this folder aren't
// removed without your say-so.
