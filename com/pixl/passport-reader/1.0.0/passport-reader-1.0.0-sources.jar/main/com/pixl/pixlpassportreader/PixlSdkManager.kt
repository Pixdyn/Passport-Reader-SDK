package com.pixl.pixlpassportreader


import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object PixlSdkManager {

    sealed class VerifyResult {
        data class Success(val deviceId: String, val fromCache: Boolean) : VerifyResult()
        data class Failure(val reason: String) : VerifyResult()
    }

    /**
     * Verifies the API key with the backend, but ONLY if it's new/changed or
     * hasn't been verified before. A previously verified key that matches the
     * one passed in short-circuits straight to success with no network call —
     * this is what lets the SDK operate offline after the first launch.
     */
    suspend fun ensureVerified(context: Context, apiKey: String): VerifyResult =
        withContext(Dispatchers.IO) {
            val store = SdkCredentialsStore(context)
            val cached = store.getCredentials()

            if (cached != null && cached.apiKey == apiKey && cached.verified) {
                return@withContext VerifyResult.Success(cached.deviceId, fromCache = true)
            }

            if (!NetworkUtils.isOnline(context)) {
                return@withContext VerifyResult.Failure(
                    "No internet connection available to verify API key"
                )
            }

            val deviceId = DeviceUtils.getDeviceId(context)
            val request = VerifyClientRequest(
                apiKey = apiKey,
                device = DeviceInfo(id = deviceId, os = "Android") //DeviceUtils.getOsInfo()
            )

            try {
                val result = PixlApiClient.verifyClient(request)
                if (result.success) {
                    store.saveVerified(apiKey, deviceId)
                    VerifyResult.Success(deviceId, fromCache = false)
                } else {
                    VerifyResult.Failure(result.message ?: "Client verification failed")
                }
            } catch (e: Exception) {
                VerifyResult.Failure(e.message ?: "Verification error")
            }
        }

    /** Queues a hit locally, then makes a best-effort attempt to flush the queue immediately. */
    suspend fun recordHit(context: Context) = withContext(Dispatchers.IO) {
        HitCountStore(context).appendHit(DateUtils.nowIsoUtc())
        syncPendingHits(context)
    }

    /**
     * Flushes any queued hit records to the backend. Safe to call opportunistically
     * (app resume, after every hit, on connectivity regained, etc.) — it's a no-op
     * when there's nothing pending or the device isn't verified/online.
     */
    suspend fun syncPendingHits(context: Context): Boolean = withContext(Dispatchers.IO) {
        val creds = SdkCredentialsStore(context).getCredentials()
        if (creds == null || !creds.verified) return@withContext false
        if (!NetworkUtils.isOnline(context)) return@withContext false

        val store = HitCountStore(context)
        val pending = store.getAll()
        if (pending.isEmpty()) return@withContext true

        return@withContext try {
            val request = UpdateHitCountRequest(
                deviceId = creds.deviceId,
                apiKey = creds.apiKey,
                hitDetails = pending
            )
            val result = PixlApiClient.updateHitCount(request)
            if (result.success) {
                store.removeSynced(pending)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }
}

object DeviceUtils {
    @SuppressLint("HardwareIds")
    fun getDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown-device"

    fun getOsInfo(): String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
}

object NetworkUtils {
    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}

object DateUtils {
    /** Matches the format already used elsewhere: "2026-07-01T07:37:48.663Z" */
    fun nowIsoUtc(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }
}