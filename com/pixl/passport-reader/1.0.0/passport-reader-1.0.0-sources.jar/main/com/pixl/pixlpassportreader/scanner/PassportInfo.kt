package com.pixl.pixlpassportreader.scanner

data class PassportInfo(
    val message: String = "N/A",
    var givenNames: String = "N/A",
    var surname: String ="N/A",
    val passportNumber: String = "N/A",
    val passportType: String = "N/A",
    val dob: String = "N/A",
    val isValidDob: Boolean?,
    val documentType: String ="N/A",
    val age: String ="N/A",
    val expirationDate: String = "N/A",
    val isExpired: Boolean?,
    val gender: String = "N/A",
    val monthsToExpire: String ="N/A",
    val issuingCountry: String,
    val nationality: String,
    val personImage: String? = null,
    val countryCode: String? = null,
    val passportImage: String? = null,
    var mrzLine1: String? = null,
    var mrzLine2: String? = null,
    var mrzLine3: String? = null,
    // TD1 (ID card) only - the two optional-data slots MrtdTd1 parses off lines 1 and 2.
    // Null for TD3 passport scans, which don't carry this data.
    var optionalData1: String? = null,
    var optionalData2: String? = null,
    // TD3 (passport) only - MRP.personalNumber, line 2 cols 28-42.
    var personalNumber: String? = null,
)