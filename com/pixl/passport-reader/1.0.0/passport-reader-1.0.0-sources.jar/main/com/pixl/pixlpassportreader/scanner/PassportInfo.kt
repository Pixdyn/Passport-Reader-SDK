package com.pixl.pixlpassportreader.scanner

data class PassportInfo(
    val message: String = "N/A",
    var givenNames: String = "N/A",
    var surname: String ="N/A",
    val passportNumber: String = "N/A",
    val passportType: String = "N/A",
    val dob: String = "N/A",
    val isValidDob: Boolean?,
    val documentType: String ="N/A",
    val age: String ="N/A",
    val expirationDate: String = "N/A",
    val isExpired: Boolean?,
    val gender: String = "N/A",
    val monthsToExpire: String ="N/A",
    val issuingCountry: String,
    val nationality: String,
    val personImage: String? = null,
    val countryCode: String? = null,
    val passportImage: String? = null,
    var mrzLine1: String? = null,
    var mrzLine2: String? = null,
)