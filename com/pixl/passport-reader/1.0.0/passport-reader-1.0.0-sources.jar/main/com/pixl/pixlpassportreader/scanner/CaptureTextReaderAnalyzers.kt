package com.pixl.pixlpassportreader.scanner

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import com.pixl.pixlpassportreader.TesseractManager
import com.pixl.pixlpassportreader.scanner.mrz.MrzParser
import com.pixl.pixlpassportreader.scanner.mrz.MrzRecord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CaptureTextReaderAnalyzer(
    private val context: Context,
    private val passFoundListener: (MrzRecord) -> Unit,
    private val errorListener: (String, Boolean) -> Unit
) {
//    fun process(bitmap: Bitmap, tessBaseAPI: TessBaseAPI) {
//        CoroutineScope(Dispatchers.IO).launch {
//            try {
//                tessBaseAPI.setImage(bitmap)
//                val extractedText = tessBaseAPI.utF8Text
//                Log.d("OCRB", "OCR Output: $extractedText")
//                processTextFromImage(extractedText)
//            } catch (e: Exception) {
//                Log.e("CaptureTextReader", "process error: ${e.message}", e)
//                errorListener("Please scan again. Couldn't read from image.", true)
//            }
//        }
//    }

//    fun process(bitmap: Bitmap) {
//        CoroutineScope(Dispatchers.IO).launch {
//            try {
//                val image = InputImage.fromBitmap(bitmap, 0)
//
//                val recognizer = TextRecognition.getClient(
//                    TextRecognizerOptions.DEFAULT_OPTIONS,
//
//                )
//
//                recognizer.process(image)
//                    .addOnSuccessListener { visionText ->
//                        val extractedText = visionText.text
//                        Log.d("MLKIT_OCR", "OCR Output: $extractedText")
//                        processTextFromImage(extractedText)
//                    }
//                    .addOnFailureListener { e ->
//                        Log.e("MLKIT_OCR", "process error: ${e.message}", e)
//                        errorListener("Please scan again. Couldn't read from image.", true)
//                    }
//
//            } catch (e: Exception) {
//                Log.e("CaptureTextReader", "process error: ${e.message}", e)
//                errorListener("Please scan again. Couldn't read from image.", true)
//            }
//        }
//    }

    fun process(bitmap: Bitmap) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                if (!TesseractManager.isReady) {
                    Log.w("TESS_OCR", "Tesseract not ready yet")
                    errorListener("Please scan again.", true)
                    return@launch
                }

                val extractedText = TesseractManager.recognize(bitmap)
                if (extractedText.isNullOrBlank()) {
                    Log.e("TESS_OCR", "Empty OCR output")
                    errorListener("Please scan again. Couldn't read from image.", true)
                    return@launch
                }

                Log.d("TESS_OCR", "OCR Output: $extractedText")
                processTextFromImage(extractedText)

            } catch (e: Exception) {
                Log.e("CaptureTextReader", "process error: ${e.message}", e)
                errorListener("Please scan again. Couldn't read from image.", true)
            }
        }
    }


    private fun processTextFromImage(visionText: String) {
        Log.d("MRZ_RAW", visionText)

        val fullMrzString = convertToFullMrz(visionText)
        if (fullMrzString.startsWith("Error:")) {
            Log.e("MRZScan", fullMrzString)
            errorListener("Please scan again. $fullMrzString", true)
            return
        }

        val lines = fullMrzString.split('\n')
        if (lines.size != 2) {
            errorListener("Error: Could not extract two valid MRZ lines from the scanned text.", true)
            return
        }

        try {
            val parts = extractMrzParts(lines.first())
            val lastString = parts.lastOrNull()
            var processedMrz = fullMrzString

            if (lastString != null && lastString.hasNumber()) {
                val reformatted = reformatGenericMrz(fullMrzString)
                if (reformatted == null) {
                    errorListener("MRZ reformat failed. Please scan again.", true)
                    return
                }
                processedMrz = reformatted
            }

            processedMrz = replacePattern(processedMrz)
            val finalLines = processedMrz.split('\n')
            if (finalLines.size == 2) {
                val firstLine = finalLines[0]
                val secondLine = finalLines[1]
                if (firstLine.length < 44 || secondLine.length < 44) {
                    errorListener(
                        "Error: Both MRZ lines must contain at least 44 characters after conversion.",
                        true
                    )
                    return
                }
                checkCorrectMrzScanned(firstLine, secondLine)
            } else {
                errorListener(
                    "Error: Could not extract two valid MRZ lines from the scanned text.",
                    true
                )
            }
        } catch (e: Exception) {
            Log.e("MRZScan", "Error processing MRZ: ${e.message}", e)
            errorListener("Please scan again. Error in processing MRZ structure.", true)
        }
    }

    fun extractMrzParts(mrzLine: String): List<String> {
        val delimiterRegex = "<{1,}".toRegex()
        return mrzLine.split(delimiterRegex).filter { it.isNotEmpty() }
    }

    fun replacePattern(inputString: String): String {
        val regex = Regex("<a< <[a-zA-Z0-9]<")
        return inputString.replace(regex, "<<<")
    }

    private fun checkCorrectMrzScanned(firstLine: String, secondLine: String) {
        val correctedFirstLine =
            correctWrongCharacters(firstLine).replace("Ö", "0")
                .replace(" ", "", ignoreCase = true)

        val correctedSecondLine = secondLine.replace(" ", "", ignoreCase = true)
        val validStartCharacters = setOf('P', 'V')

        if (correctedFirstLine.length == 44 &&
            correctedFirstLine.contains("<<") &&
            validStartCharacters.contains(correctedFirstLine[0])
        ) {
            try {
                val record =
                    MrzParser.parse(correctedFirstLine + "\n" + correctedSecondLine)
                if (record != null) {
                    if (record.surname.isEmpty()) record.surname = "N/A"
                    if (record.givenNames.isEmpty()) record.givenNames = "N/A"

                    record.surname = record.surname.replace("9", " ")
                    record.givenNames = record.givenNames.replace("9", " ")

                    val passportNo = record.documentNumber

                    if (!isValidPassportNumber(passportNo)) {
                        errorListener(
                            "Invalid or incomplete passport number detected. Please scan again.",
                            true
                        )
                        return
                    }


                    val cleanSurname = normalizeMrzName(record.surname)
                    val cleanGivenName = normalizeMrzName(record.givenNames)

                    if (
                        containsInvalidRepeatedChars(cleanSurname) ||
                        containsInvalidRepeatedChars(cleanGivenName)
                    ) {
                        errorListener(
                            "Invalid Name detected. Please scan again.",
                            true
                        )
                    }

                    val personalNumber = extractPersonalNumberFromLine2(correctedSecondLine)
                    record.personalNumber = personalNumber ?: ""

                    sanitizeMrzRecord(record)?.let { clean ->
                        Log.e("passFoundListener", "Cleaned MRZ Record: $clean")
                        passFoundListener(clean)
                    } ?: run {
                        errorListener(
                            "Invalid characters detected in MRZ fields. Please scan again.",
                            true
                        )
                    }
                } else {
                    errorListener("Please scan again. Error in processing MRZ.", true)
                }
            } catch (e: Exception) {
                errorListener("Please scan again. Error in processing MRZ.", true)
            }
        } else {
            errorListener("Please scan again. Error in processing MRZ.", true)
        }
    }

    private fun normalizePassportNumber(raw: String): String {
        return raw
            .uppercase()
            .replace("<", "")
            .replace(" ", "")
            .replace("Ö", "0")
            .replace("O", "0") // OCR confusion
    }

    private fun hasOnlyValidPassportChars(passportNo: String): Boolean {
        return passportNo.matches(Regex("^[A-Z0-9]+$"))
    }

    private fun isValidPassportLength(passportNo: String): Boolean {
        return passportNo.length in 8..9
    }

    private fun isLikelyOcrGarbage(passportNo: String): Boolean {
        if (passportNo.length < 6) return true

        val freq = passportNo.groupingBy { it }.eachCount()
        val maxRatio = freq.values.maxOrNull()!!.toFloat() / passportNo.length

        return maxRatio > 0.6f
    }

    private fun isValidPassportNumber(rawPassportNo: String?): Boolean {
        if (rawPassportNo.isNullOrBlank()) return false

        val passportNo = normalizePassportNumber(rawPassportNo)

        return hasOnlyValidPassportChars(passportNo) &&
                isValidPassportLength(passportNo) &&
                !isLikelyOcrGarbage(passportNo)
    }

    private fun containsInvalidRepeatedChars(name: String): Boolean {
        val regex = Regex("([A-Z])\\1{4,}")
        return regex.containsMatchIn(name)
    }


    fun extractPersonalNumberFromLine2(mrzLine2: String): String? {
        if (mrzLine2.length != 44) return null
        return mrzLine2.substring(28, 42)
    }

    private fun normalizeMrzName(name: String): String {
        return name
            .replace("<", " ")
            .replace("9", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .uppercase()
    }


    fun cleanName(value: String): String {
        return value.uppercase()
            .replace("<", " ")
            .replace(Regex("[^A-Z ]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }


    private fun sanitizeMrzRecord(record: MrzRecord): MrzRecord? {
        val allowedPattern = Regex("[A-Z0-9<]")

        fun cleanField(value: String): String {
            if (value.isBlank()) return ""
            return buildString {
                value.uppercase().forEach { ch ->
                    when {
                        allowedPattern.matches(ch.toString()) -> append(ch)
                        ch.isWhitespace() -> append("<")
                        else -> append("<")
                    }
                }
            }.trim('<')
        }

        record.surname = decodeNameField(cleanField(record.surname))
        record.givenNames = decodeNameField(cleanField(record.givenNames))
        record.documentNumber = cleanField(record.documentNumber)
        record.nationality = cleanField(record.nationality)
        record.issuingCountry = cleanField(record.issuingCountry)
        record.personalNumber = cleanField(record.personalNumber)
        return record
    }

    private fun decodeNameField(mrz: String): String {

        var mrzNameFild = mrz
            .trimEnd('<')
            .replace("<<", " ")
            .replace("<", " ")
            .trim()
        var cleanName = cleanName(mrzNameFild)
        return cleanName
    }

    private fun correctWrongCharacters(mrzLine: String): String {
        var line = mrzLine
            .replace("«", "<", ignoreCase = true)
            .replace(" ", "", ignoreCase = true)
            .replace("  ", "", ignoreCase = true)
            .replace(",", "<", ignoreCase = true)
            .replace("a", "Q")
            .replace("<<S<<", "<<<<<", ignoreCase = true)
            .replace("<K<", "<<<", ignoreCase = true)
            .replace("<KK<", "<<<<", ignoreCase = true)
            .replace("<KKK<", "<<<<<", ignoreCase = true)
            .replace("<KKKK<", "<<<<<<", ignoreCase = true)
            .replace("<KKKKK<", "<<<<<<<", ignoreCase = true)
            .replace("<KKKKKK<", "<<<<<<<<", ignoreCase = true)
            .replace("<c<", "<<<", ignoreCase = true)
            .replace("?", "<", ignoreCase = true)
            .replace("<cc<", "<<<<", ignoreCase = true)
            .replace("<cc", "<<<", ignoreCase = true)
            .replace("cc<", "<<<", ignoreCase = true)
            .replace("<ccc<", "<<<<<", ignoreCase = true)
            .replace("<ccccc<", "<<<<<<<", ignoreCase = true)
            .replace("<cccccc<", "<<<<<<<<", ignoreCase = true)
            .replace("c<<<", "<<<<", ignoreCase = true)
            .replace("<s<", "<<<", ignoreCase = true)
            .replace("<ss<", "<<<<", ignoreCase = true)
            .replace("<sss<", "<<<<<", ignoreCase = true)
            .replace("<ssss<", "<<<<<<", ignoreCase = true)
            .replace("<sssss<", "<<<<<<<", ignoreCase = true)
            .replace("<ssssss<", "<<<<<<<<", ignoreCase = true)
            .replace("0D00", "0000", ignoreCase = true)
            .replace("OO0", "000", ignoreCase = true)
            .replace("0D0", "000", ignoreCase = true)
            .replace("OD0", "000", ignoreCase = true)
            .replace("OOO", "000", ignoreCase = true)
            .replace("O0D", "000", ignoreCase = true)
            .replace("ODO", "000", ignoreCase = true)
            .replace("D0", "00", ignoreCase = true)
            .replace("0O0", "000", ignoreCase = true)
            .replace("O0", "00", ignoreCase = true)
            .replace("0D", "00", ignoreCase = true)
            .replace("<8<", "<<<", ignoreCase = true)
            .replace("<0<", "<<<", ignoreCase = true)
            .replace("Ó", "O")
            .replace("&", "8", ignoreCase = true)
            .replace("<C<", "<<<", ignoreCase = true)
            .replace("<<C<", "<<<<", ignoreCase = true)
            .replace("<:<", "<<<", ignoreCase = true)
            .replace("IMD", "IND", ignoreCase = true)
            .replace("C<CC", "<<<<", ignoreCase = true)
            .replace(Regex("[%^&#`!@\$\\-()*]"), "<")
            .replace(".", "")
            .uppercase()

        if (line.length < 44) {
            line = line.padEnd(44, '<')
        } else if (line.length > 44) {
            line = line.substring(0, 44)
        }

//        val split = line.split("<<")[0].split("<")
//        if (split.size > 2) {
//            val index = split[0].length + split[1].length + 1
//            line = line.substring(0, index) + "9" + line.substring(index + 1)
//        }
        return line
    }

    fun reformatGenericMrz(malformedMrz: String): String? {
        return try {
            val TARGET_LINE_LENGTH = 44
            val lines = malformedMrz.replace("«", "<").split('\n')
            if (lines.size != 2) {
                errorListener("Please scan again. Error in processing MRZ.", true)
                null
            } else {
                val splitfirst = extractMrzParts(lines.first())
                if (splitfirst.isEmpty()) {
                    errorListener("Please scan again. Invalid MRZ format detected.", true)
                    null
                } else {
                    val passportID = splitfirst.last()
                    val firstLine = lines.first()
                    val secondLine = lines.last()

                    val newFirstLine = firstLine.replace(passportID, "").padEnd(44, '<')
                    val secondSub = secondLine.substring(
                        0,
                        (secondLine.length - passportID.length - 1).coerceAtLeast(0)
                    )
                    val newSecondLine =
                        (passportID + secondSub).padEnd(TARGET_LINE_LENGTH - 1, '<') + "4"

                    "$newFirstLine\n$newSecondLine"
                }
            }
        } catch (e: Exception) {
            Log.e("MRZScan", "Error reformatting MRZ: ${e.message}", e)
            errorListener("Please scan again. Error reformatting MRZ.", true)
            null
        }
    }

    fun String.hasNumber(): Boolean = any { it.isDigit() }

    fun convertToFullMrz(inputString: String): String {
        return try {
            val normalizedMrzString = normalizePassportPrefix(inputString)
            val TARGET_LINE_LENGTH = 44
            val cleanedMrz = normalizedMrzString.replace(Regex("[^A-Z0-9<]"), "")

            val line2AnchorPattern = "[A-Z]{3}\\d{6}".toRegex()
            val anchorMatch = line2AnchorPattern.find(cleanedMrz)
            if (anchorMatch != null) {
                val passportInfoBlockLength = 10
                val line2StartIndex = anchorMatch.range.first - passportInfoBlockLength
                if (line2StartIndex < 0) {
                    return "Error: Could not determine a valid split point."
                }

                val line1Raw = cleanedMrz.substring(0, line2StartIndex)
                var line2Raw = cleanedMrz.substring(line2StartIndex)

                val natDobMatch = line2AnchorPattern.find(line2Raw)
                if (natDobMatch != null) {
                    val sexFieldIndex = natDobMatch.range.last + 2
                    if (sexFieldIndex < line2Raw.length && line2Raw[sexFieldIndex] == 'N') {
                        val chars = line2Raw.toCharArray()
                        chars[sexFieldIndex] = 'M'
                        line2Raw = String(chars)
                    }
                }

                val fullMrzLine1 = line1Raw.padEnd(TARGET_LINE_LENGTH, '<')
                val bodyLength = TARGET_LINE_LENGTH - 1
                val finalCheckDigit =
                    if (line2Raw.isNotEmpty() && line2Raw.last().isDigit()) line2Raw.last() else '4'
                val contentSource =
                    if (line2Raw.isNotEmpty() && line2Raw.last().isDigit()) line2Raw.dropLast(1)
                    else line2Raw
                val body =
                    contentSource.padEnd(bodyLength, '<').substring(0, bodyLength)
                val fullMrzLine2 = body + finalCheckDigit

                "$fullMrzLine1\n$fullMrzLine2"
            } else {
                "Error: Could not find anchor (Nationality + DOB) in MRZ string."
            }
        } catch (e: Exception) {
            "Error: An exception occurred during parsing: ${e.message}"
        }
    }

    private fun normalizePassportPrefix(inputString: String): String {
        val pIndex = inputString.indexOf('P')
        if (pIndex == -1) {
            return "P<" + inputString.replace(Regex("[^A-Z0-9<]"), "")
        }
        val candidateString = inputString.substring(pIndex).trim()
        if (candidateString.startsWith("P<")) return candidateString

        val otherValidPrefixes = listOf(
            "PA", "PC", "PD", "PE", "PF", "PG", "PH", "PI", "PJ", "PK", "PL", "PM",
            "PN", "PO", "PP", "PQ", "PR", "PS", "PT", "PU", "PV", "PW", "PX", "PY", "PZ"
        )
        for (prefix in otherValidPrefixes) {
            if (candidateString.startsWith(prefix)) {
                return "P<" + candidateString.substring(2)
            }
        }

        if (candidateString.length >= 2 &&
            candidateString[0] == 'P' &&
            candidateString[1].isLetter()
        ) {
            return "P<" + candidateString.substring(2)
        }

        return "P<$candidateString"
    }
}
