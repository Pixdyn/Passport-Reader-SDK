package com.pixl.pixlpassportreader

import android.annotation.SuppressLint
import android.app.Application
import android.content.ContentValues
import android.graphics.Bitmap
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.experimental.and
import net.sf.scuba.smartcards.CardService
import org.jmrtd.BACKey
import org.jmrtd.PassportService
import org.jmrtd.lds.SODFile
import org.jmrtd.lds.icao.COMFile
import org.jmrtd.lds.icao.DG11File
import org.jmrtd.lds.icao.DG12File
import org.jmrtd.lds.icao.DG14File
import org.jmrtd.lds.icao.DG1File
import org.jmrtd.lds.icao.DG2File
import org.jmrtd.lds.icao.DG3File
import org.jmrtd.lds.icao.DG4File
import org.jmrtd.lds.icao.DG5File
import org.jmrtd.lds.icao.DG6File
import org.jmrtd.lds.icao.DG7File
import org.jmrtd.lds.icao.MRZInfo
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.imgcodecs.Imgcodecs
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException


data class MRZData(
    val documentNumber: String,
    val dateOfBirth: String,
    val expiryDate: String
)

interface NFCScanCallback {
    fun onScanCompleted(scanResult: String, bitmap: Bitmap)
    fun onScanNFCCompleted(scanResult: PassportResult, bitmap: Bitmap)
    fun onTimeExpired()
}

public class MainViewModel : AndroidViewModel {

    companion object {
        private val TAG = MainViewModel::class.java.getSimpleName()
        private const val prefix = "android.nfc.tech."


    }


    private var nfcScanCallback: NFCScanCallback? = null

    private val liveNFC: MutableStateFlow<NFCStatus?>
    private val liveToast: MutableSharedFlow<String?>
    private val liveTag: MutableStateFlow<String?>

    private var passportInfo: PassportResult? = null

    constructor(application: Application) : super(application) {
        Log.d(TAG, "constructor")
        liveNFC = MutableStateFlow(null)
        liveToast = MutableSharedFlow()
        liveTag = MutableStateFlow(null)
    }

    //region Toast Methods
    private fun updateToast(message: String) {
        Coroutines.io(this@MainViewModel) {
            liveToast.emit(message)
        }
    }

    fun setNFCScanCallback(callback: NFCScanCallback) {
        nfcScanCallback = callback
    }

    private suspend fun postToast(message: String) {
        Log.d(TAG, "postToast(${message})")
        liveToast.emit(message)
    }

    public fun observeToast(): SharedFlow<String?> {
        return liveToast.asSharedFlow()
    }

    //endregion
    @RequiresApi(Build.VERSION_CODES.KITKAT)
    public fun getNFCFlags(): Int {
        return NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or
                NfcAdapter.FLAG_READER_NFC_BARCODE
    }

    public fun getExtras(): Bundle {
        val options: Bundle = Bundle();
        options.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 30000);
        return options
    }

    public fun onCheckNFC(isChecked: Boolean) {
        Coroutines.io(this@MainViewModel) {
            Log.d(TAG, "onCheckNFC(${isChecked})")
            if (isChecked) {
                postNFCStatus(NFCStatus.Tap)
            } else {
                postNFCStatus(NFCStatus.NoOperation)
                postToast("NFC is Disabled, Please Toggle On!")
            }
        }
    }

    public fun readTag(tag: Tag?) {
        Coroutines.default(this@MainViewModel) {
            Log.d(TAG, "readTag(${tag} ${tag?.getTechList()})")
            postNFCStatus(NFCStatus.Process)
            val stringBuilder: StringBuilder = StringBuilder()
            val id: ByteArray? = tag?.getId()
            stringBuilder.append("Tag ID (hex): ${getHex(id!!)} \n")
            stringBuilder.append("Tag ID (dec): ${getDec(id)} \n")
            stringBuilder.append("Tag ID (reversed): ${getReversed(id)} \n")
            stringBuilder.append("Technologies: ")
            tag.getTechList().forEach { tech ->
                stringBuilder.append(tech.substring(prefix.length))
                stringBuilder.append(", ")
            }
            stringBuilder.delete(stringBuilder.length - 2, stringBuilder.length)
            tag.getTechList().forEach { tech ->
                if (tech.equals(MifareClassic::class.java.getName())) {
                    stringBuilder.append('\n')
                    val mifareTag: MifareClassic = MifareClassic.get(tag)
                    val type: String
                    if (mifareTag.getType() == MifareClassic.TYPE_CLASSIC) type = "Classic"
                    else if (mifareTag.getType() == MifareClassic.TYPE_PLUS) type = "Plus"
                    else if (mifareTag.getType() == MifareClassic.TYPE_PRO) type = "Pro"
                    else type = "Unknown"
                    stringBuilder.append("Mifare Classic type: $type \n")
                    stringBuilder.append("Mifare size: ${mifareTag.getSize()} bytes \n")
                    stringBuilder.append("Mifare sectors: ${mifareTag.getSectorCount()} \n")
                    stringBuilder.append("Mifare blocks: ${mifareTag.getBlockCount()}")
                }
                if (tech.equals(MifareUltralight::class.java.getName())) {
                    stringBuilder.append('\n');
                    val mifareUlTag: MifareUltralight = MifareUltralight.get(tag);
                    val type: String
                    if (mifareUlTag.getType() == MifareUltralight.TYPE_ULTRALIGHT) type =
                        "Ultralight"
                    else if (mifareUlTag.getType() == MifareUltralight.TYPE_ULTRALIGHT_C) type =
                        "Ultralight C"
                    else type = "Unkown"
                    stringBuilder.append("Mifare Ultralight type: ");
                    stringBuilder.append(type)
                }
            }
            Log.d(TAG, "Datum: $stringBuilder")
            Log.d(ContentValues.TAG, "dumpTagData Return \n $stringBuilder")
            postNFCStatus(NFCStatus.Read)
            liveTag.emit("${getDateTimeNow()} \n ${stringBuilder}")
        }
    }

    public fun updateNFCStatus(status: NFCStatus) {
        Coroutines.io(this@MainViewModel) {
            postNFCStatus(status)
        }
    }

    public fun readNFCTag(
        tag: Tag?,
        passportResult: PassportResult,
        passportNumebr: String,
        dob: String,
        dateOfExp: String
    ) {
        CoroutineScope(Dispatchers.Main).launch {
            passportInfo = passportResult
            Log.d(
                TAG, "rea" +
                        "dTag(${tag} ${tag?.techList})"
            )

            var mrzData1 = MRZData(passportNumebr, dob, dateOfExp)
            if (tag != null && mrzData1 != null) {
                readPassportDataWithJMRTD(tag, mrzData1)
//                readCardData(tag, mrzData1)
            }
            Log.d(TAG, "NFC Processing completed")
        }
    }

    private suspend fun postNFCStatus(status: NFCStatus) {
        Log.d(TAG, "postNFCStatus(${status})")
        if (NFCManager.isSupportedAndEnabled(getApplication())) {
            liveNFC.emit(status)
        } else if (NFCManager.isNotEnabled(getApplication())) {
            liveNFC.emit(NFCStatus.NotEnabled)
            postToast("Please Enable your NFC!")
            liveTag.emit("Please Enable your NFC!")
        } else if (NFCManager.isNotSupported(getApplication())) {
            liveNFC.emit(NFCStatus.NotSupported)
            postToast("NFC Not Supported!")
            liveTag.emit("NFC Not Supported!")
        }
        if (NFCManager.isSupportedAndEnabled(getApplication()) && status == NFCStatus.Tap) {
            liveTag.emit("Please Tap Now!")
        } else {
            liveTag.emit(null)
        }
    }

    public fun observeNFCStatus(): StateFlow<NFCStatus?> {
        return liveNFC.asStateFlow()
    }

    //endregion
    //region Tags Information Methods
    private fun getDateTimeNow(): String {
        Log.d(TAG, "getDateTimeNow()")
        val TIME_FORMAT: DateFormat = SimpleDateFormat.getDateTimeInstance()
        val now: Date = Date()
        Log.d(ContentValues.TAG, "getDateTimeNow() Return ${TIME_FORMAT.format(now)}")
        return TIME_FORMAT.format(now)
    }

    private fun getHex(bytes: ByteArray): String {
        val sb = StringBuilder()
        for (i in bytes.indices.reversed()) {
            val b: Int = bytes[i].and(0xff.toByte()).toInt()
            if (b < 0x10) sb.append('0')
            sb.append(Integer.toHexString(b))
            if (i > 0)
                sb.append(" ")
        }
        return sb.toString()
    }

    private fun getDec(bytes: ByteArray): Long {
        Log.d(TAG, "getDec()")
        var result: Long = 0
        var factor: Long = 1
        for (i in bytes.indices) {
            val value: Long = bytes[i].and(0xffL.toByte()).toLong()
            result += value * factor
            factor *= 256L
        }
        return result
    }

    private fun getReversed(bytes: ByteArray): Long {
        Log.d(TAG, "getReversed()")
        var result: Long = 0
        var factor: Long = 1
        for (i in bytes.indices.reversed()) {
            val value = bytes[i].and(0xffL.toByte()).toLong()
            result += value * factor
            factor *= 256L
        }
        return result
    }

    fun deriveKeys(mrzData: MRZData): Pair<ByteArray, ByteArray> {
        val mrzString = mrzData.documentNumber + mrzData.dateOfBirth + mrzData.expiryDate

        // Deriving KENC and KMAC using MRZ string
        val sha1Digest = MessageDigest.getInstance("SHA-1").digest(mrzString.toByteArray())
        val key1 = sha1Digest.sliceArray(0 until 8)  // KENC
        val key2 = sha1Digest.sliceArray(8 until 16) // KMAC

        Log.d(TAG, "Derived Keys: KENC: ${key1.contentToString()}, KMAC: ${key2.contentToString()}")

        return Pair(key1, key2)
    }


    private fun createKey(data1: String, data2: String): ByteArray {
        Log.e("Created Key: ", (data1 + data2).toString())
        Log.e("Created Key Byte: ", "${(data1 + data2).toByteArray()}")
        return (data1 + data2).toByteArray() // Simplified for illustration
    }


    fun authenticateWithBAC(tag: Tag, keys: Pair<ByteArray, ByteArray>) {
        val isoDep = IsoDep.get(tag)
        isoDep?.connect()

        val kenc = keys.first
        val kmac = keys.second

        // Step 1: Send a SELECT FILE command (Select the MF or application on the passport)
        val selectApdu = byteArrayOf(
            0x00,
            0xA4.toByte(), 0x04, 0x0C, 0x0E,
            0xA0.toByte(), 0x00, 0x00, 0x02, 0x47,
            0x10, 0x01, 0x01, 0x01, 0x01, 0x01
        )
        val response = isoDep.transceive(selectApdu)

        Log.d(TAG, "SELECT FILE Response: ${response.contentToString()}")

        Log.d(TAG, "BAC Authentication successful")

        isoDep.close()
    }

    fun parseTLVData(data: ByteArray): Map<Int, ByteArray> {
        val tlvMap = mutableMapOf<Int, ByteArray>()
        var index = 0

        while (index < data.size) {
            if (index + 1 >= data.size) {
                Log.e(TAG, "TLV parsing error: Unexpected end of data")
                break
            }

            // Read the tag
            val tag = data[index].toInt() and 0xFF
            index += 1

            // Read the length byte
            var length = data[index].toInt() and 0xFF
            index += 1

            // If length is 0x81, the length is stored in the next byte
            if (length == 0x81) {
                length = data[index].toInt() and 0xFF
                index += 1
            } else if (length == 0x82) {
                // If length is 0x82, the length is stored in the next 2 bytes
                length = (data[index].toInt() and 0xFF shl 8) or (data[index + 1].toInt() and 0xFF)
                index += 2
            }

            Log.d(TAG, "Current Index: $index, Data Size: ${data.size}, Length: $length")

            // Ensure we don't read beyond the data array
            if (index + length > data.size) {
                Log.e(TAG, "TLV parsing error: Length exceeds data size, skipping")
                break
            }

            // Extract the value
            val value = data.copyOfRange(index, index + length)
            tlvMap[tag] = value
            index += length
        }

        return tlvMap
    }


    fun parseMRZData(data: ByteArray): String {
        return String(data, Charsets.US_ASCII)
    }

    fun decodeEFData(data: ByteArray): String {
        return String(data, Charsets.UTF_8)
    }

    @SuppressLint("NewApi")
//    suspend fun readPassportDataWithJMRTD(tag: Tag, mrzData: MRZData) {
//        val isoDep = IsoDep.get(tag)
//        if (isoDep != null) {
//            try {
//                isoDep.timeout = 50000
//
//                val cardService = CardService.getInstance(isoDep)
//                cardService.open()
//
//                val passportService = PassportService(cardService, 256, 32, false, true)
//                passportService.sendSelectApplet(false)
//                passportService.open()
//
//                val documentNumber = mrzData.documentNumber.trim().padEnd(9, '<')
//                val dateOfBirth = mrzData.dateOfBirth
//                val dateOfExpiry = mrzData.expiryDate
//
//                Log.d(
//                    TAG,
//                    "Parsed MRZ Data - Document Number: $documentNumber, Date of Birth: $dateOfBirth, Expiry Date: $dateOfExpiry"
//                )
//
//                val bacKey = BACKey(documentNumber, dateOfBirth, dateOfExpiry)
//                Log.e(TAG, "BackKey:   $bacKey")
//
//                var paceSucceeded = false
//
//                if (!paceSucceeded) {
//                    try {
//                        Log.d(TAG, "Attempting BAC authentication")
//                        passportService.doBAC(bacKey)
//                        Log.d(TAG, "BAC authentication successful")
//                    } catch (e: AccessDeniedException) {
//                        Log.e(TAG, "Access denied during BAC: ${e.message}")
//                        return
//                    } catch (e: Exception) {
//                        Log.e(TAG, "Error during BAC: ${e.message}", e)
//                        return
//                    }
//                }
//
//                val efCom = passportService.getInputStream(PassportService.EF_COM)
//                Log.d(TAG, "EF.COM: ${efCom.readBytes().contentToString()}")
//
//
//                withContext(Dispatchers.IO) {
//                    val dg2File = DG2File(passportService.getInputStream(PassportService.EF_DG2))
//                    val faceImageInfo = dg2File.faceInfos[0].faceImageInfos.firstOrNull()
//
//                    val dg1File = DG1File(passportService.getInputStream(PassportService.EF_DG1))
//                    val mrzInfo = dg1File.mrzInfo
//                    val nationality = mrzInfo.nationality
//                    val gender = mrzInfo.gender
//                    val state = mrzInfo.issuingState
//                    val document = mrzInfo.documentCode
//                    val givenName = mrzInfo.primaryIdentifier
//                    val surname = mrzInfo.secondaryIdentifier
//
//                    passportInfo?.nationality = nationality
//                    passportInfo?.gender = gender.toString()
//                    passportInfo?.documentType = document.toString()
//
//                    passportInfo?.givenNames = formatName(givenName)
//                    passportInfo?.surname = formatName(surname)
//
//                    faceImageInfo?.let { info ->
//                        val imageBytes = info.imageInputStream.readBytes()
//
//                        val base64String = imageBytes.toBase64()
//                        Log.d(TAG, "Base64 En  coded Image: $base64String")
//                        passportInfo?.personImage = base64String
//                        var userBitmap = decodeBase64JP2ToBitmap(base64String)
//                        userBitmap?.let { userImage ->
//                            passportInfo?.let {
//                                val gson = Gson()
//                                val passportInfoJson = gson.toJson(it)
//                                nfcScanCallback?.onScanCompleted(passportInfoJson, userImage)
//                            }
//                        }
//                        if (imageBytes.size > 2) {
//                            val header = imageBytes.take(2)
//                            Log.d(TAG, "Image bytes header: ${header.joinToString(",") { String.format("0x%02X", it) }}")
//                        }
//                        passportService.close()
//                    }
//                }
//            } catch (e: Exception) {
//                Log.e(TAG, "Error reading passport data", e)
//                nfcScanCallback?.onTimeExpired()
//            } finally {
//                isoDep.close()
//            }
//        } else {
//            nfcScanCallback?.onTimeExpired()
//            Log.e(TAG, "IsoDep is null, unable to read passport")
//        }
//    }

    suspend fun readPassportDataWithJMRTD(tag: Tag, mrzData: MRZData) {
        val isoDep = IsoDep.get(tag)
        if (isoDep != null) {
            try {
//                isoDep.timeout = 40000

                val cardService = CardService.getInstance(isoDep)
                cardService.open()

                val passportService = PassportService(
                    cardService,
                    PassportService.NORMAL_MAX_TRANCEIVE_LENGTH,
                    PassportService.DEFAULT_MAX_BLOCKSIZE,
                    false,
                    false
                )
                passportService.open()

                val documentNumber = mrzData.documentNumber.trim().padEnd(9, '<')
                val dateOfBirth = mrzData.dateOfBirth
                val dateOfExpiry = mrzData.expiryDate

                Log.d(
                    TAG,
                    "Parsed MRZ Data - Document Number: $documentNumber, Date of Birth: $dateOfBirth, Expiry Date: $dateOfExpiry"
                )

                val bacKey = BACKey(documentNumber, dateOfBirth, dateOfExpiry)
                Log.e(TAG, "BackKey: $bacKey")

                var paceSucceeded = false
                passportService.sendSelectApplet(paceSucceeded)

                if (!paceSucceeded) {
                    try {
                        Log.d(TAG, "Attempting BAC authentication")
                        passportService.doBAC(bacKey)
                        Log.d(TAG, "BAC authentication successful")
                    } catch (e: AccessDeniedException) {
                        Log.e(TAG, "Access denied during BAC: ${e.message}")
                        nfcScanCallback?.onTimeExpired()
                        return
                    } catch (e: Exception) {
                        Log.e(TAG, "Error during BAC: ${e.message}", e)
                        nfcScanCallback?.onTimeExpired()
                        return
                    }
                }

                withContext(Dispatchers.IO) {
                    try {
//                        val efCom = passportService.getInputStream(PassportService.EF_COM)
//                        Log.d(TAG, "EF.COM: ${efCom.readBytes().contentToString()}")

                        try {
                            val dg1File =
                                DG1File(passportService.getInputStream(PassportService.EF_DG1))
                            val mrzInfo: MRZInfo = dg1File.mrzInfo
                            passportInfo?.nationality = mrzInfo.nationality
                            passportInfo?.gender = mrzInfo.gender.toString()
                            passportInfo?.documentType = mrzInfo.documentCode.toString()
                            passportInfo?.givenNames = formatName(mrzInfo.secondaryIdentifier)
                            passportInfo?.surname = formatName(mrzInfo.primaryIdentifier)
                            passportInfo?.mrz = "${dg1File.encoded.size}"
                            passportInfo?.isNFC = true
                            Log.d(TAG, "DG1 read successfully. Size: ${dg1File.encoded.size}")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG1: ${e.message}")
                        }

                        try {
                            val dg3File =
                                DG3File(passportService.getInputStream(PassportService.EF_DG3))
                            passportInfo?.DG3Size = dg3File.encoded.size.toString()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG3: ${e.message}")
                        }

                        try {
                            val dg4File =
                                DG4File(passportService.getInputStream(PassportService.EF_DG4))
                            passportInfo?.DG4Size = dg4File.encoded.size.toString()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG4: ${e.message}")
                        }


                        try {
                            val dg5File =
                                DG5File(passportService.getInputStream(PassportService.EF_DG5))
                            passportInfo?.DG5Size = dg5File.encoded.size.toString()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG5: ${e.message}")
                        }

                        try {
                            val dg6File =
                                DG6File(passportService.getInputStream(PassportService.EF_DG6))
                            passportInfo?.DG6Size = dg6File.encoded.size.toString()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG6: ${e.message}")
                        }

                        try {
                            val dg7File =
                                DG7File(passportService.getInputStream(PassportService.EF_DG7))
                            passportInfo?.DG7Size = dg7File.encoded.size.toString()
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG7: ${e.message}")
                        }

                        var userBitmap: Bitmap? = null
                        try {
                            val dg2File =
                                DG2File(passportService.getInputStream(PassportService.EF_DG2))
                            val faceImageInfo =
                                dg2File.faceInfos.firstOrNull()?.faceImageInfos?.firstOrNull()
                            passportInfo?.biometric_facialData = "${dg2File.encoded.size}"

                            faceImageInfo?.let { info ->
                                val imageBytes = info.imageInputStream.readBytes()
                                val base64String = imageBytes.toBase64()
                                passportInfo?.personImage = base64String
                                userBitmap = decodeBase64JP2ToBitmap(base64String)
                            }
                            Log.d(TAG, "DG2 read successfully. Size: ${dg2File.encoded.size}")
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read DG2: ${e.message}")
                        }

                        try {
                            val comFile =
                                COMFile(passportService.getInputStream(PassportService.EF_COM))
                            passportInfo?.ef =
                                "LDS v${comFile.ldsVersion}, Unicode v${comFile.unicodeVersion}"
                            Log.d(
                                TAG,
                                "EF.COM read successfully. LDS Version: ${comFile.ldsVersion}, Unicode Version: ${comFile.unicodeVersion}"
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read EF.COM: ${e.message}")
                        }

                        try {
                            val sodFile = passportService.getInputStream(PassportService.EF_SOD)
                            // You can add more SOD info here if needed
                            passportInfo?.sodFile = sodFile.readBytes().size.toString()
                            Log.d(
                                TAG,
                                "EF.SOD read successfully. Size: ${sodFile.readBytes().size}"
                            )
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed to read EF.SOD: ${e.message}")
                        }
                        try {
                            val dg11File =
                                DG11File(passportService.getInputStream(PassportService.EF_DG11))

                            passportInfo?.DG11Size = dg11File.encoded.size.toString()


                            if (dg11File.placeOfBirth.isNotEmpty()){
                                passportInfo?.placeOfBirth = dg11File.placeOfBirth.joinToString(", ")
                            }

                                Log.d(TAG, "  - Place of Birth: ${dg11File.placeOfBirth}")
                                Log.d(TAG, "  - Profession: ${dg11File.profession}")
                                Log.d(TAG, "  - Title: ${dg11File.title}")
                                Log.d(TAG, "  - Personal Number: ${dg11File.personalNumber}")
                                Log.d(TAG, "  - Other Names: ${dg11File.otherNames}")

                            Log.d(TAG, "DG11 read successfully. Size: ${dg11File.encoded.size}")
                        } catch (e: Exception) {
                            Log.w(TAG, "DG11 not found or failed to read: ${e.message}")
                        }
                        // Read DG12 (Additional person details)
                        try {
                            val dg12File =
                                DG12File(passportService.getInputStream(PassportService.EF_DG12))
                            // You can extract more info from dg12File if needed
                            passportInfo?.DG12Size = dg12File.encoded.size.toString()

                            Log.d(TAG, "DG12 read successfully. Size: ${dg12File.encoded.size}")
                        } catch (e: Exception) {
                            Log.w(TAG, "DG12 not found or failed to read: ${e.message}")
                        }

                        try {
                            val dg14File =
                                DG14File(passportService.getInputStream(PassportService.EF_DG14))
                            passportInfo?.eacInfoDG14 = "${dg14File.encoded.size}"
                            Log.d(TAG, "DG14 read successfully. Size: ${dg14File.encoded.size}")
                        } catch (e: Exception) {
                            Log.w(TAG, "DG14 not found or failed to read: ${e.message}")
                        }
                        val faceBitmap = userBitmap
                        if (faceBitmap == null) {
                            Log.e(TAG, "Aborting: DG2 face image was not read successfully")
                            nfcScanCallback?.onTimeExpired()
                        } else {
                            nfcScanCallback?.onScanNFCCompleted(passportInfo!!, faceBitmap)
                        }

                        passportService.close()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error reading files", e)
                        nfcScanCallback?.onTimeExpired()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reading passport data", e)
                nfcScanCallback?.onTimeExpired()
            } finally {
                try {
                    isoDep.close()
                } catch (e: SecurityException) {
                    Log.w(TAG, "IsoDep already invalidated, cannot close: ${e.message}")
                } catch (e: Exception) {
                    Log.e(TAG, "Error closing IsoDep", e)
                }
            }
        } else {
            nfcScanCallback?.onTimeExpired()
            Log.e(TAG, "IsoDep is null, unable to read passport")
        }
    }

    suspend fun readCardData(tag: Tag, mrzData: MRZData) {
        val isoDep = IsoDep.get(tag) ?: run {
            Log.e(TAG, "IsoDep is null, unable to read card")
            nfcScanCallback?.onTimeExpired()
            return
        }

        try {
            isoDep.timeout = 40000
            val cardService = CardService.getInstance(isoDep)
            cardService.open()

            val passportService = PassportService(
                cardService,
                PassportService.NORMAL_MAX_TRANCEIVE_LENGTH,
                PassportService.DEFAULT_MAX_BLOCKSIZE,
                false,
                false
            )
            passportService.open()

            // Prepare BAC key
            val documentNumber = mrzData.documentNumber.trim().padEnd(9, '<')
            val dateOfBirth = mrzData.dateOfBirth
            val dateOfExpiry = mrzData.expiryDate

            Log.d(
                TAG,
                "Parsed MRZ Data - Document Number: $documentNumber, DOB: $dateOfBirth, Expiry: $dateOfExpiry"
            )

            // Create a BACKey using the MRZ data
            val bacKey = BACKey(documentNumber, dateOfBirth, dateOfExpiry)

            var paceSucceeded = false

            // Try PACE first (use PACE if supported by the card)
            try {
                passportService.doPACE(bacKey, "", null)
                paceSucceeded = true
                Log.d(TAG, "PACE Authentication Successful")
            } catch (e: Exception) {
                Log.e(TAG, "PACE failed: ${e.message}")
            }

            // Fallback to BAC if PACE fails
            if (!paceSucceeded) {
                try {
                    passportService.doBAC(bacKey)
                    Log.d(TAG, "BAC Authentication Successful")
                } catch (e: AccessDeniedException) {
                    Log.e(TAG, "Access denied during BAC: ${e.message}")
                    nfcScanCallback?.onTimeExpired()
                    return
                }
            }

            // Read card data after successful authentication
            withContext(Dispatchers.IO) {
                try {
                    val efComBytes =
                        passportService.getInputStream(PassportService.EF_COM).readBytes()
                    val comFile = COMFile(ByteArrayInputStream(efComBytes))
                    Log.d(
                        TAG,
                        "LDS Version: ${comFile.ldsVersion}, Unicode Version: ${comFile.unicodeVersion}"
                    )

                    val dg1File = DG1File(passportService.getInputStream(PassportService.EF_DG1))
                    val mrzInfo = dg1File.mrzInfo

                    val dg2File = DG2File(passportService.getInputStream(PassportService.EF_DG2))
                    val faceImageInfo = dg2File.faceInfos[0].faceImageInfos.firstOrNull()

                    val nationality = mrzInfo.nationality
                    val gender = mrzInfo.gender
                    val surname = mrzInfo.secondaryIdentifier
                    val givenName = mrzInfo.primaryIdentifier

                    Log.e("nationality", nationality)
                    Log.e("gender", gender.toString())
                    Log.e("surname", surname)

                    faceImageInfo?.let { info ->
                        val imageBytes = info.imageInputStream.readBytes()
                        val base64String = imageBytes.toBase64()

                        val userImage = decodeBase64JP2ToBitmap(base64String)
                        // Uncomment the following line if you need to pass the image
                        // nfcScanCallback?.onScanNFCCompleted(passportInfo, userImage)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error reading files", e)
                    nfcScanCallback?.onTimeExpired()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading card data", e)
            nfcScanCallback?.onTimeExpired()
        } finally {
            isoDep.close()
        }
    }


    @SuppressLint("NewApi")
    fun readDG2DataQuickly(passportService: PassportService): ByteArray? {
        val inputStream = passportService.getInputStream(PassportService.EF_DG2)
        val buffer = ByteArray(1024)
        val outputStream = ByteArrayOutputStream()
        try {
            var bytesRead: Int
            while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                outputStream.write(buffer, 0, bytesRead)
            }
        } catch (e: IOException) {
            Log.e(TAG, "Error reading DG2 data in chunks", e)
        }
        return outputStream.toByteArray()
    }

    fun ByteArray.toBase64(): String {
        return Base64.encodeToString(this, Base64.DEFAULT)
    }

    fun handleBiometricData(data: ByteArray) {
        Log.d(TAG, "Received biometric data of size: ${data.size}")
    }

    public fun observeTag(): StateFlow<String?> {
        return liveTag.asStateFlow()
    }

    fun formatName(input: String): String {
        return input.replace("<", " ").trim().replace(Regex(" +"), " ")
    }

    fun decodeBase64JP2ToBitmap(base64String: String): Bitmap? {

        val imageBytes = Base64.decode(base64String, Base64.DEFAULT)

        val mat = Imgcodecs.imdecode(MatOfByte(*imageBytes), Imgcodecs.IMREAD_COLOR)
        if (mat.empty()) return null

        val rgbMat = Mat(mat.rows(), mat.cols(), mat.type())
        val channels = ArrayList<Mat>(3)
        Core.split(mat, channels)

        Core.merge(listOf(channels[2], channels[1], channels[0]), rgbMat)

        val bitmap = Bitmap.createBitmap(rgbMat.cols(), rgbMat.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgbMat, bitmap)

        return bitmap
    }

}


///                try {
//                    val cardSecurityFile =
//                        CardSecurityFile(passportService.getInputStream(PassportService.EF_CARD_SECURITY))
//                    val securityInfoCollection = cardSecurityFile.securityInfos
//                    for (securityInfo in securityInfoCollection) {
//                        if (securityInfo is PACEInfo) {
//                            val paceInfo = securityInfo
//                            val objectIdentifier = paceInfo.objectIdentifier
//                            val parameterSpec = PACEInfo.toParameterSpec(paceInfo.parameterId)
//                            Log.d(TAG, "Found PACE Info: objectIdentifier=$objectIdentifier, parameterSpec=$parameterSpec")
//                            passportService.doPACE(
//                                bacKey,
//                                paceInfo.objectIdentifier,
//                                PACEInfo.toParameterSpec(paceInfo.parameterId),
//                                null
//                            )
//                            paceSucceeded = true
//                            Log.d(TAG, "PACE authentication successful")
//                            break
//                        }
//                    }
//                } catch (e: Exception) {
//                    if (e.message?.contains("SW = 0x6A82") == true) {
//                        Log.w(TAG, "PACE not supported (EF.CardSecurity not found)")
//                    } else {
//                        Log.w(TAG, "PACE failed: ${e.message}")
//                    }
//                }
