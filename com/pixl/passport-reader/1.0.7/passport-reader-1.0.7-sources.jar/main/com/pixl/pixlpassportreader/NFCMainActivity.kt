package com.pixl.pixlpassportreader

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.Bitmap
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.CompoundButton
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import com.pixl.pixlpassportreader.databinding.ActivityBinder
import com.google.gson.Gson
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Locale

interface PixlNFCResultCallback {
    fun onNFCScanSuccess(passportInfoJson: String, bitmap: Bitmap)
    fun onWithoutNFCScanSuccess(passportInfoJson: String, passportInfo: PassportResult)
    fun onNFCScan(passportResult: PassportResult, bitmap: Bitmap)
}

@RequiresApi(Build.VERSION_CODES.KITKAT)
class NFCMainActivity : AppCompatActivity(),
    CompoundButton.OnCheckedChangeListener, NfcAdapter.ReaderCallback, NFCScanCallback {
    companion object {
        private val TAG = NFCMainActivity::class.java.simpleName
        var parameter: String? = ""
        var scanResultCallback: WeakReference<PixlNFCResultCallback>? = null
        fun scanResultCallback(callback: PixlNFCResultCallback) {
            scanResultCallback = WeakReference(callback)
        }
    }
    private var animatorSet: AnimatorSet? = null
    private var passportResult: PassportResult? = null
    private var binder: ActivityBinder? = null
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        binder = DataBindingUtil.setContentView(this, R.layout.nfc_activity_main)
        binder?.viewModel = viewModel
        binder?.lifecycleOwner = this

        viewModel.setNFCScanCallback(this)
        val backButton: ImageButton = findViewById(R.id.back_bt)
        backButton.setOnClickListener {
            finish()
        }

        parameter?.let { gson ->
            val value = parseNFCPassportInfo(gson)
            passportResult = value
            binder?.nfcIconPassport?.let { nfcImage ->
                binder?.nfcIcon?.let { nfcIcon ->
                    startLoopingNfcAnimation(nfcImage, nfcIcon)
                }
            }

        }
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onResume() {
        super.onResume()
        // Delay enabling reader mode slightly to allow the activity to be fully ready.
        Handler(Looper.getMainLooper()).postDelayed({
            enableNfcReaderMode()
        }, 500) // 500ms delay
    }

    private fun enableNfcReaderMode() {
        val nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC is not supported on this device.", Toast.LENGTH_LONG).show()
            finish()
        } else if (!nfcAdapter.isEnabled) {
            Toast.makeText(this, "NFC is disabled. Please enable it in settings.", Toast.LENGTH_LONG).show()
        } else {
            NFCManager.enableReaderMode(this, this, this, viewModel.getNFCFlags(), viewModel.getExtras())
        }
    }

    @RequiresApi(Build.VERSION_CODES.KITKAT)
    override fun onPause() {
        super.onPause()
        NFCManager.disableReaderMode(this, this)
    }

    override fun onCheckedChanged(buttonView: CompoundButton?, isChecked: Boolean) {
        // Not used as of now
    }

    override fun onTagDiscovered(tag: Tag?) {
        runOnUiThread {
            passportResult?.let {
                binder?.textViewExplanation?.text = "Please Hold The Passport"
                binder?.nfcIconPassport?.let { nfcImage ->
                    binder?.nfcIcon?.let { nfcIcon ->
                        stopNfcAnimationToBottom(nfcIcon, nfcImage)
                    }
                }
                binder?.progressBar?.visibility = View.VISIBLE
                Log.d("ProgressBar", binder?.progressBar?.progressDrawable.toString())

                val dob = formatDate(it.dob)
                val exp = formatDate(it.expirationDate)

                if (dob.isNotEmpty() && exp.isNotEmpty()) {
                    viewModel.readNFCTag(tag, it, it.passportNumber, dob, exp)
                } else {
                    onNFCScanFailed("Invalid date format detected in MRZ data.")
                }
            }
        }
    }

    fun parseNFCPassportInfo(jsonString: String): PassportResult {
        val gson = Gson()
        return gson.fromJson(jsonString, PassportResult::class.java)
    }

    override fun onScanCompleted(scanResult: String, bitmap: Bitmap) {
        scanResultCallback?.get()?.onNFCScanSuccess(scanResult, bitmap)
        finish()
    }

    override fun onScanNFCCompleted(scanResult: PassportResult, bitmap: Bitmap) {
        scanResultCallback?.get()?.onNFCScan(scanResult, bitmap)
        finish()
    }

    override fun onTimeExpired() {
        runOnUiThread {
            Toast.makeText(applicationContext, "NFC connection timed out. Please keep the passport in place and try again.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    fun onNFCScanFailed(message: String) {
        runOnUiThread {
            Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    fun formatDate(input: String): String {
        return try {
            val inputFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            val outputFormat = SimpleDateFormat("yyMMdd", Locale.getDefault())
            val date = inputFormat.parse(input)
            date?.let { outputFormat.format(it) } ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "Error formatting date: $input", e)
            ""
        }
    }

    private fun startLoopingNfcAnimation(passportIcon: ImageView, nfcIcon: ImageView) {
        passportIcon.post {
            val startY = 0f
            val downDistance = 230f
            val moveDown = ObjectAnimator.ofFloat(nfcIcon, "translationY", startY, downDistance).apply {
                duration = 1500
                interpolator = AccelerateDecelerateInterpolator()
                repeatCount = ObjectAnimator.INFINITE
                repeatMode = ObjectAnimator.REVERSE
            }
            animatorSet = AnimatorSet().apply {
                play(moveDown)
                start()
            }
        }
    }

    private fun stopNfcAnimationToBottom(nfcIcon: ImageView, passportIcon: ImageView) {
        passportIcon.post {
            animatorSet?.cancel()
            val moveToBottom = ObjectAnimator.ofFloat(nfcIcon, "translationY", nfcIcon.translationY, 230f).apply {
                duration = 600
                interpolator = AccelerateDecelerateInterpolator()
            }
            animatorSet = AnimatorSet().apply {
                play(moveToBottom)
                start()
            }
        }
    }
}