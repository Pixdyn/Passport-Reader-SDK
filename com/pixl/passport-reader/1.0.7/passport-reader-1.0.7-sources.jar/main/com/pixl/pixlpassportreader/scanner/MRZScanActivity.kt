package com.pixl.pixlpassportreader.scanner

import com.pixl.pixlpassportreader.R
import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.ExifInterface
import android.net.Uri
import android.nfc.NfcAdapter
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.util.Range
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.core.view.doOnLayout
import androidx.window.layout.WindowMetricsCalculator
import com.google.gson.Gson
import com.pixl.pixlpassportreader.NFCMainActivity
import com.pixl.pixlpassportreader.NFCManager
import com.pixl.pixlpassportreader.PassportResult
import com.pixl.pixlpassportreader.PixlHitService
import com.pixl.pixlpassportreader.PixlHitServiceException
import com.pixl.pixlpassportreader.PixlNFCResultCallback
import com.pixl.pixlpassportreader.TesseractManager
import com.pixl.pixlpassportreader.databinding.MrzScanActvityBinding
import com.pixl.pixlpassportreader.scanner.BitmapUtils.bitmapToBase64
import com.pixl.pixlpassportreader.scanner.BitmapUtils.cropBitmap
import com.pixl.pixlpassportreader.scanner.mrz.MrtdTd1
import com.pixl.pixlpassportreader.scanner.mrz.MrzFormat
import com.pixl.pixlpassportreader.scanner.mrz.MrzRecord
import com.pixl.pixlpassportreader.scanner.mrz.additionaldetails.MRZUtils
import kotlinx.coroutines.*
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import java.io.File
import java.io.FileOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

interface PixlResultCallback {
    fun onScanDataSuccess(passportInfoJson: String)
    fun onNFCScanSuccess(passportInfoJson: String, bitmap: Bitmap)
    fun onScanError(errorCode: String, errorMessage: String)
}


enum class ScanState {
    SCANNING_DOCUMENT,
    MRZ_DETECTED_PROCESSING,
    OCR_PROCESSING,
    MRZ_PARSED_FINALIZING
}

enum class DeviceTier {
    LOW, MID, HIGH
}

class MRZScanActivity : AppCompatActivity(),
    Detector.DetectorListener,
    SensorEventListener,
    PixlNFCResultCallback {

    private lateinit var binding: MrzScanActvityBinding
    private lateinit var textReaderAnalyzer: CaptureTextReaderAnalyzer
    private lateinit var textReaderAnalyzerTd1: CaptureTextReaderAnalyzerTd1

    private val isFrontCamera = false
    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val bgScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var isShaking = false
    private var shakeThreshold = 2.7f

    private var preview: Preview? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraExecutor: ExecutorService? = null

    // Written on bgScope (the crop-enhance-encode work is dispatched off the
    // camera thread - see onDetect()) and read from the camera executor
    // thread / uiScope; volatile so those writes are visible promptly.
    @Volatile
    private var passportImage: String? = null
    @Volatile
    private var passportHolderPhoto: String? = null
    @Volatile
    private var isPassportSaved = false
    @Volatile
    private var isPhotoSaved = false

    private var currentScanState: ScanState = ScanState.SCANNING_DOCUMENT
    private var isFlashOn = false
    private var isProcessingGallery = false
    private var isOcrRunning = false
    private var isFinished = false

    private var lastInferenceTimeMs = 0L
    // Device-tiered (DevicePerf.inferenceIntervalMs, read at the call site in
    // bindCameraUseCases()) instead of one fixed value for every device -
    // low-tier devices get a longer gap so they're not burning every core on
    // detection attempts a slow CPU can't keep up with anyway.

    private var passportResult: PassportResult? = null

    private var isInitialized = false

    // Tesseract readiness now lives solely in TesseractManager.isReady (see
    // startService()/onDetect() below) - both the TD3 and TD1 analyzers share
    // that one engine instead of each maintaining/initializing their own.

    // ---- Detector (single instance) ----
    private val detector: Detector by lazy {
        Detector(baseContext, Constants.MODEL_PATH, Constants.LABELS_PATH, this).apply {
            setup()
        }
    }

    // Shared between the TD3 (2-line) and TD1 (3-line) analyzers so both routes finish
    // through the same result/error handling.
    private val mrzPassFoundListener: (MrzRecord) -> Unit = { mrzRecord ->
        handleMrzResult(mrzRecord)
        Log.e("passFoundListener", "Clearing analyzer queue and finalizing result")
    }

    private val mrzErrorListener: (String, Boolean) -> Unit = { error, shouldResetState ->
        Log.d("MRZ_ERROR", error)
        Log.e("errorListener", "Clearing analyzer queue and finalizing result")
        if (isProcessingGallery) {
            uiScope.launch {
                Toast.makeText(
                    this@MRZScanActivity,
                    "Failed to process selected image. Please try again.",
                    Toast.LENGTH_LONG
                ).show()
                resetGalleryState()
            }
        } else if (shouldResetState) {
            uiScope.launch {
                isOcrRunning = false
                resetScanningState()
            }
        }
    }

    private var frameCount = 0
    private var detectionHitCount = 0

    private var focusJob: Job? = null

    private var lastStableTime = 0L
    private val REQUIRED_STABLE_TIME_MS = 300L // 0.7 sec

    private var lastMrzBox: BoundingBox? = null

    private var lastLightCheckTime = 0L
    private var lastBrightTime = 0L

    private val TORCH_ON_THRESHOLD = 60.0   // darker
    private val TORCH_OFF_THRESHOLD = 90.0  // brighter
    private val TORCH_DEBOUNCE_MS = 1200L


    // ===== LIFECYCLE =====

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

//    override fun onResume() {
//        super.onResume()
//        uiScope.launch {
//            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//            val prev = prefs.getInt(PREF_HIT_COUNT, 0)
//            if (prev >= MAX_HIT_COUNT) {
//                Toast.makeText(applicationContext, "Scan limit reached", Toast.LENGTH_LONG).show()
//                finish()
//                return@launch
//            }
//
//            if (!OpenCVLoader.initDebug()) {
//                finish()
//                return@launch
//            }
//
//            val apiKey = intent.getStringExtra(EXTRA_API_KEY)
//            Log.e("MRZScanActivity", "API Key: $apiKey")
//            if (apiKey.isNullOrBlank()) {
//                Toast.makeText(applicationContext, "Missing API key", Toast.LENGTH_LONG).show()
//                finish()
//                return@launch
//            }
//
//            // Skips the network call entirely if this exact key was verified before —
//            // that's what allows the SDK to keep working offline.
//            val verifyResult = withContext(Dispatchers.IO) {
//                PixlSdkManager.ensureVerified(applicationContext, apiKey)
//            }
//
//            when (verifyResult) {
//                is PixlSdkManager.VerifyResult.Success -> {
//                    setupUiAndStart()
//
//                    bgScope.launch {
//                        TesseractManager.init(applicationContext)
//                        isOcrReady = true
//                    }
//
//                    // Opportunistic flush of any hit records queued while offline.
//                    bgScope.launch {
//                        PixlSdkManager.syncPendingHits(applicationContext)
//                    }
//                }
//
//                is PixlSdkManager.VerifyResult.Failure -> {
//                    Toast.makeText(
//                        applicationContext,
//                        "Unable to verify API key: ${verifyResult.reason}",
//                        Toast.LENGTH_LONG
//                    ).show()
//                    finish()
//                }
//            }
//        }
//    }


    override fun onResume() {
        super.onResume()

        isFinished = false
        isOcrRunning = false
        currentScanState = ScanState.SCANNING_DOCUMENT

        DevicePerf.init(applicationContext)

        if (!OpenCVLoader.initDebug()) {
            finish()
            return
        }
        setupUiAndStart()

        // Single shared engine for both the TD3 and TD1 analyzers - internally
        // idempotent (returns immediately if already initialized), so this is
        // cheap to call on every resume. TesseractManager.isReady is read
        // directly wherever readiness matters (see onDetect()) instead of
        // mirroring it into a second, possibly-stale local flag.
        bgScope.launch {
            TesseractManager.init(applicationContext)
        }
    }
//    override fun onResume() {
//        super.onResume()
//        uiScope.launch {
//            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//            val prev = prefs.getInt(PREF_HIT_COUNT, 0)
//            if (prev >= MAX_HIT_COUNT) {
//                Toast.makeText(applicationContext, "Scan limit reached", Toast.LENGTH_LONG).show()
//                finish()
//                return@launch
//            }
//
//            if (!OpenCVLoader.initDebug()) {
//                finish()
//                return@launch
//            }
//
//            setupUiAndStart()
//
//            // Cheap no-op if already initialized elsewhere in the app's lifetime.
//            bgScope.launch {
//                TesseractManager.init(applicationContext)
//                isOcrReady = true
//            }
//        }
//    }

//    override fun onResume() {
//        super.onResume()
//        Log.e("OnResume", "Resuming activity, initializing resources")
//        uiScope.launch {
//            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
//            val prev = prefs.getInt(PREF_HIT_COUNT, 0)
//            if (prev >= MAX_HIT_COUNT) {
//                Toast.makeText(applicationContext, "Scan limit reached", Toast.LENGTH_LONG).show()
//                finish()
//            } else {
//                if (!OpenCVLoader.initDebug()) {
//                    finish()
//                }
//            setupUiAndStart()
////                bgScope.launch {
//////                    initTesseract()
////                }
//            }
//        }
//    }

    fun Context.isLowEndDevice(): Boolean {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

        // 1️⃣ Android Go devices → always low-end
        if (activityManager.isLowRamDevice) {
            return true
        }

        // 2️⃣ RAM check (<= 3GB is low-end for ML)
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val totalRamGB = memoryInfo.totalMem / (1024L * 1024L * 1024L)
        if (totalRamGB <= 3) {
            return true
        }

        // 3️⃣ CPU cores check
        val cores = Runtime.getRuntime().availableProcessors()
        if (cores <= 4) {
            return true
        }

        // 4️⃣ Old Android versions (usually weak hardware)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.O) {
            return true
        }

        return false
    }

    override fun onPause() {
        super.onPause()
        // Stop all processing first
        isOcrRunning = false
        isFinished = true
        focusJob?.cancel()

        // Stop camera
        stopCameraPreview()

        // Unregister sensor
        if (::sensorManager.isInitialized) {
            sensorManager.unregisterListener(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isFinished = true
        releaseResources()
    }

    override fun onBackPressed() {
        super.onBackPressed()
//        releaseResources()
//        finish()
    }

    private fun setupUiAndStart() {
        binding = MrzScanActvityBinding.inflate(layoutInflater)
        supportActionBar?.hide()
        setContentView(binding.root)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        // Defensive: avoids stacking a second listener if this is ever re-entered
        // without an onPause() in between.
        sensorManager.unregisterListener(this)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        cameraExecutor = Executors.newSingleThreadExecutor()
        galleryExecutor = Executors.newSingleThreadExecutor()

        setupButtonListeners()
        positionPoweredByLabel()

        // Built synchronously - construction here is just wiring listeners,
        // not real work - so both analyzers are guaranteed ready before the
        // camera can possibly deliver its first frame. Building these on
        // bgScope was a race: camera frames could reach onDetect() before
        // the background coroutine finished assigning these lateinit
        // fields, crashing with UninitializedPropertyAccessException.
        textReaderAnalyzer = CaptureTextReaderAnalyzer(
            context = this@MRZScanActivity,
            passFoundListener = mrzPassFoundListener,
            errorListener = mrzErrorListener
        )

        textReaderAnalyzerTd1 = CaptureTextReaderAnalyzerTd1(
            context = this@MRZScanActivity,
            passFoundListener = mrzPassFoundListener,
            errorListener = mrzErrorListener
        )

//        startService()
        // Same shape as the iOS SDK's viewWillAppear -> verifyClientThenStart():
        // isVerified short-circuits to starting the camera with zero network
        // calls when this apiKey was already verified on a previous launch.
        val apiKey = intent.getStringExtra(EXTRA_API_KEY)
        if (apiKey.isNullOrBlank()) {
            Log.e(TAG, "verify-client aborted: missing API key")
            failVerification(PixlHitServiceException(PixlHitServiceException.NO_API_KEY, "Missing API key"))
            return
        }
        PixlHitService.configure(applicationContext, apiKey)
        Log.d(TAG, "isVerified=${PixlHitService.isVerified}")
        if (PixlHitService.isVerified) {
            startService()
        } else {
            verifyClientThenStart()
        }
    }

    // ===== CLIENT VERIFICATION =====

    // Mirrors the iOS SDK's verifyClientThenStart(): a single call into
    // PixlHitService.startSession() handles verify-client, the ERR007 ->
    // register-device fallback, and the local plan-expiry/hit-limit cache -
    // any failure comes back as one PixlHitServiceException to alert on.
    private fun verifyClientThenStart() {
        showVerifyingLoader()
        uiScope.launch {
            try {
                val status = PixlHitService.startSession()
                Log.d(TAG, "client verified, status=$status")
                onClientVerified()
            } catch (e: PixlHitServiceException) {
                failVerification(e)
            } catch (e: Exception) {
                failVerification(PixlHitServiceException(PixlHitServiceException.NETWORK_ERROR, e.message ?: "Verification error"))
            }
        }
    }

    private fun onClientVerified() {
        hideVerifyingLoader()
        startService()
    }

    private fun failVerification(error: PixlHitServiceException) {
        val message = error.message ?: "Verification failed."
        Log.e(TAG, "client verification failed [${error.code}]: $message")

        // Always hand the structured code/message back to the host app first,
        // regardless of which UI treatment follows.
        scanResultCallback?.get()?.onScanError(error.code, message)

        // ERR002 (invalid API key), ERR003 (hit limit exceeded) and ERR007
        // (device not registered - including when it's really "couldn't reach
        // the server to register", see PixlHitService.remapUnreachableToDeviceNotRegistered)
        // are messages the integrating app's end user actually needs to read
        // and act on - a Toast can be missed, so these get a modal alert with
        // an explicit OK button instead. Every other failure keeps the
        // lighter Toast.
        Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
        finish()
//        when (error.code) {
//            "ERR002" -> showVerificationErrorDialog("Invalid API Key", message)
//            "ERR003" -> showVerificationErrorDialog("Hit Limit Exceeded", message)
//            "ERR007" -> showVerificationErrorDialog("Device Not Registered", message)
//            else -> {
//
//            }
//        }
    }

    /** Modal, non-cancelable alert with a single OK button that closes the SDK. */
    private fun showVerificationErrorDialog(title: String, message: String) {
        if (isFinishing || isDestroyed) return

        val dialogView = layoutInflater.inflate(R.layout.dialog_verification_error, null)
        dialogView.findViewById<TextView>(R.id.dialogTitle).text = title
        dialogView.findViewById<TextView>(R.id.dialogMessage).text = message

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        dialogView.findViewById<Button>(R.id.dialogOkButton).setOnClickListener {
            dialog.dismiss()
            finish()
        }

        dialog.show()
    }

    private fun showVerifyingLoader() {
        binding.viewFinder.visibility = View.INVISIBLE
        binding.overlay.visibility = View.INVISIBLE
        binding.progressBar.visibility = View.VISIBLE
        binding.inferenceTime?.text = "Verifying license..."
    }

    private fun hideVerifyingLoader() {
        binding.progressBar.visibility = View.GONE
        binding.viewFinder.visibility = View.VISIBLE
        binding.overlay.visibility = View.VISIBLE
        binding.inferenceTime?.text = "Fit the document into the frame"
    }

    private fun setupButtonListeners() {
        binding.closeButton.setOnClickListener { finish() }

//        binding.galleryButton.setOnClickListener {
//            if (!isProcessingGallery) {
//                openGallery()
//            }
//        }

        binding.flashButton.setOnClickListener {
            toggleFlash()
        }
    }

    // The cutout's bottom edge depends on screen width (CameraOverlaysView derives its
    // height from width / 1.585, centered vertically) - a fixed dp margin from the
    // screen bottom can't track it across different screen sizes/aspect ratios, so this
    // reads the overlay's own computed rect once it's laid out and places the label
    // just below it, on every device.
    private fun positionPoweredByLabel() {
        binding.overlay.doOnLayout {
            val overlayRect = binding.overlay.getOverlayRect()
            val gapPx = 12f * resources.displayMetrics.density
            binding.poweredByPixl?.translationY = overlayRect.bottom + gapPx
        }
    }

    private fun toggleFlash() {
        camera?.let { cam ->
            isFlashOn = !isFlashOn
            cam.cameraControl.enableTorch(isFlashOn)
            // Swap the round background itself rather than tinting the icon - a lit
            // amber circle behind the bolt reads as "torch on" without needing to
            // recolor the glyph (which may already be a light color and would wash
            // out against a plain color tint).
            binding.flashButton.setBackgroundResource(
                if (isFlashOn) R.drawable.flash_on_background else R.drawable.close_button_background
            )
        }
    }

    // ===== GALLERY HANDLING (KEPT, BUT LIGHT) =====

    private var galleryExecutor: ExecutorService? = null

    private fun openGallery() {
        if (isProcessingGallery) return
        isProcessingGallery = true

        stopCameraPreview()
        clearDetectionData()

        binding.viewFinder.visibility = View.INVISIBLE
        binding.overlay.visibility = View.INVISIBLE
        binding.progressBar.visibility = View.VISIBLE
        binding.inferenceTime?.text = "Select image from gallery..."

        val intent =
            Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply {
                type = "image/*"
            }
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK && data?.data != null) {
                binding.inferenceTime?.text = "Processing selected image..."
                binding.progressBar.visibility = View.VISIBLE
                val uri = data.data!!
                galleryExecutor?.execute {
                    processSelectedImage(uri)
                }
            } else {
                resetGalleryState()
            }
        }
    }

    private fun processSelectedImage(imageUri: Uri) {
        try {
            val original = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
            val rotated = rotateBitmapIfRequired(original, imageUri)

            detector.detect(rotated)
            // rotated will be recycled inside onDetect() after processing
        } catch (e: Exception) {
            Log.e(TAG, "Error processing gallery image: ${e.message}", e)
            uiScope.launch {
                Toast.makeText(
                    this@MRZScanActivity,
                    "Error processing image. Please try again.",
                    Toast.LENGTH_LONG
                ).show()
                resetGalleryState()
            }
        }
    }

    private fun resetGalleryState() {
        isProcessingGallery = false
        binding.viewFinder.visibility = View.VISIBLE
        binding.overlay.visibility = View.VISIBLE
        binding.progressBar.visibility = View.GONE
        binding.inferenceTime?.text = "Scan Document"
        clearDetectionData()
        startCamera()
    }

    // ===== CAMERA =====

    private fun startService() {
        if (allPermissionsGranted()) {
            // Tesseract init is kicked off once, in onResume(), via
            // TesseractManager.init() - it's internally idempotent-guarded
            // and shared by both analyzers, so there's nothing to (re)start here.
            startCamera()
        } else {
            requestPermissionLauncher.launch(REQUIRED_PERMISSIONS)
        }
    }

    // No coroutine needed here - nothing below suspends, and this is always
    // already called from the main thread. The extra uiScope.launch hop was
    // pure overhead on the camera-start hot path.
    @SuppressLint("SetTextI18n")
    private fun startCamera() {
        binding.inferenceTime?.text = "Initializing camera..."
        currentScanState = ScanState.SCANNING_DOCUMENT

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    fun getScreenSize(activity: Activity): android.util.Size {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = WindowMetricsCalculator.getOrCreate()
                .computeCurrentWindowMetrics(activity)
            val bounds = windowMetrics.bounds
            android.util.Size(bounds.width(), bounds.height())
        } else {
            val display = activity.windowManager.defaultDisplay
            val outSize = android.graphics.Point()
            display.getSize(outSize)
            android.util.Size(outSize.x, outSize.y)
        }
    }

    fun Context.getDeviceTier(): DeviceTier {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

        if (am.isLowRamDevice) return DeviceTier.LOW

        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val ramGB = memInfo.totalMem / (1024L * 1024L * 1024L)

        val cores = Runtime.getRuntime().availableProcessors()

        return when {
            ramGB >= 6 && cores >= 8 -> DeviceTier.HIGH
            ramGB >= 4 -> DeviceTier.MID
            else -> DeviceTier.LOW
        }
    }
    @OptIn(ExperimentalCamera2Interop::class)
    private fun bindCameraUseCases() {

        val cameraProvider =
            cameraProvider ?: throw IllegalStateException("Camera init failed")

        val display = binding.viewFinder.display
        val rotation = display?.rotation ?: return

        val cameraSelector = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .build()

        // 1. Preview
        preview = Preview.Builder()
            .setTargetAspectRatio(AspectRatio.RATIO_4_3)
            .setTargetRotation(rotation)
            .build()

//        val analysisResolution = applicationContext.getAnalysisResolution()

        val resolutionSelector = ResolutionSelector.Builder()
            .setResolutionStrategy(
                ResolutionStrategy(
                    DevicePerf.analysisResolution,
                    ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                )
            )
            .build()

        imageAnalyzer = ImageAnalysis.Builder()
            .setResolutionSelector(resolutionSelector)
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setTargetRotation(rotation)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()

//        imageAnalyzer = ImageAnalysis.Builder()
////            .setTargetResolution(analysisResolution)
//            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
//            .setTargetRotation(rotation)
//            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
//            .build()


        cameraExecutor?.let { executor ->
            imageAnalyzer?.setAnalyzer(executor) { imageProxy ->
                try {

//                    if (currentScanState == ScanState.MRZ_PARSED_FINALIZING ||
//                        currentScanState == ScanState.OCR_PROCESSING
//                    ) {
//                        imageProxy.close()
//                        return@setAnalyzer
//                    }

                    val now = System.currentTimeMillis()
                    if (now - lastInferenceTimeMs < DevicePerf.inferenceIntervalMs) {
                        imageProxy.close()
                        return@setAnalyzer
                    }

                    lastInferenceTimeMs = now

                    val bitmapBuffer = imageProxy.toBitmap()
                    if (bitmapBuffer != null) {
                        val matrix = Matrix().apply {
                            postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
                            if (isFrontCamera) postScale(-1f, 1f)
                        }

                        val rotatedBitmap = Bitmap.createBitmap(
                            bitmapBuffer,
                            0,
                            0,
                            bitmapBuffer.width,
                            bitmapBuffer.height,
                            matrix,
                            true
                        )
                        if(!isFinished) {
                            detector.detect(rotatedBitmap)
                        }
                    }

                } catch (e: Exception) {
                    Log.e(TAG, "Error in image analysis", e)
                } finally {
                    imageProxy.close()
                }
            }
        }

        cameraProvider.unbindAll()

        try {
            camera = cameraProvider.bindToLifecycle(
                this,
                cameraSelector,
                preview,
                imageAnalyzer
            )

            preview?.setSurfaceProvider(binding.viewFinder.surfaceProvider)

            // 🔹 Zoom slightly for better MRZ focus
            camera?.cameraControl?.setZoomRatio(1.1f)

            val camera2Control = Camera2CameraControl.from(camera!!.cameraControl)
            camera2Control.setCaptureRequestOptions(
                CaptureRequestOptions.Builder()
                    .setCaptureRequestOption(
                        CaptureRequest.CONTROL_AF_MODE,
                        CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                    )
                    .build()
            )

//            applyLowLightCameraTuning()
            startCenterAutoFocus()

        } catch (exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }
    }


    fun hasGlare(bitmap: Bitmap, threshold: Int = 240, percent: Double = 0.15): Boolean {
        val width = bitmap.width
        val height = bitmap.height
        val totalPixels = width * height
        var brightPixels = 0
        val pixels = IntArray(totalPixels)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        for (pixel in pixels) {
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            if (r > threshold && g > threshold && b > threshold) {
                brightPixels++
            }
        }
        return brightPixels > totalPixels * percent
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun applyLowLightCameraTuning() {
        camera?.let { cam ->
            val camera2Control = Camera2CameraControl.from(cam.cameraControl)

            val options = CaptureRequestOptions.Builder()
                // Continuous focus
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AF_MODE,
                    CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                )

                // 🔥 Low light magic
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_MODE,
                    CameraMetadata.CONTROL_AE_MODE_ON
                )
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION,
                    2 // try 1–3 based on device
                )

                // Prefer brighter frames over fast shutter
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                    Range(15, 30)
                )

                .build()

            camera2Control.setCaptureRequestOptions(options)
        }
    }
    // How long a single startFocusAndMetering() call is allowed to run before
    // it auto-reverts to the base continuous-AF mode. The periodic nudge
    // below is deliberately spaced well past this, never overlapping it.
    private val FOCUS_AUTO_CANCEL_MS = 800L

    /**
     * CONTROL_AF_MODE_CONTINUOUS_PICTURE (set in bindCameraUseCases) already
     * has the HAL continuously refocusing on its own - this just (a) gives it
     * an initial kick onto the center of frame right after binding, since a
     * fresh continuous-AF session can start out soft, and (b) nudges it again
     * every few seconds in case the lens has drifted (e.g. distance to the
     * document changed).
     *
     * This USED to re-trigger every 300ms while each trigger's own
     * auto-cancel window was 800ms - i.e. a new focus-and-meter cycle was
     * kicked off before the previous one had even finished settling, several
     * times over. That's a textbook cause of visible focus "hunting" (the
     * lens perpetually restarting a scan instead of settling), which is
     * exactly what produces soft/blurry frames that MRZ OCR then fails to
     * read - contributing to both the slow results and the "sometimes
     * missing" detections. Nudges are also skipped while OCR_PROCESSING /
     * MRZ_PARSED_FINALIZING so a refocus can't blur the frame right as a
     * crop is being read.
     */
    private fun startCenterAutoFocus() {
        focusJob?.cancel()

        focusJob = uiScope.launch {
            triggerCenterFocus()

            while (isActive && camera != null && !isFinished) {
                delay(1500)
                if (currentScanState == ScanState.SCANNING_DOCUMENT) {
                    triggerCenterFocus()
                }
            }
        }
    }

    private fun triggerCenterFocus() {
        try {
            val factory = SurfaceOrientedMeteringPointFactory(
                binding.viewFinder.width.toFloat(),
                binding.viewFinder.height.toFloat()
            )

            val centerPoint = factory.createPoint(
                binding.viewFinder.width / 2f,
                binding.viewFinder.height / 2f
            )

            val action = FocusMeteringAction.Builder(
                centerPoint,
                FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            )
                .setAutoCancelDuration(FOCUS_AUTO_CANCEL_MS, TimeUnit.MILLISECONDS)
                .build()

            camera?.cameraControl?.startFocusAndMetering(action)
        } catch (e: Exception) {
            Log.w(TAG, "Auto focus failed: ${e.message}")
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onDetect(
        boundingBoxes: List<BoundingBox>,
        rotatedBitmap: Bitmap
    ) {
        try {
//            if (currentScanState != ScanState.SCANNING_DOCUMENT &&
//                !isProcessingGallery
//            ) {
//                rotatedBitmap.recycle()
//                return
//            }

            var passport: BoundingBox? = null
            var mrz: BoundingBox? = null
            var data_area: BoundingBox? = null
            var photo: BoundingBox? = null



            for (box in boundingBoxes) {
                if (!box.isValid()) continue
                when (box.clsName) {
                    "passport" -> if (box.cnf >= 0.7f) passport = box
                    "mrz" -> if (box.cnf >= 0.7f) mrz = box
                    "data_area" -> if (box.cnf >= 0.7f) data_area = box
                    "photo" -> if (box.cnf >= 0.6f) photo = box
                }
            }

            // Prefer whichever MRZ line-format was detected with higher confidence -
            // a single document should only ever surface one of the two.
//            val isThreeLineMrz = mrz3LineBox != null &&
//                    (mrz2LineBox == null || mrz3LineBox.cnf >= mrz2LineBox.cnf)
//            val mrzBox = if (isThreeLineMrz) mrz3LineBox else mrz2LineBox

//            if (m == null) return;

            if (passport != null ) {
                val croppedPassport = cropBitmap(rotatedBitmap, passport!!)
                if (croppedPassport != null) {

                    bgScope.launch {

//                        val enhanced = enhanceCropForClarity(
//                            croppedPassport,
//                            targetMinDimension = DevicePerf.mrzTargetMinDim,
//                            sharpnessLevel = 0.8,
//                            maxScale = DevicePerf.maxUpscale
//                        )
                        passportImage = bitmapToBase64(croppedPassport)
                        isPassportSaved = true
                    }
                }
            }

            if (photo != null ) {
                val croppedPhoto = cropBitmap(rotatedBitmap, photo!!)
                if (croppedPhoto != null) {

                    bgScope.launch {
//                        val enhanced = enhanceCropForClarity(
//                            croppedPhoto,
//                            targetMinDimension = 400,
//                            sharpnessLevel = 0.6
//                        )
                        passportHolderPhoto = bitmapToBase64(croppedPhoto)
                        isPhotoSaved = true
                    }
                }
            }

            if (mrz != null && isPassportSaved) {

                if (!::textReaderAnalyzer.isInitialized) { // || !::textReaderAnalyzerTd1.isInitialized
                    return
                }

                if (!TesseractManager.isReady) {
                    return
                }

//                isOcrRunning = true
//                currentScanState = ScanState.OCR_PROCESSING

                val mrzCrop = cropBitmap(rotatedBitmap, mrz)
                if (mrzCrop != null) {
//                    uiScope.launch {
//                        binding.inferenceTime?.visibility = View.VISIBLE
//                        binding.inferenceTime?.text = "Reading MRZ..."
//                        binding.overlay.setCaptured(true)
//                    }

                    bgScope.launch {
                        val sharp = increaseImageSharpness(mrzCrop, 1.8)
//                        val enhanced = enhanceCropForClarity(
//                            mrzCrop,
//                            targetMinDimension = DevicePerf.mrzTargetMinDim,
//                            sharpnessLevel = 0.8,
//                            maxScale = DevicePerf.maxUpscale
//                        )
                        textReaderAnalyzer.process(sharp)
//                        if (isThreeLineMrz) {
//                            textReaderAnalyzerTd1.process(sharp)
//                        } else {
//
//                        }
                    }
                }
            }

//                uiScope.launch {
//                    if (currentScanState == ScanState.SCANNING_DOCUMENT) {
//                        val src = if (isProcessingGallery) "Gallery" else "Camera"
//                        binding.inferenceTime.text = "Processing $src document..."
//                    }
//                }
        } finally {
            rotatedBitmap.recycle()
        }
    }

    override fun onEmptyDetect() {
//        uiScope.launch {
//            if (currentScanState == ScanState.SCANNING_DOCUMENT) {
//                binding.inferenceTime?.text = "Fit the document into the frame"
//                binding.overlay.setCaptured(false)
//                binding.mrzoverlay.clear()
//            }
//        }
    }

    // ===== MRZ RESULT HANDLING =====
    private fun hasInvalidChars(vararg fields: String): Boolean {
        val invalidRegex = Regex("[<>.,\\]\\[}{|_\\-()*^&%$#@!]")
        return fields.any { invalidRegex.containsMatchIn(it) }
    }

    private fun handleMrzResult(mrzRecord: MrzRecord) {
        Log.e("handleMrzResult", "Clearing analyzer queue and finalizing result")
        Log.d(TAG, "handleMrzResult: record=$mrzRecord")

        val countryCode = mrzRecord.nationality
        val issuingCountryCode = mrzRecord.issuingCountry
        val dob = MRZUtils.formatDate(mrzRecord.dateOfBirth.toString().trim('{', '}'))
        val expirationDate =
            MRZUtils.formatDate(mrzRecord.expirationDate.toString().trim('{', '}'))

        Log.d(TAG, "handleMrzResult: dob=$dob (raw=${mrzRecord.dateOfBirth}), expirationDate=$expirationDate (raw=${mrzRecord.expirationDate})")

        if (mrzRecord.toString().isEmpty() ||
            mrzRecord.expirationDate.toString().contains("-1") ||
            dob.contains("-1") ||
            expirationDate.contains("-1")
        ) {
            Log.e(TAG, "handleMrzResult: aborting - empty record or unparsable date " +
                    "(record.isEmpty=${mrzRecord.toString().isEmpty()}, " +
                    "expirationDateRaw=${mrzRecord.expirationDate}, dob=$dob, expirationDate=$expirationDate)")
            uiScope.launch {
                resetScanningState()
            }

        }

        val rawFields = listOf(
            mrzRecord.surname,
            mrzRecord.givenNames,
            mrzRecord.documentNumber,
            mrzRecord.personalNumber ?: "",
            mrzRecord.nationality,
            mrzRecord.code.toString()
        )

        if (hasInvalidChars(*rawFields.toTypedArray())) {
            Log.e(TAG, "handleMrzResult: aborting - invalid characters in fields: $rawFields")
            uiScope.launch { resetScanningState() }
            
        }

        try {
            var passportNumber =
                MRZUtils.formatPassportNumber(mrzRecord.documentNumber, countryCode)

            val dobMrz = MRZUtilsDate.formatDateForMrz(dob)
            val expiryMrz = MRZUtilsDate.formatDateForMrz(expirationDate)
            val sexChar = if (mrzRecord.sex.name.startsWith("M", true)) 'M' else 'F'
            val documentCode = "${mrzRecord.code1}${mrzRecord.code2}"

            // TD1 records (3-line ID cards) need the actual TD1 30-char/3-line
            // encoding, not the TD3 44-char/2-line passport format.
            val isTd1 = mrzRecord.format == MrzFormat.MRTD_TD1
            val mrtdTd1 = mrzRecord as? MrtdTd1
            val optionalData1 = mrtdTd1?.optional
            val optionalData2 = mrtdTd1?.optional2
            val mrzLine1: String
            val mrzLine2: String
            val mrzLine3: String?

            if (isTd1) {
                val (l1, l2, l3) = generateIdCardMRZ(
                    documentCode = documentCode,
                    // Line 1's country and line 2's nationality are genuinely
                    // distinct fields on TD1 documents (e.g. a UAE-issued Emirates
                    // ID held by an Indian national) - don't collapse them.
                    issuingCountry = mrzRecord.issuingCountry,
                    surname = mrzRecord.surname,
                    givenNames = mrzRecord.givenNames,
                    documentNumber = passportNumber,
                    nationality = mrzRecord.nationality,
                    dateOfBirth = dobMrz,
                    sex = sexChar,
                    expiryDate = expiryMrz,
                    optionalData1 = optionalData1 ?: "",
                    optionalData2 = optionalData2 ?: ""
                )
                mrzLine1 = l1
                mrzLine2 = l2
                mrzLine3 = l3
            } else {
                val (l1, l2) = generatePassportMRZ(
                    issuingCountry = mrzRecord.nationality,
                    surname = mrzRecord.surname,
                    givenNames = mrzRecord.givenNames,
                    passportNumber = passportNumber,
                    nationality = mrzRecord.nationality,
                    dateOfBirth = dobMrz,
                    sex = sexChar,
                    expiryDate = expiryMrz,
                    personalNumber = mrzRecord.personalNumber,
                    documentCode = documentCode
                )
                mrzLine1 = l1
                mrzLine2 = l2
                mrzLine3 = null
            }

            val passportInfo = PassportInfo(
                message = "success",
                givenNames = mrzRecord.givenNames.replace("0", "o", true)
                    .replace(Regex("[^a-zA-Z ]"), "").uppercase(),
                surname = mrzRecord.surname.replace("0", "o", true)
                    .replace(Regex("[^a-zA-Z ]"), "").uppercase(),
                passportNumber = passportNumber,
                passportType = MRZUtils.extractCode(
                    mrzRecord.toString(),
                    mrzRecord.code1.toString()
                ),
                dob = dob,
                isValidDob = mrzRecord.validDateOfBirth,
                documentType = mrzRecord.code.toString().uppercase(),
                age = MRZUtils.calculateAge(dob),
                expirationDate = expirationDate,
                isExpired = MRZUtils.isExpired(expirationDate),
                monthsToExpire = MRZUtils.calculateMonthsToExpire(expirationDate).toString(),
                gender = mrzRecord.sex.toString(),
                issuingCountry = issuingCountryCode.uppercase(),
                nationality = PassportUtils.getNationality(countryCode.uppercase()).uppercase(),
                personImage = passportHolderPhoto,
                countryCode = issuingCountryCode.uppercase(),
                passportImage = passportImage,
                mrzLine1 = mrzLine1,
                mrzLine2 = mrzLine2,
                mrzLine3 = mrzLine3,
                optionalData1 = optionalData1?.ifBlank { null },
                optionalData2 = optionalData2?.ifBlank { null },
                // Only meaningful for TD3 passports - for TD1 this is just a copy
                // of optionalData2 backfilled for MRZ regeneration, not a distinct
                // user-facing field, so don't show it twice.
                personalNumber = if (isTd1) null else mrzRecord.personalNumber?.ifBlank { null },
            )
            currentScanState = ScanState.MRZ_PARSED_FINALIZING
            Log.d(TAG, "handleMrzResult: reached finish, passportInfo=$passportInfo")
            clearAnalyzerQueueAndFinish(passportInfo)
        } catch (e: Exception) {
            Log.e(TAG, "handleMrzResult: exception building/finishing passportInfo: ${e.message}", e)
            uiScope.launch { resetScanningState() }
        }
    }

    private fun clearAnalyzerQueueAndFinish(passportInfo: PassportInfo) {
        Log.e("clearAnalyzerQueueAndFinish", "Clearing analyzer queue and finalizing result")
        if (isFinished) return
        uiScope.launch {
            isFinished = true
            Log.e("isFinished entered", "Clearing analyzer queue and finalizing result")
            stopCameraPreview()

            val gson = Gson()
            var passportInfoJson = gson.toJson(passportInfo)
            passportResult = PassportResult(
                message = "Success",
                givenNames = passportInfo.givenNames,
                surname = passportInfo.surname,
                dob = passportInfo.dob,
                gender = passportInfo.gender,
                issuingCountry = passportInfo.issuingCountry,
                nationality = passportInfo.nationality,
                passportNumber = passportInfo.passportNumber,
                expirationDate = passportInfo.expirationDate,
                passportType = passportInfo.passportType,
                isValidDob = passportInfo.isValidDob,
                age = passportInfo.age,
                documentType = passportInfo.passportType,
                isExpired = passportInfo.isExpired,
                monthsToExpire = passportInfo.monthsToExpire,
                personImage = passportInfo.personImage,
                passportImage = passportInfo.passportImage,
                ef = "-",
                eacInfoDG14 = "-",
                mrz = "-",
                biometric_facialData = "-",
                mrzLine1 = passportInfo.mrzLine1 ?: "",
                mrzLine2 = passportInfo.mrzLine2 ?: "",
                mrzLine3 = passportInfo.mrzLine3,
                optionalData1 = passportInfo.optionalData1,
                optionalData2 = passportInfo.optionalData2,
                personalNumber = passportInfo.personalNumber,
                isNFC = false
            )

//            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                vibrator.vibrate(
//                    VibrationEffect.createOneShot(
//                        200,
//                        VibrationEffect.DEFAULT_AMPLITUDE
//                    )
//                )
//            } else {
//                vibrator.vibrate(200)
//            }

            if (isNFCBased) {
                if (NfcAdapter.getDefaultAdapter(applicationContext) != null &&
                    NFCManager.isSupportedAndEnabled(application)
                ) {
                    if (passportInfoJson != null ) {
                        bgScope.launch {
                            NFCMainActivity.parameter = passportInfoJson
                            NFCMainActivity.scanResultCallback(this@MRZScanActivity)
                            startActivity(Intent(applicationContext, NFCMainActivity::class.java))
                            setResult(Activity.RESULT_OK)
                            finish()
                        }
                    } else {
                        Toast.makeText(applicationContext, "Session Failed, Please scan Again", Toast.LENGTH_SHORT)
                            .show()
                        finish()
                    }

                } else {
                    Toast.makeText(applicationContext, "Please Enable NFC!", Toast.LENGTH_SHORT)
                        .show()
                    currentScanState = ScanState.SCANNING_DOCUMENT
                    finish()
                }
            } else {
                // Encrypts + queues the hit locally and kicks off a best-effort
                // flush to the server - mirrors iOS's recordHitAndFlush().
                Log.e("Result Call", "PixlHitService.recordHitAndFlush() called")
                PixlHitService.recordHitAndFlush()
                passportResult?.let { result ->
                    Log.e("Result ", result.toString())
                    val gson = Gson()
                    val json = gson.toJson(result)
                    scanResultCallback?.get()?.onScanDataSuccess(json)
                    setResult(Activity.RESULT_OK)
                    finish()
                }

            }
        }
    }

    private fun resetScanningState() {
        Log.d(TAG, "resetScanningState: resuming document scan")
        currentScanState = ScanState.SCANNING_DOCUMENT
        isOcrRunning = false

        // Deliberately NOT resetting isPassportSaved/isPhotoSaved/passportImage/
        // passportHolderPhoto here. This runs after every failed OCR attempt
        // (garbled read, bad checksum, etc.) - a bad MRZ read says nothing
        // about whether the id_card/photo crop already captured is good, and
        // re-detecting the id_card box a second time needs its own 0.7
        // confidence hit, which doesn't reliably line up with the next
        // MRZ-good frame. Wiping these here meant one failed attempt could
        // strand the scan waiting on a box that may not reappear for a while,
        // and dropped an image that was already fine. clearDetectionData()
        // is the place that resets these, for an actual new source image
        // (gallery pick) rather than a retry of the same live scan.
        binding.overlay.setCaptured(false)
        binding.mrzoverlay.visibility = View.GONE
        binding.inferenceTime?.text = "Fit the document into the frame"
    }

    // ===== HELPERS =====

    private fun clearDetectionData() {
        passportImage = null
        passportHolderPhoto = null
        isPassportSaved = false
        isPhotoSaved = false
    }

    private fun rotateBitmapIfRequired(bitmap: Bitmap, uri: Uri): Bitmap {
        val inputStream = contentResolver.openInputStream(uri)
        val exif = inputStream?.use { ExifInterface(it) }
        val orientation =
            exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)

        val rotation = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }

        return if (rotation != 0f) {
            val matrix = Matrix().apply { postRotate(rotation) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
    }

    // Bitmap.createScaledBitmap's bilinear filter goes soft past ~1.5x; cubic interpolation
    // keeps edges crisp so the unsharp mask afterward has real detail to work with.
    fun upscaleBitmap(inputBitmap: Bitmap, scale: Double): Bitmap {
        if (scale <= 1.0) return inputBitmap

        val src = Mat()
        Utils.bitmapToMat(inputBitmap, src)

        val resized = Mat()
        Imgproc.resize(src, resized, Size(0.0, 0.0), scale, scale, Imgproc.INTER_CUBIC)

        val resultBitmap =
            Bitmap.createBitmap(resized.cols(), resized.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(resized, resultBitmap)

        src.release()
        resized.release()
        return resultBitmap
    }

    // Scales a crop up so its shorter side is at least targetMinDimension, capped at maxScale
    // to avoid amplifying noise on crops that are already large enough.
    fun upscaleToMinDimension(
        inputBitmap: Bitmap,
        targetMinDimension: Int,
        maxScale: Double = 3.0
    ): Bitmap {
        val shortSide = minOf(inputBitmap.width, inputBitmap.height)
        if (shortSide <= 0) return inputBitmap
        val scale = (targetMinDimension.toDouble() / shortSide).coerceIn(1.0, maxScale)
        return upscaleBitmap(inputBitmap, scale)
    }

    fun enhanceCropForClarity(
        inputBitmap: Bitmap,
        targetMinDimension: Int,
        sharpnessLevel: Double,
        maxScale: Double = 3.0
    ): Bitmap {
        val upscaled = upscaleToMinDimension(inputBitmap, targetMinDimension, maxScale)
        val sharpened = increaseImageSharpness(upscaled, sharpnessLevel)
        if (upscaled !== inputBitmap) upscaled.recycle()
        return sharpened
    }

    fun increaseImageSharpness(
        inputBitmap: Bitmap,
        sharpnessLevel: Double = 1.8
    ): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(inputBitmap, src)
        val blurred = Mat()
        Imgproc.GaussianBlur(src, blurred, Size(0.0, 0.0), 3.0)

        val sharpened = Mat()
        Core.addWeighted(src, 1 + sharpnessLevel, blurred, -sharpnessLevel, 0.0, sharpened)

        val resultBitmap =
            Bitmap.createBitmap(sharpened.cols(), sharpened.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(sharpened, resultBitmap)

        src.release()
        blurred.release()
        sharpened.release()
        return resultBitmap
    }

    fun toGrayscale(original: Bitmap): Bitmap {
        val src = Mat()
        val gray = Mat()
        Utils.bitmapToMat(original, src)
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)
        val out = Bitmap.createBitmap(gray.cols(), gray.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(gray, out)
        src.release()
        gray.release()
        return out
    }

    fun MRZColorCorrection(inputBitmap: Bitmap): Bitmap {
        val src = Mat()
        val gray = Mat()
        val claheOutput = Mat()

        try {
            Utils.bitmapToMat(inputBitmap, src)

            // 1. Grayscale: ML Kit works faster with grayscale, and it removes color noise.
            Imgproc.cvtColor(src, gray, Imgproc.COLOR_BGR2GRAY)

            // 2. CLAHE (Lighting Fix):
            // We use a lower clipLimit (2.0) to be gentle.
            // This removes dark shadows without "frying" the text edges.
            val clahe = Imgproc.createCLAHE(2.0, Size(8.0, 8.0))
            clahe.apply(gray, claheOutput)

            // 3. NO BINARIZATION!
            // We stop here. We give ML Kit a clean, high-contrast grayscale image.
            // We let ML Kit decide exactly where the character edges are.

            val resultBitmap = Bitmap.createBitmap(
                claheOutput.cols(),
                claheOutput.rows(),
                Bitmap.Config.ARGB_8888
            )
            Utils.matToBitmap(claheOutput, resultBitmap)
            return resultBitmap

        } catch (e: Exception) {
            return inputBitmap
        } finally {
            src.release()
            gray.release()
            claheOutput.release()
        }
    }

    private fun stopCameraPreview() {
        camera?.let {
            preview?.setSurfaceProvider(null)
            imageAnalyzer?.clearAnalyzer()
            cameraProvider?.unbindAll()
        }
        camera = null
        imageAnalyzer = null
    }

    private fun releaseResources() {
        stopCameraPreview()
        cameraExecutor?.shutdown()
        cameraExecutor = null
        galleryExecutor?.shutdown()
        galleryExecutor = null
        detector.clear()
        uiScope.cancel()
        bgScope.cancel()
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {

            if (it[Manifest.permission.CAMERA] == true) {
                if (!isInitialized) {
                    isInitialized = true
                    setupUiAndStart()
                }
            } else {
                Toast.makeText(
                    this,
                    "Camera permission is required to scan documents.",
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        }

    // ===== SENSOR =====

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        val (x, y, z) = event.values
        val acceleration = sqrt(x * x + y * y + z * z) - SensorManager.GRAVITY_EARTH
        isShaking = acceleration > shakeThreshold

//        if (currentScanState == ScanState.SCANNING_DOCUMENT) {
//            if (isShaking) {
//                lastStableTime = 0L
//                lastMrzBox = null
//            }
//            binding.inferenceTime?.text =
//                if (isShaking) "Hold steady..." else "Fit the document into the frame"
//        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ===== NFC CALLBACKS =====

    override fun onNFCScanSuccess(passportInfoJson: String, bitmap: Bitmap) {
        Log.d(TAG, "onNFCScanSuccess $passportInfoJson")
    }

    override fun onWithoutNFCScanSuccess(passportInfoJson: String, passportInfo: PassportResult) {
        Log.d(TAG, "onWithoutNFCScanSuccess $passportInfoJson")
    }

    override fun onNFCScan(passportResult: PassportResult, bitmap: Bitmap) {
        val gson = Gson()
        val passportInfoJson = gson.toJson(passportResult)
        scanResultCallback?.get()?.onNFCScanSuccess(passportInfoJson, bitmap)
    }

    // ===== MRZ UTILS =====

    fun generatePassportMRZ(
        issuingCountry: String,
        surname: String,
        givenNames: String,
        passportNumber: String,
        nationality: String,
        dateOfBirth: String,
        sex: Char,
        expiryDate: String,
        personalNumber: String = "",
        documentCode: String = "P<"
    ): Pair<String, String> {

        fun charValue(c: Char): Int = when (c) {
            in '0'..'9' -> c - '0'
            in 'A'..'Z' -> c - 'A' + 10
            '<' -> 0
            else -> 0
        }

        fun computeCheckDigit(data: String): Char {
            val weights = listOf(7, 3, 1)
            var sum = 0
            data.forEachIndexed { i, c ->
                sum += charValue(c) * weights[i % 3]
            }
            return ((sum % 10) + '0'.code).toChar()
        }

        val nameField =
            (surname.replace(" ", "<") + "<<" + givenNames.replace(" ", "<")).uppercase()
        val line1 = "${documentCode.uppercase()}${issuingCountry.uppercase()}$nameField"
            .padEnd(44, '<')
            .take(44)

        val passportField = passportNumber.uppercase().padEnd(9, '<')
        val passportChk = computeCheckDigit(passportField)

        val dobChk = computeCheckDigit(dateOfBirth)
        val expChk = computeCheckDigit(expiryDate)

        val personalField = personalNumber.uppercase().padEnd(14, '<').take(14)
        val personalChk = computeCheckDigit(personalField)

        val compositeData = passportField + passportChk +
                dateOfBirth + dobChk +
                expiryDate + expChk +
                personalField + personalChk

        val finalChk = computeCheckDigit(compositeData)

        val line2 = passportField + passportChk +
                nationality.uppercase() +
                dateOfBirth + dobChk +
                sex +
                expiryDate + expChk +
                personalField + personalChk +
                finalChk

        return Pair(line1, line2)
    }

    // TD1 (ID card) equivalent of generatePassportMRZ: three lines of 30 characters
    // each, per ICAO 9303 (mirrors MrtdTd1.toMrz()'s field layout), built from the
    // same cleaned/formatted inputs the TD3 path uses rather than the raw parsed record.
    fun generateIdCardMRZ(
        documentCode: String,
        issuingCountry: String,
        surname: String,
        givenNames: String,
        documentNumber: String,
        nationality: String,
        dateOfBirth: String,
        sex: Char,
        expiryDate: String,
        optionalData1: String = "",
        optionalData2: String = ""
    ): Triple<String, String, String> {

        fun charValue(c: Char): Int = when (c) {
            in '0'..'9' -> c - '0'
            in 'A'..'Z' -> c - 'A' + 10
            '<' -> 0
            else -> 0
        }

        fun computeCheckDigit(data: String): Char {
            val weights = listOf(7, 3, 1)
            var sum = 0
            data.forEachIndexed { i, c ->
                sum += charValue(c) * weights[i % 3]
            }
            return ((sum % 10) + '0'.code).toChar()
        }

        val docCode = documentCode.uppercase().padEnd(2, '<').take(2)
        val country = issuingCountry.uppercase().padEnd(3, '<').take(3)

        val docNumberField = documentNumber.uppercase().padEnd(9, '<').take(9)
        val docNumberChk = computeCheckDigit(docNumberField)
        val optionalField = optionalData1.uppercase().padEnd(15, '<').take(15)

        val line1 = (docCode + country + docNumberField + docNumberChk + optionalField)
            .padEnd(30, '<').take(30)

        val dobChk = computeCheckDigit(dateOfBirth)
        val expChk = computeCheckDigit(expiryDate)
        val nationalityField = nationality.uppercase().padEnd(3, '<').take(3)
        val optional2Field = optionalData2.uppercase().padEnd(11, '<').take(11)

        val compositeData = docNumberField + docNumberChk + optionalField +
                dateOfBirth + dobChk +
                expiryDate + expChk +
                optional2Field
        val compositeChk = computeCheckDigit(compositeData)

        val line2 = (dateOfBirth + dobChk + sex + expiryDate + expChk +
                nationalityField + optional2Field + compositeChk)
            .padEnd(30, '<').take(30)

        val nameField =
            (surname.replace(" ", "<") + "<<" + givenNames.replace(" ", "<")).uppercase()
        val line3 = nameField.padEnd(30, '<').take(30)

        return Triple(line1, line2, line3)
    }

    companion object {
        private const val GALLERY_REQUEST_CODE = 1001
        private const val TAG = "MRZScanActivity"
        private const val PREFS_NAME = "pixl_prefs"
        private const val PREF_HIT_COUNT = "mrz_hit_count"
//        private const val MAX_HIT_COUNT = 500

        // This is just the *name* of the extra — never assign a real API key to it.
        const val EXTRA_API_KEY = "api_key"
        var isNFCBased: Boolean = false
        var isGallery: Boolean = false
        private var scanResultCallback: WeakReference<PixlResultCallback>? = null

        fun scanResultCallback(callback: PixlResultCallback) {
            scanResultCallback = WeakReference(callback)
        }

        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA
        )
    }

//    companion object {
//        private const val GALLERY_REQUEST_CODE = 1001
//        private const val TAG = "MRZScanActivity"
//        private const val PREFS_NAME = "pixl_prefs"
//        private const val PREF_HIT_COUNT = "mrz_hit_count"
//        private const val MAX_HIT_COUNT = 500
//
//        public var API_KEY: String = "api_key"
//
//        var isNFCBased: Boolean = false
//        var isGallery: Boolean = false
//        private var scanResultCallback: WeakReference<PixlResultCallback>? = null
//
//        fun scanResultCallback(callback: PixlResultCallback) {
//            scanResultCallback = WeakReference(callback)
//        }
//
//        private val REQUIRED_PERMISSIONS = arrayOf(
//            Manifest.permission.CAMERA
//        )
//    }
}

object MRZUtilsDate {
    fun formatDateForMrz(dateString: String): String {
        val clean = dateString.replace("{", "").replace("}", "").replace("/", "-")
        val parts = clean.split("-")
        return when (parts.size) {
            3 -> {
                val (d1, d2, d3) = parts
                val (day, month, year) = when {
                    d1.length == 4 -> Triple(
                        d3.padStart(2, '0'),
                        d2.padStart(2, '0'),
                        d1.takeLast(2)
                    )

                    d3.length == 4 -> Triple(
                        d1.padStart(2, '0'),
                        d2.padStart(2, '0'),
                        d3.takeLast(2)
                    )

                    else -> Triple(d1.padStart(2, '0'), d2.padStart(2, '0'), d3.padStart(2, '0'))
                }
                "$year$month$day"
            }

            else -> "000000"
        }
    }
}
